package hu.reelee81.pdflabelprinting

import com.itextpdf.kernel.geom.Rectangle
import com.itextpdf.kernel.geom.Vector
import com.itextpdf.kernel.pdf.PdfArray
import com.itextpdf.kernel.pdf.PdfBoolean
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfDictionary
import com.itextpdf.kernel.pdf.PdfName
import com.itextpdf.kernel.pdf.PdfNumber
import com.itextpdf.kernel.pdf.PdfPage
import com.itextpdf.kernel.pdf.PdfResources
import com.itextpdf.kernel.pdf.PdfStream
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.canvas.PdfCanvas
import com.itextpdf.kernel.pdf.canvas.parser.EventType
import com.itextpdf.kernel.pdf.canvas.parser.data.IEventData
import com.itextpdf.kernel.pdf.canvas.parser.data.ImageRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.data.PathRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.data.TextRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.listener.IEventListener
import com.itextpdf.kernel.pdf.xobject.PdfFormXObject
import com.itextpdf.kernel.pdf.xobject.PdfImageXObject
import com.itextpdf.kernel.font.PdfFontFactory
import java.io.ByteArrayOutputStream
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PdfFitClippingTest {
    @Test
    fun formBoundsExcludeHiddenContentsWithoutChangingTheStream() {
        document { pdf ->
            val form = PdfFormXObject(Rectangle(0f, 0f, 100f, 50f))
            PdfCanvas(form, pdf).rectangle(-20.0, -20.0, 1000.0, 1000.0).fill()
            val original = form.pdfObject.bytes.copyOf()
            val page = pdf.addNewPage()
            PdfCanvas(page).addXObjectAt(form, 100f, 200f)
            assertBounds(Rectangle(100f, 200f, 100f, 50f), bounds(page))
            assertArrayEquals(original, form.pdfObject.bytes)
        }
    }

    @Test
    fun explicitClippingInsideAFormRestrictsItsContents() {
        document { pdf ->
            val form = PdfFormXObject(Rectangle(0f, 0f, 100f, 50f))
            PdfCanvas(form, pdf).rectangle(2.0, 2.0, 96.0, 46.0).clip().endPath()
                .rectangle(-20.0, -20.0, 1000.0, 1000.0).fill()
            val page = pdf.addNewPage()
            PdfCanvas(page).addXObjectAt(form, 100f, 200f)
            assertBounds(Rectangle(102f, 202f, 96f, 46f), bounds(page))
        }
    }

    @Test
    fun clippedTextDoesNotContributeHiddenLinesOrOverlongRuns() {
        document { pdf ->
            val form = PdfFormXObject(Rectangle(0f, 0f, 100f, 50f))
            val font = PdfFontFactory.createFont(PdfDictionary().apply {
                put(PdfName.Type, PdfName.Font)
                put(PdfName.Subtype, PdfName.Type1)
                put(PdfName.BaseFont, PdfName("Helvetica"))
                put(PdfName.Encoding, PdfName.WinAnsiEncoding)
            })
            PdfCanvas(form, pdf).rectangle(2.0, 2.0, 96.0, 46.0).clip().endPath()
                .beginText().setFontAndSize(font, 20f)
                .moveText(2.0, 20.0).showText("A very long line that extends outside the field")
                .moveText(0.0, -100.0).showText("Hidden text").endText()
            val page = pdf.addNewPage()
            PdfCanvas(page).addXObjectAt(form, 100f, 200f)
            val box = requireNotNull(bounds(page))
            assertEquals(102f, box.left, .001f)
            assertEquals(198f, box.right, .001f)
            assertTrue(box.bottom >= 202f)
            assertTrue(box.top <= 248f)
        }
    }

    @Test
    fun rotatedFormMatrixAndParentTransformApplyToTheClip() {
        document { pdf ->
            val form = PdfFormXObject(Rectangle(0f, 0f, 100f, 50f))
            form.pdfObject.put(PdfName.Matrix, PdfArray(floatArrayOf(0f, 2f, -3f, 0f, 150f, 0f)))
            PdfCanvas(form, pdf).rectangle(-20.0, -20.0, 1000.0, 1000.0).fill()
            val page = pdf.addNewPage()
            PdfCanvas(page).concatMatrix(2.0, 0.0, 0.0, 3.0, 100.0, 200.0)
                .addXObjectWithTransformationMatrix(form, 1f, 0f, 0f, 1f, 0f, 0f)
            assertBounds(Rectangle(100f, 200f, 300f, 600f), bounds(page))
        }
    }

    @Test
    fun nestedFormsIntersectTheirBounds() {
        document { pdf ->
            val inner = PdfFormXObject(Rectangle(0f, 0f, 100f, 100f))
            PdfCanvas(inner, pdf).rectangle(-20.0, -20.0, 1000.0, 1000.0).fill()
            val outer = PdfFormXObject(Rectangle(0f, 0f, 50f, 50f))
            PdfCanvas(outer, pdf).addXObjectAt(inner, 25f, 25f)
            val page = pdf.addNewPage()
            PdfCanvas(page).addXObjectAt(outer, 100f, 200f)
            assertBounds(Rectangle(125f, 225f, 25f, 25f), bounds(page))
        }
    }

    @Test
    fun reversedFormCoordinatesDescribeTheSameClippingRectangle() {
        document { pdf ->
            val form = PdfFormXObject(Rectangle(0f, 0f, 100f, 50f))
            form.pdfObject.put(PdfName.BBox, PdfArray(floatArrayOf(100f, 50f, 0f, 0f)))
            PdfCanvas(form, pdf).rectangle(-20.0, -20.0, 1000.0, 1000.0).fill()
            val page = pdf.addNewPage()
            PdfCanvas(page).addXObjectWithTransformationMatrix(form, 1f, 0f, 0f, 1f, 100f, 200f)
            assertBounds(Rectangle(100f, 200f, 100f, 50f), bounds(page))
        }
    }

    @Test
    fun graphicsStateRestoreRemovesTemporaryClipping() {
        document { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).saveState().rectangle(10.0, 10.0, 20.0, 20.0).clip().endPath()
                .rectangle(0.0, 0.0, 100.0, 100.0).fill().restoreState()
                .rectangle(200.0, 200.0, 10.0, 10.0).fill()
            assertBounds(Rectangle(10f, 10f, 200f, 200f), bounds(page))
        }
    }

    @Test
    fun clipsStayInPageCoordinatesAfterTheMatrixChanges() {
        document { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).concatMatrix(1.0, 0.0, 0.0, 1.0, 100.0, 200.0)
                .rectangle(0.0, 0.0, 50.0, 50.0).clip().endPath()
                .concatMatrix(2.0, 0.0, 0.0, 2.0, 0.0, 0.0)
                .rectangle(-100.0, -100.0, 1000.0, 1000.0).fill()
            assertBounds(Rectangle(100f, 200f, 50f, 50f), bounds(page))
        }
    }

    @Test
    fun siblingFormDoesNotInheritThePreviousFormClip() {
        document { pdf ->
            val form = PdfFormXObject(Rectangle(0f, 0f, 10f, 10f))
            PdfCanvas(form, pdf).rectangle(-100.0, -100.0, 1000.0, 1000.0).fill()
            val page = pdf.addNewPage()
            PdfCanvas(page).addXObjectAt(form, 100f, 200f).addXObjectAt(form, 300f, 400f)
            assertBounds(Rectangle(100f, 200f, 210f, 210f), bounds(page))
        }
    }

    @Test
    fun emptyClipHasNoVisibleContents() {
        document { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).rectangle(0.0, 0.0, 0.0, 0.0).clip().endPath()
                .rectangle(0.0, 0.0, 100.0, 100.0).fill()
            assertNull(bounds(page))
        }
    }

    @Test
    fun disjointSuccessiveClipsRemainEmpty() {
        document { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).rectangle(0.0, 0.0, 10.0, 10.0).clip().endPath()
                .rectangle(20.0, 20.0, 10.0, 10.0).clip().endPath()
                .rectangle(0.0, 0.0, 100.0, 100.0).fill()
            assertNull(bounds(page))
        }
    }

    @Test
    fun imageBoundsRespectTheSameClipAsTextAndPaths() {
        document { pdf ->
            val image = PdfImageXObject(PdfStream(byteArrayOf(0)).apply {
                put(PdfName.Type, PdfName.XObject)
                put(PdfName.Subtype, PdfName.Image)
                put(PdfName.Width, PdfNumber(1))
                put(PdfName.Height, PdfNumber(1))
                put(PdfName.ColorSpace, PdfName.DeviceGray)
                put(PdfName.BitsPerComponent, PdfNumber(8))
            })
            val page = pdf.addNewPage()
            PdfCanvas(page).rectangle(10.0, 20.0, 30.0, 40.0).clip().endPath()
                .addXObjectWithTransformationMatrix(image, 100f, 0f, 0f, 100f, 0f, 0f)
            assertBounds(Rectangle(10f, 20f, 30f, 40f), bounds(page))
        }
    }

    @Test
    fun failedCallbackDoesNotLeaveClippingOnTheGeometry() {
        document { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).rectangle(10.0, 20.0, 30.0, 40.0).clip().endPath()
                .rectangle(0.0, 0.0, 100.0, 100.0).fill()
            val geometry = PdfFitGeometry()
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is PathRenderInfo && data.operation != PathRenderInfo.NO_OP) error("Callback failed")
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH)
            }
            assertTrue(runCatching { PdfFitGeometry.Processor(listener, geometry).processPageContent(page) }.isFailure)
            assertBounds(Rectangle(0f, 0f, 100f, 100f), geometry.visibleRectangle(Rectangle(0f, 0f, 100f, 100f)))
        }
    }

    @Test
    fun shadingContributesItsClipWithoutChangingTheContentOrState() {
        document { pdf ->
            val page = pdf.addNewPage()
            addShading(page.resources)
            page.newContentStreamAfter().setData(
                "q 100 200 50 60 re W n 10 0 0 20 0 0 cm /Sh1 sh Q 300 400 10 10 re f"
                    .toByteArray(Charsets.US_ASCII))
            val original = page.contentBytes
            assertBounds(Rectangle(100f, 200f, 210f, 210f), bounds(page))
            assertArrayEquals(original, page.contentBytes)
        }
    }

    @Test
    fun shadingBoundsAreTransformedBeforeIntersectingThePageSpaceClip() {
        document { pdf ->
            val page = pdf.addNewPage()
            addShading(page.resources, floatArrayOf(0f, 0f, 1f, 1f))
            page.newContentStreamAfter().setData(
                "100 200 50 60 re W n 100 0 0 100 90 190 cm /Sh1 sh".toByteArray(Charsets.US_ASCII))
            assertBounds(Rectangle(100f, 200f, 50f, 60f), bounds(page))
        }
    }

    @Test
    fun anUnboundedShadingUsesTheVisiblePageEnvelope() {
        document { pdf ->
            val page = pdf.addNewPage()
            page.cropBox = Rectangle(10f, 20f, 100f, 200f)
            addShading(page.resources)
            page.newContentStreamAfter().setData("/Sh1 sh".toByteArray(Charsets.US_ASCII))
            assertBounds(Rectangle(10f, 20f, 100f, 200f), bounds(page))
        }
    }

    @Test
    fun shadingInsideAFormUsesTheTransformedFormBoundary() {
        document { pdf ->
            val form = PdfFormXObject(Rectangle(0f, 0f, 20f, 30f))
            addShading(form.resources)
            form.pdfObject.setData("/Sh1 sh".toByteArray(Charsets.US_ASCII))
            val page = pdf.addNewPage()
            PdfCanvas(page).addXObjectAt(form, 100f, 200f)
            assertBounds(Rectangle(100f, 200f, 20f, 30f), bounds(page))
        }
    }

    @Test
    fun anEmptyShadingClipDoesNotAddVisibleBounds() {
        document { pdf ->
            val page = pdf.addNewPage()
            addShading(page.resources)
            page.newContentStreamAfter().setData("0 0 0 0 re W n /Sh1 sh".toByteArray(Charsets.US_ASCII))
            assertNull(bounds(page))
        }
    }

    private fun addShading(resources: PdfResources, box: FloatArray? = null) {
        resources.pdfObject.put(PdfName.Shading, PdfDictionary().apply {
            put(PdfName("Sh1"), PdfDictionary().apply {
                put(PdfName.ShadingType, PdfNumber(2))
                put(PdfName.ColorSpace, PdfName.DeviceRGB)
                put(PdfName.Coords, PdfArray(floatArrayOf(0f, 0f, 1f, 0f)))
                put(PdfName.Extend, PdfArray(listOf(PdfBoolean.TRUE, PdfBoolean.TRUE)))
                put(PdfName.Function, PdfDictionary().apply {
                    put(PdfName.FunctionType, PdfNumber(2))
                    put(PdfName.Domain, PdfArray(floatArrayOf(0f, 1f)))
                    put(PdfName.C0, PdfArray(floatArrayOf(0f, 0f, 0f)))
                    put(PdfName.C1, PdfArray(floatArrayOf(1f, 1f, 1f)))
                    put(PdfName.N, PdfNumber(1))
                })
                if (box != null) put(PdfName.BBox, PdfArray(box))
            })
        })
    }

    private fun document(test: (PdfDocument) -> Unit) {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use(test)
    }

    private fun bounds(page: PdfPage): Rectangle? {
        val geometry = PdfFitGeometry()
        var result: Rectangle? = null
        fun include(rect: Rectangle) {
            val visible = geometry.visibleRectangle(rect) ?: return
            result = result?.let { Rectangle.getCommonRectangle(it, visible) } ?: visible
        }
        val listener = object : IEventListener {
            override fun eventOccurred(data: IEventData?, type: EventType?) {
                when (data) {
                    is PathRenderInfo -> PdfFitGeometry.includePath(data, ::include)
                    is TextRenderInfo -> geometry.includeText(data, ::include)
                    is ImageRenderInfo -> {
                        val points = arrayOf(Vector(0f, 0f, 1f), Vector(1f, 0f, 1f), Vector(0f, 1f, 1f), Vector(1f, 1f, 1f))
                            .map { it.cross(data.imageCtm) }
                        val left = points.minOf { it.get(Vector.I1) }
                        val bottom = points.minOf { it.get(Vector.I2) }
                        include(Rectangle(left, bottom, points.maxOf { it.get(Vector.I1) } - left,
                            points.maxOf { it.get(Vector.I2) } - bottom))
                    }
                }
            }
            override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH, EventType.RENDER_TEXT, EventType.RENDER_IMAGE)
        }
        PdfFitGeometry.Processor(listener, geometry).processPageContent(page)
        return result
    }

    private fun assertBounds(expected: Rectangle, actual: Rectangle?) {
        val box = requireNotNull(actual)
        assertEquals(expected.left, box.left, .001f)
        assertEquals(expected.bottom, box.bottom, .001f)
        assertEquals(expected.right, box.right, .001f)
        assertEquals(expected.top, box.top, .001f)
    }
}
