package hu.reelee81.pdflabelprinting

import android.annotation.SuppressLint
import android.app.UiModeManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION_CODES
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.StrictMode
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AbsoluteSizeSpan
import android.util.AttributeSet
import android.util.Log
import android.util.Xml
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.annotation.WorkerThread
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.AppCompatCheckBox
import androidx.appcompat.widget.AppCompatImageButton
import androidx.appcompat.widget.AppCompatImageView
import androidx.constraintlayout.widget.ConstraintLayout.LayoutParams
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.content.edit
import androidx.core.graphics.createBitmap
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.core.view.MenuCompat
import androidx.core.widget.NestedScrollView
import androidx.core.widget.TextViewCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import androidx.window.layout.WindowMetricsCalculator
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.progressindicator.BaseProgressIndicator
import com.google.android.material.radiobutton.MaterialRadioButton
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textview.MaterialTextView
import com.itextpdf.io.image.ImageDataFactory
import com.itextpdf.kernel.colors.ColorConstants
import com.itextpdf.kernel.exceptions.BadPasswordException
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.geom.Rectangle
import com.itextpdf.kernel.geom.Vector
import com.itextpdf.kernel.pdf.CompressionConstants
import com.itextpdf.kernel.pdf.EncryptionConstants
import com.itextpdf.kernel.pdf.PdfArray
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.ReaderProperties
import com.itextpdf.kernel.pdf.WriterProperties
import com.itextpdf.kernel.pdf.canvas.PdfCanvas
import com.itextpdf.kernel.pdf.canvas.parser.EventType
import com.itextpdf.kernel.pdf.canvas.parser.data.IEventData
import com.itextpdf.kernel.pdf.canvas.parser.data.ImageRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.data.PathRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.data.TextRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.listener.IEventListener
import hu.reelee81.pdflabelprinting.databinding.ActivityMainBinding
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.StringReader
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Collections.newSetFromMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.CopyOnWriteArrayList
import java.util.Date
import java.util.Locale
import java.util.WeakHashMap
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import org.xmlpull.v1.XmlPullParser

class MainActivity : AppCompatActivity() {

    private companion object {
        const val PREFS_NAME_FRAGMENT = "PdfLabelPrintingPrefs"
        const val KEY_THEME_MODE = "theme_mode"
        const val KEY_ROWS = "rows"
        const val KEY_NORMAL_ROWS = "normal_rows"
        const val KEY_LABEL_ROWS = "label_rows"
        const val KEY_COLUMNS = "columns"
        const val KEY_NORMAL_COLUMNS = "normal_columns"
        const val KEY_LABEL_COLUMNS = "label_columns"
        const val KEY_MARGIN = "margin"
        const val KEY_NORMAL_MARGIN = "normal_margin"
        const val KEY_LABEL_MARGIN = "label_margin"
        const val KEY_ORIENTATION = "orientation"
        const val KEY_NORMAL_ORIENTATION = "normal_orientation"
        const val KEY_LABEL_ORIENTATION = "label_orientation"
        const val KEY_DRAW_FRAME = "draw_frame"
        const val KEY_NORMAL_DRAW_FRAME = "normal_draw_frame"
        const val KEY_LABEL_DRAW_FRAME = "label_draw_frame"
        const val KEY_SIG_POS_X = "sig_pos_x"
        const val KEY_NORMAL_SIG_POS_X = "normal_sig_pos_x"
        const val KEY_LABEL_SIG_POS_X = "label_sig_pos_x"
        const val KEY_SIG_POS_Y = "sig_pos_y"
        const val KEY_NORMAL_SIG_POS_Y = "normal_sig_pos_y"
        const val KEY_LABEL_SIG_POS_Y = "label_sig_pos_y"
        const val KEY_SCALE = "scale"
        const val KEY_NORMAL_SCALE = "normal_scale"
        const val KEY_LABEL_SCALE = "label_scale"
        const val KEY_FIT = "fit"
        const val KEY_NORMAL_FIT = "normal_fit"
        const val KEY_LABEL_FIT = "label_fit"
        const val KEY_BATCH_PAGE = "batch_page"
        const val KEY_NORMAL_BATCH_PAGE = "normal_batch_page"
        const val KEY_LABEL_BATCH_PAGE = "label_batch_page"
        const val KEY_PASSWORD_OUT = "password_out"
        const val KEY_NORMAL_PASSWORD_OUT = "normal_password_out"
        const val KEY_LABEL_PASSWORD_OUT = "label_password_out"
        const val KEY_FILE_NAME_TEMPLATE = "file_name_template"
        const val KEY_NORMAL_FILE_NAME_TEMPLATE = "normal_file_name_template"
        const val KEY_LABEL_FILE_NAME_TEMPLATE = "label_file_name_template"
        const val KEY_LAST_SIG_DPI_INDEX = "key_last_signature_dpi_index"
        const val KEY_LAST_SCAN_EFFECT = "key_last_scan_effect"
        const val KEY_LAST_GRAYSCALE = "key_last_grayscale_page"
        const val KEY_LAST_INNER_PDF_READER = "key_last_inner_pdf_reader"
        const val KEY_LAST_LOADED_PROFILE = "key_last_loaded_profile"
        const val KEY_RESTORE_LOCK_UNTIL_RELOAD = "key_restore_lock_until_reload"
        const val KEY_FIRST_RUN_INITIALIZED = "key_first_run_initialized"
        const val KEY_THEME_RESTORE_FIRST = "key_theme_restore_first"
        const val KEY_THEME_RESTORE_OFFSET = "key_theme_restore_offset"
        const val KEY_THEME_RESTORE_SELECTED_CSV = "key_theme_restore_selected_csv"
        const val KEY_THEME_RESTORE_NSV_Y = "key_theme_restore_nsv_y"
        const val KEY_THEME_RESTORE_ROTATION_CSV = "key_theme_restore_rotation_csv"
        const val KEY_BACKUP_SELECTED = "backup_selected"
        const val KEY_BACKUP_THUMB_FIRST = "backup_thumb_first"
        const val KEY_BACKUP_THUMB_OFFSET = "backup_thumb_offset"
        const val KEY_BACKUP_ROWS = "backup_rows"
        const val KEY_BACKUP_COLUMNS = "backup_columns"
        const val KEY_BACKUP_MARGIN = "backup_margin"
        const val KEY_BACKUP_ORIENTATION = "backup_orientation"
        const val KEY_BACKUP_DRAW_FRAME = "backup_draw_frame"
        const val KEY_BACKUP_SCALE = "backup_scale"
        const val KEY_BACKUP_FIT = "backup_fit"
        const val KEY_BACKUP_ROTATION = "backup_rotation"
        const val DEFAULT_SIG_POS_X_MM = 155
        const val DEFAULT_SIG_POS_Y_MM = 245

        private const val SOURCE_TEMP_NAME = "source_temp.pdf"
        private const val SOURCE_TEMP_WORK = "source_temp_work.pdf"
        private const val PLP_TEMP_NAME = "plp_temp.pdf"
        private const val SOURCE_TEMP_COPY_NAME = "source_temp_copy.pdf"
        private const val PLP_TEMP_COPY_NAME = "plp_temp_copy.pdf"
        private const val MAX_BASE_LEN = 251
        private const val MAX_INPUT = 100
        private const val KEEP_RECENT_EXPORTS = 0
        private const val MAX_IMG_W = 8411
        private const val MAX_IMG_H = 8411
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: PageItemsViewModel
    private lateinit var adapter: ThumbnailAdapter
    private lateinit var timeStamp: String
    private lateinit var pdfPickerLauncher: ActivityResultLauncher<Intent>
    private lateinit var pdfViewerLauncher: ActivityResultLauncher<Intent>
    private lateinit var progressDialog: AlertDialog
    private lateinit var signaturesDir: File
    private lateinit var signaturePickerLauncher: ActivityResultLauncher<Intent>
    private lateinit var numberOfRows: TextInputEditText
    private lateinit var numberOfColumns: TextInputEditText
    private lateinit var margin: TextInputEditText
    private lateinit var signaturePosX: TextInputEditText
    private lateinit var signaturePosY: TextInputEditText
    private lateinit var emptyPage: MaterialButton
    private lateinit var printPdf: MaterialButton
    private lateinit var savePdf: MaterialButton
    private lateinit var sendPdf: MaterialButton
    private lateinit var addSignature: MaterialButton
    private lateinit var portrait: MaterialRadioButton
    private lateinit var landscape: MaterialRadioButton
    private lateinit var drawFrameSwitch: SwitchMaterial
    private lateinit var scaleSwitch: SwitchMaterial
    private lateinit var fitSwitch: SwitchMaterial
    private lateinit var listStartButton: AppCompatImageButton
    private lateinit var listEndButton: AppCompatImageButton
    private lateinit var saveDocumentLauncher: ActivityResultLauncher<Intent>
    private lateinit var batchPage: TextInputEditText
    private lateinit var passwordOutCb: MaterialCheckBox

    private var pendingSaveNamedPath: String? = null
    private var pendingSaveNamedDisplayName: String? = null
    private var isLoadingSettingsProfile = false
    private var regenRequestedDuringProfileLoad = false
    private var nbColumnsValid = true
    private var nbRowsValid = true
    private var marginValid = true
    private var sigXValid = true
    private var sigYValid = true
    private var currentSigFile: File? = null
    private var selectedSigIndex = -1
    private var fastScroller: AlwaysVisibleFastScroller? = null
    private var orderDirty = false
    private var lastGlobalAllSelected: Boolean? = null
    private var lastGrantedViewUri: Uri? = null
    private var lastGrantedPkg: String? = null
    private var selectedDpiIndexForSignature = 0
    private var didRunNScrollColdStartFix = false
    private var isFirstCreate = true
    private var batchValid = true
    private var sourceRotation: IntArray = IntArray(0)
    private var restoreImeAfterBackground = false
    private var restoreImeAfterBackgroundEditTextId = View.NO_ID
    private var restoreImeAfterBackgroundWasActive = false
    private var foldableInfoJob: Job? = null
    private var isTabletLikeDevice: Boolean = false
    private var suppressRootScrollLayoutCallback: Boolean = false
    private var lastRootW: Int = -1
    private var lastRootH: Int = -1
    private var bottomPanelView: View? = null
    private var hasWindowFocusFlag: Boolean = true
    private var pendingRvUpdate: Boolean = false
    private var suppressNup: Boolean = true
    private var lastBuiltNupConfig: NupConfig? = null
    private var isUiBlockedByProgress: Boolean = false
    private var lastNightMask: Int = -1
    private var pendingUiModeRecreate: Boolean = false
    private var signaturePositionEditorDialog: AlertDialog? = null
    private var signaturePositionEditorRerender: (() -> Unit)? = null
    private var savedSoftInputModeForOverlay: Int? = null
    private var passwordOverlayOwnsSecureFlag = false
    private var pendingCacheCleanupAfterExternalReturn = false
    private var didPauseForExternalAction = false
    private var orientationLockPrevRequested: Int? = null
    private var uiModeRecreateScheduled: Boolean = false
    private var lastConfigSnapshotForDiff: Configuration? = null

    @Volatile private var isSigningCancelled: Boolean = false
    @Volatile private var isPlpRebuilding = false
    @Volatile private var clearSelectionOnNextRebuild = false
    @Volatile private var isFoldableDevice: Boolean = false
    @Volatile private var deferOrientationUnlockUntilThumbnailsReady: Boolean = false
    @Volatile private var deferredOrientationUnlockRequested: Boolean = false
    @Volatile private var reloadThumbnailsGeneration: Long = 0L

    private val prefsBackupLock = Any()
    private val rvHeightUpdateRunnable = Runnable {
        applyRvThumbnailsHeight()
    }

    private data class NupConfig(
        val rows: Int,
        val cols: Int,
        val marginMm: Int,
        val isLandscape: Boolean,
        val drawFrame: Boolean,
        val scaleIndividually: Boolean,
        val fitIndividually: Boolean
    )

    private val activeJobs = CopyOnWriteArrayList<Job>()
    private val plpSizedDialogs: MutableSet<AlertDialog> = newSetFromMap(WeakHashMap())

    private val savePrefsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data?.data != null) {
            val uri = result.data!!.data!!
            val job = lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val xml = exportAllSharedPreferencesXml()
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(xml.toByteArray(Charsets.UTF_8))
                        out.flush()
                    } ?: throw IOException(getString(R.string.output_stream_is_null))
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, getString(R.string.msg_prefs_saved_success), Toast.LENGTH_LONG).show()
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, getString(R.string.msg_prefs_save_failed, e.message), Toast.LENGTH_LONG).show()
                    }
                }
            }
            activeJobs.add(job)
            job.invokeOnCompletion { activeJobs.remove(job) }
        }
    }

    private val loadPrefsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data?.data != null) {
            val uri = result.data!!.data!!
            val job = lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val xml = contentResolver.openInputStream(uri)?.use { inp ->
                        inp.readBytes().toString(Charsets.UTF_8)
                    } ?: throw IOException(getString(R.string.input_stream_is_null))

                    importAllSharedPreferencesFromXml(xml)

                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, getString(R.string.msg_prefs_loaded_success), Toast.LENGTH_LONG).show()

                        val sp = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                        val profile = synchronized(prefsBackupLock) {
                            sp.getString(KEY_LAST_LOADED_PROFILE, "") ?: ""
                        }

                        when (profile) {
                            "normal" -> {
                                findViewById<Button>(R.id.load_normal_pages)?.performClick()
                            }
                            "label" -> {
                                findViewById<Button>(R.id.load_label_pages)?.performClick()
                            }
                            else -> {

                            }
                        }

                        invalidateOptionsMenu()
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, getString(R.string.msg_prefs_load_failed, e.message), Toast.LENGTH_LONG).show()
                    }
                }
            }
            activeJobs.add(job)
            job.invokeOnCompletion { activeJobs.remove(job) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        if (savedInstanceState == null) {
            clearCacheDir()
        }

        val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
        val theme = synchronized(prefsBackupLock) {
            prefs.getString(KEY_THEME_MODE, "system") ?: "system"
        }

        if (Build.VERSION.SDK_INT >= VERSION_CODES.S) {
            val uiModeManager = getSystemService(UI_MODE_SERVICE) as UiModeManager
            val appNightMode = when (theme) {
                "light" -> UiModeManager.MODE_NIGHT_NO
                "dark" -> UiModeManager.MODE_NIGHT_YES
                else -> UiModeManager.MODE_NIGHT_AUTO
            }
            uiModeManager.setApplicationNightMode(appNightMode)

            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        } else {
            val mode = when (theme) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
            AppCompatDelegate.setDefaultNightMode(mode)
        }

        super.onCreate(savedInstanceState)

        isFirstCreate = (savedInstanceState == null)

        // START Alternative DEBUG mode check
        val isDebug = try {
            (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        } catch (_: Exception) {
            false
        }

        if (isDebug) {
            StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy.Builder()
                    .detectAll()
                    .penaltyLog()
                    .build()
            )
            StrictMode.setVmPolicy(
                StrictMode.VmPolicy.Builder()
                    .detectLeakedClosableObjects()
                    .detectLeakedRegistrationObjects()
                    .penaltyLog()
                    .build()
            )
        }
        // STOP Alternative DEBUG mode check

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lastNightMask = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK

        val maxMetrics = WindowMetricsCalculator.getOrCreate().computeMaximumWindowMetrics(this)
        val density = resources.displayMetrics.density
        val wDp = maxMetrics.bounds.width() / density
        val hDp = maxMetrics.bounds.height() / density
        val maxSmallestDp = min(wDp, hDp)

        isTabletLikeDevice = (maxSmallestDp >= 600f)

        binding.rootScroll.addOnLayoutChangeListener { _, left, top, right, bottom, _, _, _, _ ->
            if (suppressRootScrollLayoutCallback) return@addOnLayoutChangeListener

            val w = right - left
            val h = bottom - top
            if (w == lastRootW && h == lastRootH) return@addOnLayoutChangeListener
            lastRootW = w
            lastRootH = h

            requestRvThumbnailsHeightUpdate()
        }

        requestRvThumbnailsHeightUpdate()


        run {
            val navColor = ContextCompat.getColor(this, R.color.app_background_color)
            SystemBarsCompat.applyNavBarColor(this, navColor)
        }

        setSupportActionBar(binding.toolbar)

        setThemedBackArrow()
        binding.toolbar.setNavigationOnClickListener { finishAndRemoveTask() }

        signaturesDir = File(filesDir, "Signatures")
        if (!signaturesDir.exists()) {
            signaturesDir.mkdirs()
        }

        val rvThumbnails: RecyclerView = findViewById(R.id.rv_thumbnails)
        numberOfRows = findViewById(R.id.number_of_rows)
        numberOfColumns = findViewById(R.id.number_of_columns)
        margin = findViewById(R.id.margin)
        batchPage = findViewById(R.id.batch_page)
        passwordOutCb = findViewById(R.id.password_out)
        emptyPage = findViewById(R.id.empty_page)
        val selectPdf: Button = findViewById(R.id.select_pdf)
        printPdf = findViewById(R.id.print_pdf)
        savePdf = findViewById(R.id.save_pdf_file)
        sendPdf = findViewById(R.id.send_pdf)
        addSignature = findViewById(R.id.add_signature)
        portrait = findViewById(R.id.portrait)
        landscape = findViewById(R.id.landscape)
        drawFrameSwitch = findViewById(R.id.drawframe)

        bottomPanelView = findViewById(R.id.bottom_panel)

        listStartButton = findViewById(R.id.list_start)
        listEndButton = findViewById(R.id.list_end)

        listStartButton.setOnClickListener {
            binding.rvThumbnails.scrollToPosition(0)
        }

        listEndButton.setOnClickListener {
            if (viewModel.pageItems.isNotEmpty()) {
                binding.rvThumbnails.scrollToPosition(viewModel.pageItems.size - 1)
            }
        }

        scaleSwitch = findViewById(R.id.scale)
        fitSwitch = findViewById(R.id.fit)
        fitSwitch.isEnabled = scaleSwitch.isChecked

        signaturePosX = findViewById(R.id.signature_position_x)
        signaturePosY = findViewById(R.id.signature_position_y)

        val addTimeBtn: ImageButton = findViewById(R.id.add_time)

        numberOfRows.filters    = arrayOf(InputFilter.LengthFilter(3), numberRangeFilterNoOp(1..100))
        numberOfColumns.filters = arrayOf(InputFilter.LengthFilter(3), numberRangeFilterNoOp(1..100))
        margin.filters          = arrayOf(InputFilter.LengthFilter(3), numberRangeFilterNoOp(0..100))
        batchPage.filters       = arrayOf(InputFilter.LengthFilter(3), numberRangeFilterNoOp(1..100))

        portrait.setOnCheckedChangeListener { _, checked ->
            updateSignatureInputFilters()
            if (checked) maybeRegeneratePlpOnSettingChange()
        }

        landscape.setOnCheckedChangeListener { _, checked ->
            updateSignatureInputFilters()
            if (checked) maybeRegeneratePlpOnSettingChange()
        }

        drawFrameSwitch.setOnCheckedChangeListener { _, _ ->
            maybeRegeneratePlpOnSettingChange()
        }

        scaleSwitch.setOnCheckedChangeListener { _, isChecked ->
            fitSwitch.isEnabled = isChecked
            maybeRegeneratePlpOnSettingChange()
        }

        fitSwitch.setOnCheckedChangeListener { _, _ ->
            maybeRegeneratePlpOnSettingChange()
        }

        setupRegenerateOnBlur(numberOfRows)
        setupRegenerateOnBlur(numberOfColumns)
        setupRegenerateOnBlur(margin)

        progressDialog = AlertDialog.Builder(this).create()

        viewModel = ViewModelProvider(this)[PageItemsViewModel::class.java]
        val pageItems = viewModel.pageItems

        loadSettings()

        timeStamp = System.currentTimeMillis().toString()

        pdfPickerLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                result.data?.data?.let { handlePdfUri(it) }
            }
        }

        pdfViewerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val editedUri = result.data
                ?.getStringExtra(PdfViewer.EXTRA_OUTPUT_URI)
                ?.toUri()

            if (result.resultCode == RESULT_OK && editedUri != null) {
                handleEditedPdfFromViewer(editedUri)
            } else {
                lifecycleScope.launch(Dispatchers.IO) {
                    cleanupCacheExceptTemps()
                }
            }
        }

        signaturePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val uri = result.data?.data
                uri?.let { copySignatureToAppDir(it) }
            }
        }

        saveDocumentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val uri = result.data?.data
                if (uri != null) {
                    val backupJob = lifecycleScope.launch {
                        backupSelectionState()
                    }
                    activeJobs.add(backupJob)
                    backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

                    showInProgress(getString(R.string.in_progress_save))
                    lockScreenOrientation()
                    val job = lifecycleScope.launch(Dispatchers.IO) {
                        try {
                            val srcPath = pendingSaveNamedPath
                            if (srcPath.isNullOrEmpty()) throw IllegalStateException(getString(R.string.temporary_pdf_not_found))
                            val srcFile = File(srcPath)
                            if (!srcFile.exists()) throw IllegalStateException(getString(R.string.temporary_pdf_not_found))

                            contentResolver.openOutputStream(uri)?.use { out ->
                                FileInputStream(srcFile).use { inp ->
                                    val buffer = ByteArray(16 * 1024)
                                    var read: Int
                                    while (inp.read(buffer).also { read = it } > 0) {
                                        out.write(buffer, 0, read)
                                    }
                                    out.flush()
                                }
                            } ?: throw IOException(getString(R.string.input_stream_is_null))

                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    this@MainActivity,
                                    getString(R.string.pdf_saved_successfully),
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    this@MainActivity,
                                    getString(R.string.failed_to_generate_pdf_with_msg, e.message),
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } finally {
                            runCatching { cleanupCacheExceptTemps() }

                            withContext(Dispatchers.Main) {
                                hideInProgressIfShown()
                                unlockScreenOrientation()
                                pendingSaveNamedPath = null
                                pendingSaveNamedDisplayName = null
                                maybeRunDeferredUiModeRecreate()
                            }
                        }
                    }
                    activeJobs.add(job)
                    job.invokeOnCompletion { activeJobs.remove(job) }
                } else {
                    pendingSaveNamedPath = null
                    pendingSaveNamedDisplayName = null
                    lifecycleScope.launch(Dispatchers.IO) { cleanupCacheExceptTemps() }
                    maybeRunDeferredUiModeRecreate()
                }
            } else {
                pendingSaveNamedPath = null
                pendingSaveNamedDisplayName = null
                lifecycleScope.launch(Dispatchers.IO) { cleanupCacheExceptTemps() }
                maybeRunDeferredUiModeRecreate()
            }
        }

        rvThumbnails.layoutManager = GridLayoutManager(this, 2)
        adapter = ThumbnailAdapter(
            pageItems,
            deleteListener = { pos -> deletePlpPageGroupAndMirrorSource(pos) },
            rotateLeftListener = { pos -> rotateLeftPlpPageGroupAndMirrorSource(pos) },
            clickListener = { position -> openPdfWithDriveOrOther(position) },
            selectionChanged = { _, _ -> updateButtonsState() }
        )
        rvThumbnails.adapter = adapter

        rvThumbnails.post {
            val lm = rvThumbnails.layoutManager as? GridLayoutManager ?: return@post

            val first = lm.findFirstVisibleItemPosition().takeIf { it != RecyclerView.NO_POSITION } ?: 0
            val last  = lm.findLastVisibleItemPosition().takeIf  { it != RecyclerView.NO_POSITION } ?: 0

            val start = (first - 4).coerceAtLeast(0)
            val end   = (last + 4).coerceAtMost(adapter.itemCount - 1)
            val r = start..end

            adapter.prefetchAroundVisible(this@MainActivity, r)
        }

        rvThumbnails.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val lm = rv.layoutManager as? GridLayoutManager ?: return
                val first = lm.findFirstVisibleItemPosition()
                val last = lm.findLastVisibleItemPosition()
                if (first != RecyclerView.NO_POSITION && last != RecyclerView.NO_POSITION) {
                    val start = (first - 4).coerceAtLeast(0)
                    val end   = (last + 4).coerceAtMost(adapter.itemCount - 1)
                    adapter.prefetchAroundVisible(this@MainActivity, start..end)
                }
            }
        })

        binding.rvThumbnails.setHasFixedSize(true)
        binding.rvThumbnails.itemAnimator = null

        fastScroller = AlwaysVisibleFastScroller(binding.rvThumbnails, this)
        fastScroller?.setEnabledWhen(viewModel.pageItems.isNotEmpty())

        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or
                    ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            private var userDragActive = false

            private var originalOrder: List<PageItem>? = null

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition

                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) {
                    return false
                }

                if (from != to) {
                    val moved = pageItems.removeAt(from)
                    pageItems.add(to, moved)
                    adapter.notifyItemMoved(from, to)
                    orderDirty = true
                }
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}

            override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(viewHolder, actionState)
                userDragActive = (actionState == ItemTouchHelper.ACTION_STATE_DRAG)

                if (userDragActive) {
                    val job = lifecycleScope.launch {
                        backupSelectionState()
                    }
                    activeJobs.add(job)
                    job.invokeOnCompletion { activeJobs.remove(job) }

                    try { fastScroller?.setTemporarilyDisabled(true) } catch (_: Exception) {}

                    if (originalOrder == null) {
                        originalOrder = ArrayList(pageItems)
                    }
                }

                try {
                    (findViewById<RecyclerView>(R.id.rv_thumbnails).parent as? ViewGroup)
                        ?.requestDisallowInterceptTouchEvent(userDragActive)
                } catch (_: Exception) {}
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                try { recyclerView.parent?.requestDisallowInterceptTouchEvent(false) } catch (_: Exception) {}

                val hasOrderActuallyChanged = orderDirty && originalOrder?.equals(pageItems) == false

                if (hasOrderActuallyChanged) {
                    val doPersist = {
                        if (orderDirty) {
                            persistPlpOrderToSourceTemp()
                            orderDirty = false
                        }
                        try { fastScroller?.setTemporarilyDisabled(false) } catch (_: Exception) {}
                        updateButtonsState()
                    }

                    val settleCheck = object : Runnable {
                        override fun run() {
                            if (userDragActive ||
                                recyclerView.scrollState != RecyclerView.SCROLL_STATE_IDLE ||
                                recyclerView.isComputingLayout
                            ) {
                                recyclerView.postDelayed(this, 16L)
                            } else {
                                doPersist()
                            }
                        }
                    }
                    recyclerView.post(settleCheck)

                } else {
                    orderDirty = false
                    try { fastScroller?.setTemporarilyDisabled(false) } catch (_: Exception) {}
                    updateButtonsState()
                }

                originalOrder = null
            }
        }).attachToRecyclerView(rvThumbnails)

        numberOfColumns.addTextChangedListener(SimpleTextWatcher { validateInputs() })
        numberOfRows.addTextChangedListener(SimpleTextWatcher { validateInputs() })
        margin.addTextChangedListener(SimpleTextWatcher { validateInputs() })
        signaturePosX.addTextChangedListener(SimpleTextWatcher { validateInputs() })
        signaturePosY.addTextChangedListener(SimpleTextWatcher { validateInputs() })
        batchPage.addTextChangedListener(SimpleTextWatcher { validateInputs() })

        emptyPage.setOnClickListener { addEmptyPageToSource() }
        selectPdf.setOnClickListener { launchSelectPdf() }
        printPdf.setOnClickListener { printNupPdf() }
        savePdf.setOnClickListener { saveNupPdf() }
        sendPdf.setOnClickListener { shareNupPdf() }
        addSignature.setOnClickListener { showSignatureDialog() }

        addTimeBtn.setOnClickListener { showTimestampDialog() }

        val saveNormalPages: Button = findViewById(R.id.save_normal_pages)
        val saveLabelPages: Button = findViewById(R.id.save_label_pages)
        saveNormalPages.setOnClickListener {
            saveSettings("normal")
            numberOfRows.clearFocus()
            numberOfColumns.clearFocus()
            margin.clearFocus()
            signaturePosX.clearFocus()
            signaturePosY.clearFocus()
            maybeRegeneratePlpOnSettingChange()
        }
        saveLabelPages.setOnClickListener {
            saveSettings("label")
            numberOfRows.clearFocus()
            numberOfColumns.clearFocus()
            margin.clearFocus()
            signaturePosX.clearFocus()
            signaturePosY.clearFocus()
            maybeRegeneratePlpOnSettingChange()
        }

        val normalPages: Button = findViewById(R.id.load_normal_pages)
        val labelPages: Button = findViewById(R.id.load_label_pages)
        normalPages.setOnClickListener {
            loadSettings("normal")
            maybeRegeneratePlpOnSettingChange()
        }
        labelPages.setOnClickListener {
            loadSettings("label")
            maybeRegeneratePlpOnSettingChange()
        }

        val intent = intent

        handleIncomingShareIntent(intent)
        setIntent(Intent())

        val bundleIndicesToSelect: Set<Int>? = savedInstanceState
            ?.getIntegerArrayList("state_selected_idx")
            ?.toSet()
            ?.takeIf { it.isNotEmpty() }

        savedInstanceState
            ?.getIntArray("state_source_rotation")
            ?.let { sourceRotation = it }

        runCatching {
            val sp = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)

            val restFirst: Int
            val restOffset: Int
            val csv: String
            val nsvY: Int
            val needLockAtStart: Boolean

            synchronized(prefsBackupLock) {
                restFirst = sp.getInt(KEY_THEME_RESTORE_FIRST, RecyclerView.NO_POSITION)
                restOffset = sp.getInt(KEY_THEME_RESTORE_OFFSET, 0)
                csv = sp.getString(KEY_THEME_RESTORE_SELECTED_CSV, "") ?: ""
                nsvY = sp.getInt(KEY_THEME_RESTORE_NSV_Y, -1)
                needLockAtStart = sp.getBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, false)
            }

            val hasRotationRestore = sp.contains(KEY_THEME_RESTORE_ROTATION_CSV)
            val rotationCsv = sp.getString(KEY_THEME_RESTORE_ROTATION_CSV, "") ?: ""
            val restoredRotation: IntArray? = if (hasRotationRestore) {
                if (rotationCsv.isNotEmpty()) {
                    rotationCsv.split(',').mapNotNull { it.toIntOrNull() }.toIntArray()
                } else {
                    IntArray(0)
                }
            } else null

            restoredRotation?.let { sourceRotation = it }

            val indicesToSelectPrefs: Set<Int>? = csv.split(',')
                .mapNotNull { it.toIntOrNull() }
                .toSet()
                .takeIf { it.isNotEmpty() }

            val indicesToSelect: Set<Int>? = indicesToSelectPrefs ?: bundleIndicesToSelect

            if (restFirst != RecyclerView.NO_POSITION || indicesToSelect != null || hasRotationRestore || nsvY >= 0) {
                synchronized(prefsBackupLock) {
                    sp.edit {
                        remove(KEY_THEME_RESTORE_FIRST)
                        remove(KEY_THEME_RESTORE_OFFSET)
                        remove(KEY_THEME_RESTORE_SELECTED_CSV)
                        remove(KEY_THEME_RESTORE_ROTATION_CSV)
                        remove(KEY_THEME_RESTORE_NSV_Y)
                    }
                }

                if (needLockAtStart) {
                    showInProgressUpdateUI(getString(R.string.in_progress_ui))
                    lockScreenOrientation()
                }

                reloadThumbnailsFromPlp(
                    targetIndex = restFirst.takeIf { it != RecyclerView.NO_POSITION },
                    targetOffsetPx = restOffset,
                    restorePrevious = false,
                    indicesToSelect = indicesToSelect,
                    releaseUiAtStart = false,
                    onStarted = {
                        hideInProgressIfShownUpdateUI()
                        unlockScreenOrientation()
                        synchronized(prefsBackupLock) {
                            val spLock = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                            spLock.edit { putBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, false) }
                        }
                    }
                )

                if (nsvY >= 0) {
                    val nsv = findViewById<NestedScrollView>(R.id.root_scroll)
                    nsv?.post { nsv.scrollTo(0, nsvY) }
                }
            } else {
                if (needLockAtStart) {
                    showInProgressUpdateUI(getString(R.string.in_progress_ui))
                    lockScreenOrientation()
                }

                reloadThumbnailsFromPlp(
                    onStarted = {
                        hideInProgressIfShownUpdateUI()
                        unlockScreenOrientation()
                        synchronized(prefsBackupLock) {
                            val spLock = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                            spLock.edit { putBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, false) }
                        }
                    }
                )
            }
        }.onFailure {
            val spLock = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            val needLock = synchronized(prefsBackupLock) {
                spLock.getBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, false)
            }
            if (needLock) {
                showInProgressUpdateUI(getString(R.string.in_progress_ui))
                lockScreenOrientation()
            }

            reloadThumbnailsFromPlp(
                onStarted = {
                    hideInProgressIfShownUpdateUI()
                    unlockScreenOrientation()
                    synchronized(prefsBackupLock) {
                        spLock.edit { putBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, false) }
                    }
                }
            )
        }

        updateButtonsState()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

                if (::binding.isInitialized) {
                    if (binding.overlayProgressDialog.isVisible || binding.overlayProgressDialogUpdateUi.isVisible) {
                        return
                    }

                    if (binding.overlayDialogSignaturePosition.isVisible) {
                        binding.overlayDialogSignaturePosition.performClick()
                        return
                    }

                    if (binding.overlayDialogSignatureChooser.isVisible) {
                        binding.overlayDialogSignatureChooser.performClick()
                        return
                    }

                    if (binding.overlayDialogPassword.isVisible) {
                        binding.overlayDialogPassword.performClick()
                        return
                    }

                    if (binding.overlayDialogTimestamp.isVisible) {
                        binding.overlayDialogTimestamp.performClick()
                        return
                    }

                    if (binding.overlayDialogBatteryOptimization.isVisible) {
                        binding.overlayDialogBatteryOptimization.performClick()
                        return
                    }

                    if (binding.overlayDialogMaxCoordinates.isVisible) {
                        binding.overlayDialogMaxCoordinates.performClick()
                        return
                    }
                }

                finishAndRemoveTask()
            }
        })
    }

    private fun clearCacheDir() {
        try {
            cacheDir.listFiles()?.forEach { file -> file.deleteRecursively() }
        } catch (_: Exception) { }
    }

    private fun sourceTempFile(): File = File(cacheDir, SOURCE_TEMP_NAME)
    private fun sourceWorkFile(): File = File(cacheDir, SOURCE_TEMP_WORK)
    private fun plpTempFile(): File = File(cacheDir, PLP_TEMP_NAME)

    private fun backupTempFilesBeforeLongOperation() {
        val sourceTemp = sourceTempFile()
        if (sourceTemp.exists()) {
            val sourceCopy = File(cacheDir, SOURCE_TEMP_COPY_NAME)
            runCatching {
                FileInputStream(sourceTemp).use { input ->
                    FileOutputStream(sourceCopy, false).use { output ->
                        input.copyTo(output)
                    }
                }
            }
        }

        val plpTemp = plpTempFile()
        if (plpTemp.exists()) {
            val plpCopy = File(cacheDir, PLP_TEMP_COPY_NAME)
            runCatching {
                FileInputStream(plpTemp).use { input ->
                    FileOutputStream(plpCopy, false).use { output ->
                        input.copyTo(output)
                    }
                }
            }
        }
    }

    private fun scheduleUiModeRecreate() {
        if (isFinishing || isDestroyed) return

        if (uiModeRecreateScheduled) return
        uiModeRecreateScheduled = true

        window.decorView.post {
            uiModeRecreateScheduled = false

            if (isFinishing || isDestroyed) {
                return@post
            }
            recreate()
        }
    }

    private fun maybeRunDeferredUiModeRecreate() {
        if (!pendingUiModeRecreate) return
        if (isUiBlockedByProgress) return
        if (orientationLockPrevRequested != null) return
        if (pendingSaveNamedPath != null) return

        pendingUiModeRecreate = false
        scheduleUiModeRecreate()
    }

    private fun recomputeTabletLikeFlag() {
        val maxMetrics = WindowMetricsCalculator.getOrCreate().computeMaximumWindowMetrics(this)
        val density = resources.displayMetrics.density
        val wDp = maxMetrics.bounds.width() / density
        val hDp = maxMetrics.bounds.height() / density
        val maxSmallestDp = min(wDp, hDp)
        isTabletLikeDevice = (maxSmallestDp >= 600f)
    }

    private fun reapplyPanelsMaxWidthFromResources() {
        val maxPxMain = resources.getDimensionPixelSize(R.dimen.dp_9999_main)
        val maxPxOverlay = resources.getDimensionPixelSize(R.dimen.dp_9999_overlay)

        listOf(binding.topPanel, binding.bottomPanel)
            .forEach { updateMatchConstraintMaxWidth(it, maxPxMain) }

        listOf(
            binding.overlayDialogPasswordPanel,
            binding.overlayDialogSignaturePositionPanel,
            binding.overlayDialogSignatureChooserPanel,
            binding.overlayDialogTimestampPanel,
            binding.overlayDialogBatteryOptimizationPanel,
            binding.overlayDialogMaxCoordinatesPanel,
            binding.overlayProgressDialogPanel,
            binding.overlayProgressDialogUpdateUiPanel
        ).forEach { updateMatchConstraintMaxWidth(it, maxPxOverlay) }
    }

    private fun updateMatchConstraintMaxWidth(view: View, maxWidthPx: Int) {
        val lp = view.layoutParams as? LayoutParams
            ?: return

        if (lp.matchConstraintMaxWidth != maxWidthPx) {
            lp.matchConstraintMaxWidth = maxWidthPx
            view.layoutParams = lp
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        val prevConfig = lastConfigSnapshotForDiff?.let { Configuration(it) } ?: Configuration(newConfig)
        lastConfigSnapshotForDiff = Configuration(newConfig)

        super.onConfigurationChanged(newConfig)

        recomputeTabletLikeFlag()

        reapplyPanelsMaxWidthFromResources()

        fastScroller?.refreshDisplayMetrics()

        requestRvThumbnailsHeightUpdate()

        val localeChanged = prevConfig.locales != newConfig.locales
        val fontScaleChanged = prevConfig.fontScale != newConfig.fontScale
        val layoutDirectionChanged = prevConfig.layoutDirection != newConfig.layoutDirection
        val keyboardChanged = prevConfig.keyboard != newConfig.keyboard
        val navigationChanged = prevConfig.navigation != newConfig.navigation
        val touchscreenChanged = prevConfig.touchscreen != newConfig.touchscreen
        val colorModeChanged =
            Build.VERSION.SDK_INT >= VERSION_CODES.O &&
                    prevConfig.colorMode != newConfig.colorMode
        val fontWeightAdjustmentChanged =
            Build.VERSION.SDK_INT >= VERSION_CODES.S &&
                    prevConfig.fontWeightAdjustment != newConfig.fontWeightAdjustment
        val mccChanged = prevConfig.mcc != newConfig.mcc
        val mncChanged = prevConfig.mnc != newConfig.mnc
        val grammaticalGenderChanged =
            Build.VERSION.SDK_INT >= VERSION_CODES.UPSIDE_DOWN_CAKE &&
                    prevConfig.grammaticalGender != newConfig.grammaticalGender

        val nonUiModeConfigChangeNeedsRecreate =
            localeChanged ||
                    fontScaleChanged ||
                    layoutDirectionChanged ||
                    keyboardChanged ||
                    navigationChanged ||
                    touchscreenChanged ||
                    colorModeChanged ||
                    fontWeightAdjustmentChanged ||
                    mccChanged ||
                    mncChanged ||
                    grammaticalGenderChanged

        val prevNightMask = lastNightMask
        val nightMask = newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK

        if (nightMask == Configuration.UI_MODE_NIGHT_UNDEFINED) {
            val rerender = signaturePositionEditorRerender

            if (::binding.isInitialized && binding.overlayDialogSignaturePosition.isVisible && rerender != null) {
                binding.root.post {
                    rerender.invoke()
                }
            }

            if (nonUiModeConfigChangeNeedsRecreate) {
                if (isUiBlockedByProgress || orientationLockPrevRequested != null) {
                    pendingUiModeRecreate = true
                } else {
                    scheduleUiModeRecreate()
                }
            }

            return
        }

        if (prevNightMask < 0) {
            lastNightMask = nightMask

            if (nonUiModeConfigChangeNeedsRecreate) {
                if (isUiBlockedByProgress || orientationLockPrevRequested != null) {
                    pendingUiModeRecreate = true
                } else {
                    scheduleUiModeRecreate()
                }
            }

            return
        }

        if (prevNightMask == Configuration.UI_MODE_NIGHT_UNDEFINED) {
            lastNightMask = nightMask

            if (nonUiModeConfigChangeNeedsRecreate) {
                if (isUiBlockedByProgress || orientationLockPrevRequested != null) {
                    pendingUiModeRecreate = true
                } else {
                    scheduleUiModeRecreate()
                }
            }

            return
        }

        val uiModeChanged = (nightMask != prevNightMask)
        if (uiModeChanged) {
            lastNightMask = nightMask

            window.decorView.post {
                if (isFinishing || isDestroyed) return@post

                val stableMask = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                if (stableMask == Configuration.UI_MODE_NIGHT_UNDEFINED) {
                    return@post
                }

                if (stableMask != nightMask) {
                    lastNightMask = stableMask
                    return@post
                }

                if (isUiBlockedByProgress || orientationLockPrevRequested != null) {
                    pendingUiModeRecreate = true
                } else {
                    scheduleUiModeRecreate()
                }
            }
        } else {
            val rerender = signaturePositionEditorRerender

            if (::binding.isInitialized && binding.overlayDialogSignaturePosition.isVisible && rerender != null) {
                binding.root.post {
                    rerender.invoke()
                }
            }

            if (nonUiModeConfigChangeNeedsRecreate) {
                if (isUiBlockedByProgress || orientationLockPrevRequested != null) {
                    pendingUiModeRecreate = true
                } else {
                    scheduleUiModeRecreate()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val selectedIdx = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }
        if (selectedIdx.isNotEmpty()) {
            outState.putIntegerArrayList("state_selected_idx", ArrayList(selectedIdx))
        }

        if (isChangingConfigurations) {
            runCatching {
                val lm = binding.rvThumbnails.layoutManager as? LinearLayoutManager
                val first = lm?.findFirstVisibleItemPosition() ?: RecyclerView.NO_POSITION
                val offset = if (first != RecyclerView.NO_POSITION) {
                    lm?.findViewByPosition(first)?.top ?: 0
                } else 0

                val nsv = findViewById<NestedScrollView>(R.id.root_scroll)
                val nsvY = nsv?.scrollY ?: -1

                val csv = selectedIdx.joinToString(",")
                val rotationCsv = sourceRotation.joinToString(",")

                val sp = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                synchronized(prefsBackupLock) {
                    sp.edit {
                        putInt(KEY_THEME_RESTORE_FIRST, first)
                        putInt(KEY_THEME_RESTORE_OFFSET, offset)
                        putString(KEY_THEME_RESTORE_SELECTED_CSV, csv)
                        putString(KEY_THEME_RESTORE_ROTATION_CSV, rotationCsv)
                        putInt(KEY_THEME_RESTORE_NSV_Y, nsvY)
                        putBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, true)
                    }
                }
            }.onFailure {
            }
        }
    }

    private fun lockScreenOrientation() {
        if (::binding.isInitialized && binding.overlayDialogPassword.isVisible) return
        if (orientationLockPrevRequested != null) return

        orientationLockPrevRequested = requestedOrientation
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
    }

    private fun unlockScreenOrientation() {

        if (deferOrientationUnlockUntilThumbnailsReady) {
            deferredOrientationUnlockRequested = true
            return
        }

        val prev = orientationLockPrevRequested ?: return
        orientationLockPrevRequested = null
        requestedOrientation = prev
    }

    private fun sourceTempPageCount(): Int {
        val f = sourceTempFile()
        if (!f.exists()) return 0
        return try { PdfDocument(rdr(f.absolutePath)).use { it.numberOfPages } } catch (_: Exception) { 0 }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)

        handleIncomingShareIntent(intent)

        setIntent(Intent())
    }

    private fun handleIncomingShareIntent(intent: Intent) {
        if (::binding.isInitialized && (
                    binding.overlayProgressDialog.isVisible ||
                            binding.overlayProgressDialogUpdateUi.isVisible
                    )
        ) {
            return
        }

        val action = intent.action

        val collected = LinkedHashSet<Uri>()

        fun tryCollectIfLikelyPdf(uri: Uri?) {
            if (uri == null) return

            val mt = try { contentResolver.getType(uri) } catch (_: Exception) { null }
            val mtLc = mt?.lowercase(Locale.ROOT)
            val nameLc = try { extractFileName(uri).lowercase(Locale.ROOT) } catch (_: Exception) { "" }

            val explicitNonPdf =
                (mtLc?.startsWith("image/") ?: false) ||
                        (mtLc?.startsWith("text/")  ?: false) ||
                        (mtLc?.startsWith("audio/") ?: false) ||
                        (mtLc?.startsWith("video/") ?: false)
            if (explicitNonPdf) return

            val isPdfMime = mtLc?.contains("pdf") ?: false
            val isPdfName = nameLc.endsWith(".pdf")

            val isUnknownApp = when (mtLc) {
                null -> true
                "application/octet-stream" -> true
                else -> mtLc.startsWith("application/")
            }

            val looksPdf = isPdfMime || isPdfName || isUnknownApp
            if (looksPdf) collected.add(uri)
        }

        fun processUris(uris: List<Uri>) {
            if (uris.isEmpty()) return

            val startProcessing = {
                val backupJob = lifecycleScope.launch {
                    backupSelectionState()
                }
                activeJobs.add(backupJob)
                backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

                if (uris.size == 1) {
                    handlePdfUri(uris.first())
                } else {
                    handlePdfUrisBatch(uris)
                }
            }

            val decor = window?.decorView
            val isWarmStart = try { decor?.isShown == true && hasWindowFocus() } catch (_: Exception) { false }
            if (isWarmStart) {
                startProcessing()
            } else {
                decor?.post(startProcessing) ?: startProcessing()
            }
        }

        when (action) {
            Intent.ACTION_VIEW -> {
                tryCollectIfLikelyPdf(intent.data)
                intent.clipData?.let { cd ->
                    for (i in 0 until cd.itemCount) tryCollectIfLikelyPdf(cd.getItemAt(i)?.uri)
                }
            }
            Intent.ACTION_SEND -> {
                tryCollectIfLikelyPdf(intent.getParcelableCompat(Intent.EXTRA_STREAM))
                intent.clipData?.let { cd ->
                    for (i in 0 until cd.itemCount) tryCollectIfLikelyPdf(cd.getItemAt(i)?.uri)
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val list = intent.getParcelableArrayListCompat(Intent.EXTRA_STREAM)
                if (!list.isNullOrEmpty()) {
                    for (u in list) tryCollectIfLikelyPdf(u)
                } else {
                    val cd = intent.clipData
                    if (cd != null && cd.itemCount > 0) {
                        for (i in 0 until cd.itemCount) tryCollectIfLikelyPdf(cd.getItemAt(i)?.uri)
                    } else {
                        tryCollectIfLikelyPdf(intent.getParcelableCompat(Intent.EXTRA_STREAM))
                    }
                }
            }
        }

        if (collected.isNotEmpty()) {
            processUris(collected.toList())
            return
        }

        if (collected.isEmpty()) {
            when (action) {
                Intent.ACTION_VIEW -> {
                    val single = intent.data
                    if (single != null) {
                        val mtLc = try { contentResolver.getType(single)?.lowercase(Locale.ROOT) } catch (_: Exception) { null }
                        val nameLc = try { extractFileName(single).lowercase(Locale.ROOT) } catch (_: Exception) { "" }
                        if (isSupportedImageMime(mtLc) || isSupportedImageFileName(nameLc)) {
                            processUris(listOf(single))
                            return
                        } else {
                            val looksImageByMime = (mtLc?.startsWith("image/") == true)
                            if (looksImageByMime) {
                                Toast.makeText(this@MainActivity, getString(R.string.unsupported_image), Toast.LENGTH_LONG).show()
                                return
                            }
                        }
                    }
                }
                Intent.ACTION_SEND -> {
                    val single = intent.getParcelableCompat(Intent.EXTRA_STREAM)
                    if (single != null) {
                        val mtLc = try { contentResolver.getType(single)?.lowercase(Locale.ROOT) } catch (_: Exception) { null }
                        val nameLc = try { extractFileName(single).lowercase(Locale.ROOT) } catch (_: Exception) { "" }
                        if (isSupportedImageMime(mtLc) || isSupportedImageFileName(nameLc)) {
                            processUris(listOf(single))
                            return
                        } else {
                            val looksImageByMime = (mtLc?.startsWith("image/") == true)
                            if (looksImageByMime) {
                                Toast.makeText(this@MainActivity, getString(R.string.unsupported_image), Toast.LENGTH_LONG).show()
                                return
                            }
                        }
                    }
                }
            }
        }
    }

    private fun handlePdfUrisBatch(uris: List<Uri>) {
        if (uris.isEmpty()) return

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val selectedIdx = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

        val oldPer = run {
            val last = lastBuiltNupConfig ?: currentNupConfigFromInputs()
            (last.rows.coerceAtLeast(1)) * (last.cols.coerceAtLeast(1))
        }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val oldPageCount = sourceTempPageCount()

                val selectedSrcPages: Set<Int> = if (selectedIdx.isNotEmpty() && oldPageCount > 0) {
                    buildSet {
                        selectedIdx.forEach { g ->
                            val start = g * oldPer + 1
                            val end = min(oldPageCount, start + oldPer - 1)
                            for (p in start..end) add(p)
                        }
                    }
                } else emptySet()

                fun isBadPassword(t: Throwable): Boolean {
                    if (t is BadPasswordException) return true
                    val msg = t.message?.lowercase().orEmpty()
                    return msg.contains("bad user password") || msg.contains("bad password")
                }

                var progressStarted = false

                for (uri in uris) {
                    val tempSrc = File(cacheDir, "${timeStamp}_${extractFileName(uri)}")
                    try {
                        contentResolver.openInputStream(uri)?.use { inputStream ->
                            FileOutputStream(tempSrc).use { outputStream ->
                                val buffer = ByteArray(4096)
                                var bytesRead: Int
                                while (inputStream.read(buffer).also { bytesRead = it } > 0) {
                                    outputStream.write(buffer, 0, bytesRead)
                                }
                            }
                        } ?: throw IOException(getString(R.string.input_stream_is_null))

                        var passwordBytes: ByteArray? = null
                        var attempt = 0

                        while (true) {
                            val canOpen = try {
                                PdfDocument(rdr(tempSrc.absolutePath, passwordBytes)).use { }
                                true
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                if (!isBadPassword(e)) throw e
                                false
                            }

                            if (canOpen) break

                            if (progressStarted) {
                                withContext(Dispatchers.Main) {
                                    hideInProgressIfShown()
                                    unlockScreenOrientation()
                                }
                                progressStarted = false
                            }

                            val entered: String? = withContext(Dispatchers.Main) {
                                promptForPdfPassword(showError = (attempt > 0))
                            }

                            if (entered.isNullOrEmpty()) {
                                withContext(Dispatchers.Main) {
                                    hideInProgressIfShown()
                                    unlockScreenOrientation()
                                }
                                tempSrc.delete()
                                return@launch
                            }

                            passwordBytes = entered.toByteArray(Charsets.UTF_8)
                            attempt++
                        }

                        if (!progressStarted) {
                            withContext(Dispatchers.Main) {
                                showInProgress(getString(R.string.in_progress_opening))
                                lockScreenOrientation()
                            }
                            progressStarted = true
                        }

                        appendPdfToSourceTemp(tempSrc, passwordBytes)

                    } finally {
                        runCatching { tempSrc.delete() }
                    }
                }

                createTempPdfInternal()

                withContext(Dispatchers.Main) {
                    resetThumbDocKey("handlePdfUrisBatch")

                    val per = perGroup()
                    val indicesToSelectAfter: Set<Int> =
                        if (selectedSrcPages.isNotEmpty())
                            selectedSrcPages.map { p -> (p - 1) / per }.toSet()
                        else emptySet()

                    val onReloadStarted: () -> Unit = {
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }

                    reloadThumbnailsFromPlp(
                        targetIndex = null,
                        targetOffsetPx = 0,
                        restorePrevious = true,
                        indicesToSelect = indicesToSelectAfter,
                        releaseUiAtStart = false,
                        onStarted = onReloadStarted
                    )

                    updateButtonsState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.error_loading_pdf_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun isTouchInsideView(ev: MotionEvent, view: View): Boolean {
        val location = IntArray(2)
        view.getLocationInWindow(location)

        val left = location[0].toFloat()
        val top = location[1].toFloat()
        val right = left + view.width
        val bottom = top + view.height

        if (ev.x in left..<right && ev.y in top..<bottom) {
            return true
        }

        view.getLocationOnScreen(location)

        val screenLeft = location[0].toFloat()
        val screenTop = location[1].toFloat()
        val screenRight = screenLeft + view.width
        val screenBottom = screenTop + view.height

        return ev.rawX in screenLeft..<screenRight && ev.rawY in screenTop..<screenBottom
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::binding.isInitialized && binding.overlayDialogPassword.isVisible) {
            return super.dispatchTouchEvent(ev)
        }

        if (ev.action == MotionEvent.ACTION_DOWN) {
            val view = currentFocus
            if (view is EditText) {
                val blockingIds = setOf(
                    R.id.number_of_rows,
                    R.id.number_of_columns,
                    R.id.margin,
                    R.id.batch_page,
                    R.id.signature_position_x,
                    R.id.signature_position_y,
                    R.id.file_name
                )
                if (view.id in blockingIds) {
                    if (!isTouchInsideView(ev, view)) {
                        view.clearFocus()

                        run {
                            val root = findViewById<View>(android.R.id.content)
                            if (root != null) {
                                val prevFocusable = root.isFocusableInTouchMode
                                root.isFocusableInTouchMode = true
                                root.requestFocus()
                                root.post {
                                    try {
                                        root.isFocusableInTouchMode = prevFocusable
                                    } catch (_: Exception) { }
                                }
                            }
                        }

                        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.hideSoftInputFromWindow(view.windowToken, 0)

                        return true
                    }
                }
            }
        }

        var shouldHideKeyboard = false
        var targetWindowToken: IBinder? = null

        var focusedBefore: View? = null

        if (ev.action == MotionEvent.ACTION_UP) {
            currentFocus?.let { focusedView ->
                if (focusedView is EditText) {
                    if (!isTouchInsideView(ev, focusedView)) {
                        shouldHideKeyboard = true
                        targetWindowToken = focusedView.windowToken
                        focusedBefore = focusedView
                    }
                }
            }
        }

        val handled = super.dispatchTouchEvent(ev)

        if (shouldHideKeyboard) {
            window?.decorView?.post {
                try {
                    focusedBefore?.let { fv ->
                        if (fv.isFocused) {
                            fv.clearFocus()
                        }
                    }

                    run {
                        val root = findViewById<View>(android.R.id.content)
                        if (root != null) {
                            val prevFocusable = root.isFocusableInTouchMode
                            root.isFocusableInTouchMode = true
                            root.requestFocus()
                            root.post {
                                try {
                                    root.isFocusableInTouchMode = prevFocusable
                                } catch (_: Exception) { }
                            }
                        }
                    }

                    val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                    val token = targetWindowToken ?: window?.decorView?.windowToken
                    if (token != null) {
                        imm.hideSoftInputFromWindow(token, 0)
                    }
                } catch (_: Exception) { }
            }
        }

        return handled
    }

    private fun closeEditingAndHideKeyboardNoJump(et: EditText) {
        try {
            if (et.isFocused) {
                et.clearFocus()
            }

            run {
                val root = findViewById<View>(android.R.id.content)
                if (root != null) {
                    val prevFocusable = root.isFocusableInTouchMode
                    root.isFocusableInTouchMode = true
                    root.requestFocus()
                    root.post {
                        try {
                            root.isFocusableInTouchMode = prevFocusable
                        } catch (_: Exception) { }
                    }
                }
            }

            window?.decorView?.post {
                try {
                    val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                    val token = et.windowToken ?: window?.decorView?.windowToken
                    if (token != null) {
                        imm.hideSoftInputFromWindow(token, 0)
                    }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    private fun setupEnterClosesEditTextAndHidesKeyboard(et: EditText) {
        et.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN

            if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_NEXT ||
                isEnter
            ) {
                closeEditingAndHideKeyboardNoJump(et)
                true
            } else {
                false
            }
        }
    }

    private fun clearAnyEditTextFocusAfterRecreate() {
        try {
            var token: IBinder? = null

            val focused = currentFocus
            if (focused is EditText) {
                token = focused.windowToken
                if (focused.isFocused) {
                    focused.clearFocus()
                }
            }

            run {
                val root = findViewById<View>(android.R.id.content)
                if (root != null) {
                    val prevFocusable = root.isFocusableInTouchMode
                    root.isFocusableInTouchMode = true
                    root.requestFocus()
                    root.post {
                        try {
                            root.isFocusableInTouchMode = prevFocusable
                        } catch (_: Exception) { }
                    }
                }
            }

            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            val t = token ?: window?.decorView?.windowToken
            if (t != null) {
                imm.hideSoftInputFromWindow(t, 0)
            }
        } catch (_: Exception) { }
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        window?.decorView?.post {
            try {
                clearAnyEditTextFocusAfterRecreate()
            } catch (_: Exception) { }
        }
    }

    private fun numberRangeFilterNoOp(range: IntRange) = InputFilter { src, start, end, dest, dStart, dEnd ->
        val newText = dest.take(dStart).toString() + src.subSequence(start, end) + dest.drop(dEnd).toString()
        if (newText.isEmpty()) return@InputFilter null
        val v = newText.toIntOrNull()
        if (v != null && v in range) null else dest.subSequence(dStart, dEnd)
    }

    private fun updateSignatureInputFilters() {
        signaturePosX.filters = arrayOf(InputFilter.LengthFilter(3))
        signaturePosY.filters = arrayOf(InputFilter.LengthFilter(3))

        validateInputs()
    }

    private fun deleteDir(dir: File?): Boolean {
        if (dir != null && dir.isDirectory) {
            val children = dir.list()
            if (children != null) for (child in children) if (!deleteDir(File(dir, child))) return false
            return dir.delete()
        } else if (dir != null && dir.isFile) {
            return dir.delete()
        }
        return false
    }

    private fun showMaxCoordinatesAlert(maxXi: Int, maxYi: Int) {
        val overlay = binding.overlayDialogMaxCoordinates
        val panel = binding.overlayDialogMaxCoordinatesPanel

        panel.removeAllViews()
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_max_coordinates, panel, false)
        panel.addView(dialogView)

        overlay.visibility = View.VISIBLE

        overlay.setOnClickListener {
            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)
        }
        panel.setOnClickListener {
        }

        dialogView.findViewById<MaterialTextView>(R.id.dmc_text)?.text =
            getString(R.string.max_coordinates_x_y_mm, maxXi, maxYi)

        val btnOk = dialogView.findViewById<Button>(R.id.dmc_btn_ok)

        btnOk?.setOnClickListener {
            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)
        }
    }

    private fun refPxForSignatureDpi(idx: Int): Float {
        return when (idx) {
            0 -> 1190f
            1 -> 2480f
            else -> 1190f
        }
    }

    private fun currentSignatureRefPx(): Float = refPxForSignatureDpi(selectedDpiIndexForSignature)

    @SuppressLint("RtlHardcoded")
    private fun showSignatureDialog() {
        if (viewModel.pageItems.none { it.isSelected }) {
            Toast.makeText(this, getString(R.string.select_a_page), Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch(Dispatchers.Main) {
            val signatureFiles = withContext(Dispatchers.IO) {
                (signaturesDir.listFiles { file ->
                    file.isFile &&
                            file.name.startsWith("sign_") &&
                            file.name.endsWith(".png", ignoreCase = true)
                }?.toList() ?: emptyList()).sortedBy { it.lastModified() }
            }

            val sigDisplayNames = signatureFiles.map { file ->
                file.name.removePrefix("sign_").removeSuffix(".png").replace('_', ' ')
            }.toTypedArray()

            selectedSigIndex = -1

            val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            val lastDpiSaved = synchronized(prefsBackupLock) {
                prefs.getInt(KEY_LAST_SIG_DPI_INDEX, 0).coerceIn(0, 1)
            }
            selectedDpiIndexForSignature = lastDpiSaved

            val overlay = binding.overlayDialogSignatureChooser
            val panel = binding.overlayDialogSignatureChooserPanel
            panel.removeAllViews()
            val dialogView = LayoutInflater.from(this@MainActivity).inflate(R.layout.dialog_signature_chooser, panel, false)
            panel.addView(dialogView)
            overlay.visibility = View.VISIBLE
            overlay.bringToFront()

            overlay.setOnClickListener {
                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)
            }
            panel.setOnClickListener {
            }

            val listView = dialogView.findViewById<ListView>(R.id.sic_listview)

            var applyScanEffect = synchronized(prefsBackupLock) {
                prefs.getBoolean(KEY_LAST_SCAN_EFFECT, false)
            }
            var applyGrayscalePage = synchronized(prefsBackupLock) {
                prefs.getBoolean(KEY_LAST_GRAYSCALE, false)
            }

            var overrideXmm: Float? = null
            var overrideYmm: Float? = null

            var dpiSelectedIndex = selectedDpiIndexForSignature

            run {
                data class RowViews(
                    val container: LinearLayout,
                    val text: MaterialTextView,
                    val rightGroup: LinearLayout?,
                    val radio: MaterialRadioButton?,
                    val edit: AppCompatImageButton?,
                    val scanCheck: MaterialCheckBox?,
                    val type: Int
                )

                val customAdapter = object : BaseAdapter() {
                    override fun getCount(): Int = sigDisplayNames.size + 4

                    override fun getItem(position: Int): Any =
                        when (position) {
                            0 -> getString(R.string.dpi_144)
                            1 -> getString(R.string.dpi_300)
                            2 -> getString(R.string.scan_effect)
                            3 -> getString(R.string.print_page_grayscale)
                            else -> sigDisplayNames[position - 4]
                        }

                    override fun getItemId(position: Int): Long = position.toLong()

                    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                        val isDpiRow = (position == 0 || position == 1)
                        val isScanRow = (position == 2)
                        val isGrayRow = (position == 3)
                        val isSignatureRow = (position >= 4)

                        val desiredType = when {
                            isDpiRow -> 0
                            isScanRow || isGrayRow -> 1
                            else -> 2
                        }

                        val row = if (convertView == null || ((convertView.tag as? RowViews)?.type != desiredType)) {
                            val container = LinearLayout(parent.context).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.WRAP_CONTENT
                                )

                                val padH = parent.resources.getDimensionPixelSize(R.dimen.dp_16)
                                val padV = parent.resources.getDimensionPixelSize(R.dimen.dp_12)
                                setPadding(
                                    padH,
                                    padV,
                                    padH - (padH - parent.resources.getDimensionPixelSize(R.dimen.dp_12)),
                                    padV
                                )
                                isClickable = true
                                isFocusable = true
                            }

                            val tv = MaterialTextView(parent.context).apply {
                                layoutParams = LinearLayout.LayoutParams(
                                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                                )
                                textAlignment = View.TEXT_ALIGNMENT_GRAVITY
                                gravity = Gravity.LEFT
                                TextViewCompat.setTextAppearance(
                                    this, R.style.TextAppearance_PdfLabelPrinting_ListItem
                                )
                            }

                            if (isScanRow || isGrayRow) {
                                val rightGroup = LinearLayout(parent.context).apply {
                                    orientation = LinearLayout.HORIZONTAL
                                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                                    layoutParams = LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                    ).apply {
                                        gravity = Gravity.RIGHT
                                    }
                                    isBaselineAligned = false
                                }

                                val chk = MaterialCheckBox(parent.context).apply {
                                    layoutParams = LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                    ).apply {
                                        gravity = Gravity.RIGHT
                                    }
                                    contentDescription = null
                                    background = null
                                    setPadding(0, 0, 0, 0)

                                    isUseMaterialThemeColors = false
                                    buttonDrawable = AppCompatResources.getDrawable(context, R.drawable.ic_checkbox)
                                    buttonTintList = AppCompatResources.getColorStateList(context, R.color.ic_checkbox_filename_color)

                                    isChecked = applyScanEffect

                                    isClickable = false
                                    isFocusable = false

                                    minWidth = 0
                                    minHeight = 0
                                }

                                run {
                                    val rbProbe = MaterialRadioButton(parent.context)
                                    val rbW = (rbProbe.buttonDrawable?.intrinsicWidth ?: 0)
                                    val chkW = (chk.buttonDrawable?.intrinsicWidth ?: 0)
                                    val extraEnd = (rbW - chkW)
                                    if (extraEnd > 0) {
                                        rightGroup.setPadding(0, 0, extraEnd, 0)
                                    }
                                }

                                rightGroup.addView(chk)
                                container.addView(tv)
                                container.addView(rightGroup)

                                container.tag = RowViews(
                                    container = container,
                                    text = tv,
                                    rightGroup = rightGroup,
                                    radio = null,
                                    edit = null,
                                    scanCheck = chk,
                                    type = 1
                                )
                                container
                            } else if (isDpiRow) {
                                val rightGroup = LinearLayout(parent.context).apply {
                                    orientation = LinearLayout.HORIZONTAL
                                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                                    layoutParams = LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                    ).apply {
                                        gravity = Gravity.RIGHT
                                    }
                                    isBaselineAligned = false
                                }

                                val rb = MaterialRadioButton(parent.context).apply {
                                    layoutParams = LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                    ).apply {
                                        gravity = Gravity.RIGHT
                                    }
                                    isClickable = false
                                    isFocusable = false
                                    setPadding(0, 0, 0, 0)
                                    minWidth = 0
                                    minHeight = 0
                                }

                                rightGroup.addView(rb)
                                container.addView(tv)
                                container.addView(rightGroup)

                                container.tag = RowViews(
                                    container = container,
                                    text = tv,
                                    rightGroup = rightGroup,
                                    radio = rb,
                                    edit = null,
                                    scanCheck = null,
                                    type = 0
                                )
                                container
                            } else {
                                val rightGroup = LinearLayout(parent.context).apply {
                                    orientation = LinearLayout.HORIZONTAL
                                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                                    layoutParams = LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                    ).apply {
                                        gravity = Gravity.RIGHT
                                    }
                                    isBaselineAligned = false
                                }

                                val rb = MaterialRadioButton(parent.context).apply {
                                    layoutParams = LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                    ).apply {
                                        gravity = Gravity.RIGHT
                                    }
                                    isClickable = false
                                    isFocusable = false
                                    setPadding(0, 0, 0, 0)
                                    minWidth = 0
                                    minHeight = 0
                                }

                                val editBtn = AppCompatImageButton(parent.context).apply {
                                    layoutParams = LinearLayout.LayoutParams(
                                        ViewGroup.LayoutParams.WRAP_CONTENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                    ).apply {
                                        leftMargin = 0
                                        gravity = Gravity.RIGHT
                                        gravity = Gravity.CENTER_VERTICAL
                                    }
                                    setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_edit_24))
                                    contentDescription = null
                                    background = null
                                    isFocusable = false
                                    setPadding(0, 0, 0, 0)
                                }

                                rightGroup.addView(rb)
                                rightGroup.addView(editBtn)
                                container.addView(tv)
                                container.addView(rightGroup)

                                container.tag = RowViews(
                                    container = container,
                                    text = tv,
                                    rightGroup = rightGroup,
                                    radio = rb,
                                    edit = editBtn,
                                    scanCheck = null,
                                    type = 2
                                )
                                container
                            }
                        } else convertView

                        val holder = row.tag as RowViews

                        holder.text.text = when {
                            isDpiRow && position == 0 -> getString(R.string.dpi_144)
                            isDpiRow -> getString(R.string.dpi_300)
                            isScanRow -> getString(R.string.scan_effect)
                            isGrayRow -> getString(R.string.print_page_grayscale)
                            else -> sigDisplayNames[position - 4]
                        }

                        run {
                            val checkedPos = listView.checkedItemPosition
                            if (isSignatureRow) {
                                holder.radio?.isEnabled = true

                                holder.radio?.isChecked = (position == checkedPos)
                                val onePageSelected = (viewModel.pageItems.count { it.isSelected } == 1)
                                val isThisSigSelected = (position == checkedPos)
                                val canEdit = onePageSelected && isThisSigSelected
                                holder.edit?.isEnabled = canEdit

                                holder.edit?.setOnClickListener {
                                    if (!canEdit) return@setOnClickListener

                                    val singleIdx = viewModel.pageItems
                                        .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }
                                        .firstOrNull() ?: return@setOnClickListener

                                    lifecycleScope.launch(Dispatchers.Main) {
                                        val sigFile = signatureFiles[position - 4]
                                        val (pxW, pxH) = withContext(Dispatchers.IO) {
                                            readImageBounds(sigFile.absolutePath)
                                        }

                                        if (pxW <= 0 || pxH <= 0) {
                                            Toast.makeText(this@MainActivity, getString(R.string.signature_image_invalid), Toast.LENGTH_LONG).show()
                                            return@launch
                                        }

                                        val isLand = landscape.isChecked
                                        val a4Wmm  = if (isLand) 297f else 210f
                                        val a4Hmm  = if (isLand) 210f else 297f
                                        val refAxisMm = if (isLand) a4Hmm else a4Wmm
                                        val mmPerSigPx = refAxisMm / refPxForSignatureDpi(dpiSelectedIndex)
                                        val imgWmm = pxW * mmPerSigPx
                                        val imgHmm = pxH * mmPerSigPx

                                        val maxXf = a4Wmm - imgWmm
                                        val maxYf = a4Hmm - imgHmm
                                        val maxXi = floor(maxXf).toInt()
                                        val maxYi = floor(maxYf).toInt()

                                        if (maxXf < 0f || maxYf < 0f) {
                                            showMaxCoordinatesAlert(maxXi, maxYi)
                                            return@launch
                                        }

                                        runCatching {
                                            openSignaturePositionEditor(
                                                signatureFile = sigFile,
                                                plpPageIndex = singleIdx
                                            ) { xmm, ymm ->
                                                if (xmm != null && ymm != null) {
                                                    overrideXmm = xmm
                                                    overrideYmm = ymm
                                                }
                                            }
                                        }.onFailure {
                                            Toast.makeText(this@MainActivity, getString(R.string.editor_open_error), Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            } else if (isScanRow) {
                                holder.scanCheck?.isChecked = applyScanEffect
                            } else if (isGrayRow) {
                                holder.scanCheck?.isChecked = applyGrayscalePage
                            } else if (isDpiRow) {
                                holder.radio?.isChecked = (dpiSelectedIndex == position)
                            }
                        }

                        holder.container.setOnClickListener {
                            if (isDpiRow) {
                                dpiSelectedIndex = position
                                selectedDpiIndexForSignature = position
                                synchronized(prefsBackupLock) {
                                    prefs.edit {
                                        putInt(KEY_LAST_SIG_DPI_INDEX, position)
                                    }
                                }
                                (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                            } else if (isScanRow) {
                                applyScanEffect = !applyScanEffect
                                (row.tag as RowViews).scanCheck?.isChecked = applyScanEffect
                                synchronized(prefsBackupLock) {
                                    prefs.edit {
                                        putBoolean(KEY_LAST_SCAN_EFFECT, applyScanEffect)
                                    }
                                }
                                (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                            } else if (isGrayRow) {
                                applyGrayscalePage = !applyGrayscalePage
                                (row.tag as RowViews).scanCheck?.isChecked = applyGrayscalePage
                                synchronized(prefsBackupLock) {
                                    prefs.edit {
                                        putBoolean(KEY_LAST_GRAYSCALE, applyGrayscalePage)
                                    }
                                }
                                (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                            } else {
                                listView.setItemChecked(position, true)
                                (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                                listView.performItemClick(row, position, listView.getItemIdAtPosition(position))
                            }
                        }

                        return row
                    }
                }

                listView.adapter = customAdapter
                listView.choiceMode = ListView.CHOICE_MODE_SINGLE
            }

            val btnNew = dialogView.findViewById<Button>(R.id.sic_new)
            val btnRemove = dialogView.findViewById<Button>(R.id.sic_remove)
            val btnOk = dialogView.findViewById<Button>(R.id.sic_ok)
            val btnCancel = dialogView.findViewById<Button>(R.id.sic_cancel)

            btnNew.setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/png"
                }
                signaturePickerLauncher.launch(intent)

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)
            }

            btnRemove.isEnabled = false
            btnRemove.setOnClickListener {
                val checkedPosition = listView.checkedItemPosition
                if (checkedPosition != ListView.INVALID_POSITION && checkedPosition >= 4) {
                    val job = lifecycleScope.launch(Dispatchers.IO) {
                        val fileToDelete = signatureFiles[checkedPosition - 4]
                        val deleted = fileToDelete.delete()
                        withContext(Dispatchers.Main) {
                            if (deleted) {
                                overlay.visibility = View.GONE
                                overlay.setOnClickListener(null)

                                showSignatureDialog()
                            } else {
                                Toast.makeText(this@MainActivity, getString(R.string.failed_to_delete_signature), Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    activeJobs.add(job)
                    job.invokeOnCompletion { activeJobs.remove(job) }
                }
            }

            btnOk.isEnabled = false
            btnOk.setOnClickListener {
                val pos = listView.checkedItemPosition
                if (pos == ListView.INVALID_POSITION || pos < 4) return@setOnClickListener

                val sigFile = signatureFiles[pos - 4]

                val xmmFromEditor = overrideXmm
                val ymmFromEditor = overrideYmm

                val xStr = signaturePosX.text?.toString()?.trim().orEmpty()
                val yStr = signaturePosY.text?.toString()?.trim().orEmpty()
                val inputXmm = xmmFromEditor ?: (if (xStr.isEmpty()) 0f else xStr.toFloatOrNull())
                val inputYmm = ymmFromEditor ?: (if (yStr.isEmpty()) 0f else yStr.toFloatOrNull())

                if (inputXmm == null || inputYmm == null) {
                    Toast.makeText(this@MainActivity, getString(R.string.enter_value_0_100), Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

                lifecycleScope.launch(Dispatchers.Main) {
                    val (pxW, pxH) = withContext(Dispatchers.IO) {
                        readImageBounds(sigFile.absolutePath)
                    }

                    if (pxW <= 0 || pxH <= 0) {
                        Toast.makeText(this@MainActivity, getString(R.string.signature_image_invalid), Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    val isLand = landscape.isChecked
                    val a4Wmm  = if (isLand) 297f else 210f
                    val a4Hmm  = if (isLand) 210f else 297f
                    val refAxisMm = if (isLand) a4Hmm else a4Wmm
                    val mmPerSigPx = refAxisMm / refPxForSignatureDpi(dpiSelectedIndex)
                    val imgWmm = pxW * mmPerSigPx
                    val imgHmm = pxH * mmPerSigPx

                    val maxXf = a4Wmm - imgWmm
                    val maxYf = a4Hmm - imgHmm
                    val maxXi = floor(maxXf).toInt()
                    val maxYi = floor(maxYf).toInt()

                    if (inputXmm !in 0f..maxXf || inputYmm !in 0f..maxYf) {
                        currentSigFile = null

                        signaturePosX.filters = arrayOf(InputFilter.LengthFilter(3))
                        signaturePosY.filters = arrayOf(InputFilter.LengthFilter(3))

                        overlay.visibility = View.GONE
                        overlay.setOnClickListener(null)

                        window?.decorView?.post {
                            showMaxCoordinatesAlert(maxXi, maxYi)
                        }
                        return@launch
                    }

                    signSelectedPagesOnSourceTemp(
                        signatureFilePath = sigFile.absolutePath,
                        inputXMM = inputXmm,
                        inputYMM = inputYmm,
                        applyScanEffect = applyScanEffect,
                        applyGrayscalePage = applyGrayscalePage
                    )

                    overlay.visibility = View.GONE
                    overlay.setOnClickListener(null)
                }
            }

            listView.setOnItemClickListener { _, _, position, _ ->
                if (position >= 4) currentSigFile = signatureFiles[position - 4]

                btnRemove.isEnabled = (position >= 4)
                btnOk.isEnabled     = false

                lifecycleScope.launch(Dispatchers.Main) {
                    if (position >= 4) {
                        val file = currentSigFile
                        val (pxW, pxH) = withContext(Dispatchers.IO) {
                            readImageBounds(file!!.absolutePath)
                        }

                        if (pxW > 0 && pxH > 0) {
                            signaturePosX.filters = arrayOf(InputFilter.LengthFilter(3))
                            signaturePosY.filters = arrayOf(InputFilter.LengthFilter(3))
                        }

                        btnOk.isEnabled = true

                        (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                    } else {
                        (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()

                        btnOk.isEnabled = false
                    }
                }
            }

            btnCancel.setOnClickListener {

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)
            }
        }
    }

    private class DraggableSignatureView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null
    ) : AppCompatImageView(context, attrs) {

        var minLeft: Int = 0
        var minTop: Int = 0
        var maxLeft: Int = Int.MAX_VALUE
        var maxTop: Int = Int.MAX_VALUE

        var onMoved: ((left: Int, top: Int) -> Unit)? = null

        private var dX = 0f
        private var dY = 0f

        private var downXRelToParent = 0f
        private var downYRelToParent = 0f

        private val clickSlop = ViewConfiguration.get(context).scaledTouchSlop

        private var disallowingParentIntercept = false

        private fun forceAllowParentIntercept() {
            if (!disallowingParentIntercept) return
            disallowingParentIntercept = false
            try {
                parent?.requestDisallowInterceptTouchEvent(false)
            } catch (_: Exception) {
            }
        }

        fun updatePosition(left: Int, top: Int) {
            layoutParams = (layoutParams as FrameLayout.LayoutParams).apply {
                leftMargin = left
                topMargin = top
            }
            requestLayout()
            onMoved?.invoke(left, top)
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            fun parentLocationOnScreen(): Pair<Int, Int> {
                val loc = IntArray(2)
                (parent as? View)?.getLocationOnScreen(loc)
                return loc[0] to loc[1]
            }

            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val lp = layoutParams as FrameLayout.LayoutParams
                    val (parentX, parentY) = parentLocationOnScreen()

                    dX = ev.rawX - parentX - lp.leftMargin
                    dY = ev.rawY - parentY - lp.topMargin
                    downXRelToParent = ev.rawX - parentX
                    downYRelToParent = ev.rawY - parentY

                    disallowingParentIntercept = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val (parentX, parentY) = parentLocationOnScreen()

                    val wantedLeft = (ev.rawX - parentX - dX).toInt()
                    val wantedTop  = (ev.rawY - parentY - dY).toInt()

                    val clampedLeft = wantedLeft.coerceIn(minLeft, maxLeft)
                    val clampedTop  = wantedTop.coerceIn(minTop,  maxTop)
                    updatePosition(clampedLeft, clampedTop)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    forceAllowParentIntercept()

                    val (parentX, parentY) = parentLocationOnScreen()
                    val dx = abs((ev.rawX - parentX) - downXRelToParent)
                    val dy = abs((ev.rawY - parentY) - downYRelToParent)
                    if (dx <= clickSlop && dy <= clickSlop) {
                        performClick()
                    }
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    forceAllowParentIntercept()
                    return true
                }
            }
            return super.onTouchEvent(ev)
        }

        override fun onDetachedFromWindow() {
            forceAllowParentIntercept()
            super.onDetachedFromWindow()
        }

        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            if (!hasWindowFocus) {
                forceAllowParentIntercept()
            }
            super.onWindowFocusChanged(hasWindowFocus)
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }
    }

    @SuppressLint("RtlHardcoded")
    private fun openSignaturePositionEditor(
        signatureFile: File,
        plpPageIndex: Int,
        onResult: (Float?, Float?) -> Unit
    ) {
        val ctx = this

        val overlay = binding.overlayDialogSignaturePosition
        val panel = binding.overlayDialogSignaturePositionPanel
        panel.removeAllViews()
        val dialogView = LayoutInflater.from(ctx).inflate(R.layout.dialog_signature_position, panel, false)
        panel.addView(dialogView)
        overlay.visibility = View.VISIBLE
        overlay.bringToFront()

        panel.setOnClickListener {
        }

        signaturePositionEditorDialog = null
        signaturePositionEditorRerender = null

        val btnCancel = dialogView.findViewById<MaterialButton>(R.id.sp_btn_cancel)
        val btnOk = dialogView.findViewById<MaterialButton>(R.id.sp_btn_ok)

        val spThumb = dialogView.findViewById<AppCompatImageView>(R.id.sp_thumbnail)
        val thumbParent = spThumb.parent as ViewGroup
        val indexInParent = thumbParent.indexOfChild(spThumb)
        thumbParent.removeView(spThumb)

        val scroller = NestedScrollView(ctx).apply {
            layoutParams = when (thumbParent) {
                is LinearLayout -> LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    0,
                    1f
                )
                else -> ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            isFillViewport = true
            clipToPadding = true
            clipChildren = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            isVerticalScrollBarEnabled = true
        }
        thumbParent.addView(scroller, indexInParent)

        val stage = FrameLayout(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(0, 0, 0, 0)
            isClickable = true
            isFocusable = true
            clipToPadding = true
            clipChildren = true
        }
        scroller.addView(stage)

        var inner: FrameLayout? = null

        val pageView = spThumb.apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

        val sigView = DraggableSignatureView(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            isClickable = true
            isFocusable = true
        }

        val isLand = landscape.isChecked
        val a4Wmm = if (isLand) 297f else 210f
        val a4Hmm = if (isLand) 210f else 297f

        val initXmm = signaturePosX.text?.toString()?.trim()?.toFloatOrNull() ?: 0f
        val initYmm = signaturePosY.text?.toString()?.trim()?.toFloatOrNull() ?: 0f

        var okReady = false
        var pageLeft = 0
        var pageTop = 0
        var pxPerMMX = 0f
        var pxPerMMY = 0f
        var currentLeft = 0
        var currentTop = 0

        var allowedMaxXmm = 0f
        var allowedMaxYmm = 0f

        var lastPageBitmap: Bitmap? = null
        var lastSigBitmap: Bitmap? = null
        var lastRenderedAvailW = -1

        var layoutRerenderRunnable: Runnable? = null
        var layoutListener: View.OnLayoutChangeListener? = null

        val finished = AtomicBoolean(false)

        fun dismissWithResult(xmm: Float?, ymm: Float?) {
            if (!finished.compareAndSet(false, true)) return

            signaturePositionEditorDialog = null
            signaturePositionEditorRerender = null

            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)

            layoutListener?.let { ll ->
                stage.removeOnLayoutChangeListener(ll)
                scroller.removeOnLayoutChangeListener(ll)
                dialogView.removeOnLayoutChangeListener(ll)
            }

            layoutRerenderRunnable?.let { rr ->
                stage.removeCallbacks(rr)
            }

            runCatching {
                pageView.setImageDrawable(null)
                lastPageBitmap?.let { if (!it.isRecycled) it.recycle() }
                lastPageBitmap = null
            }

            runCatching {
                sigView.setImageDrawable(null)
                lastSigBitmap?.let { if (!it.isRecycled) it.recycle() }
                lastSigBitmap = null
            }

            onResult(xmm, ymm)
        }

        btnCancel.setOnClickListener {
            dismissWithResult(null, null)
        }
        btnOk.setOnClickListener {
            if (!okReady) {
                Toast.makeText(ctx, getString(R.string.in_progress_signature_editing), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val leftWithin = (currentLeft - pageLeft).toFloat()
            val topWithin  = (currentTop  - pageTop).toFloat()
            val outXmmRaw = leftWithin / pxPerMMX
            val outYmmRaw = topWithin  / pxPerMMY

            val outXmm = outXmmRaw.coerceIn(0f, allowedMaxXmm)
            val outYmm = outYmmRaw.coerceIn(0f, allowedMaxYmm)

            dismissWithResult(outXmm, outYmm)
        }

        fun requestRender(keepCurrentPosition: Boolean) {
            scroller.post {
                if (overlay.visibility != View.VISIBLE) return@post

                var availW = stage.width
                if (availW <= 0) availW = scroller.width
                if (availW <= 0) availW = thumbParent.width
                if (availW <= 0) availW = dialogView.width
                if (availW <= 0) availW = panel.width
                if (availW <= 0) availW = overlay.width
                if (availW <= 0) availW = 1

                if (keepCurrentPosition && availW == lastRenderedAvailW) {
                    return@post
                }
                lastRenderedAvailW = availW

                val carryXmm = if (keepCurrentPosition && okReady && pxPerMMX > 0f && pxPerMMY > 0f) {
                    val leftWithin = (currentLeft - pageLeft).toFloat()
                    (leftWithin / pxPerMMX).coerceAtLeast(0f)
                } else {
                    initXmm
                }

                val carryYmm = if (keepCurrentPosition && okReady && pxPerMMX > 0f && pxPerMMY > 0f) {
                    val topWithin = (currentTop - pageTop).toFloat()
                    (topWithin / pxPerMMY).coerceAtLeast(0f)
                } else {
                    initYmm
                }

                okReady = false

                val pageSize = if (isLand) PageSize.A4.rotate() else PageSize.A4
                val pageAspect = pageSize.width / pageSize.height

                val contentW = lastRenderedAvailW.coerceAtLeast(1)
                val contentH = max(1, floor(contentW / pageAspect).toInt())

                runCatching {
                    pageView.setImageDrawable(null)
                    lastPageBitmap?.let { if (!it.isRecycled) it.recycle() }
                    lastPageBitmap = null
                }
                runCatching {
                    sigView.setImageDrawable(null)
                    lastSigBitmap?.let { if (!it.isRecycled) it.recycle() }
                    lastSigBitmap = null
                }

                val plp = plpTempFile()
                if (!plp.exists()) {
                    Toast.makeText(ctx, getString(R.string.temporary_pdf_not_found), Toast.LENGTH_LONG).show()
                    dismissWithResult(null, null)
                    return@post
                }

                val pageBmp = kotlin.run {
                    var bmp: Bitmap? = null
                    try {
                        ParcelFileDescriptor.open(plp, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                            PdfRenderer(pfd).use { renderer ->
                                if (plpPageIndex !in 0 until renderer.pageCount) return@use
                                renderer.openPage(plpPageIndex).use { page ->
                                    val b = createBitmap(contentW, contentH, Bitmap.Config.ARGB_8888)
                                    val sx = contentW.toFloat() / page.width.toFloat()
                                    val sy = contentH.toFloat() / page.height.toFloat()
                                    val mat = Matrix().apply { postScale(sx, sy) }
                                    page.render(b, null, mat, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    bmp = b
                                }
                            }
                        }
                    } catch (_: Exception) { }
                    bmp
                }

                if (pageBmp == null) {
                    Toast.makeText(ctx, getString(R.string.failed_to_open_pdf_with_msg, "render"), Toast.LENGTH_LONG).show()
                    dismissWithResult(null, null)
                    return@post
                }

                if (inner == null) {
                    inner = FrameLayout(ctx).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            pageBmp.width,
                            pageBmp.height,
                            Gravity.CENTER
                        )
                        clipChildren = true
                        clipToPadding = true

                        val bg = ContextCompat.getColor(ctx, R.color.signature_position_pdf_bg)
                        setBackgroundColor(bg)
                    }
                    stage.addView(inner)
                } else {
                    inner.layoutParams = (inner.layoutParams as FrameLayout.LayoutParams).apply {
                        width = pageBmp.width
                        height = pageBmp.height
                        gravity = Gravity.CENTER
                    }
                }

                if (pageView.parent !== inner) {
                    (pageView.parent as? ViewGroup)?.removeView(pageView)
                    inner.addView(
                        pageView,
                        FrameLayout.LayoutParams(pageBmp.width, pageBmp.height, Gravity.CENTER)
                    )
                } else {
                    pageView.layoutParams = (pageView.layoutParams as FrameLayout.LayoutParams).apply {
                        width = pageBmp.width
                        height = pageBmp.height
                        gravity = Gravity.CENTER
                    }
                }

                pageView.setImageBitmap(pageBmp)
                lastPageBitmap = pageBmp
                pageView.requestLayout()

                val sigBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(signatureFile.absolutePath, sigBounds)

                val refAxisPx = if (isLand) pageBmp.height else pageBmp.width
                val desiredSigW = max(1, floor(sigBounds.outWidth  * (refAxisPx / currentSignatureRefPx())).toInt())
                val desiredSigH = max(1, floor(sigBounds.outHeight * (refAxisPx / currentSignatureRefPx())).toInt())

                fun calcInSampleSize(sw0: Int, sh0: Int, dw: Int, dh: Int): Int {
                    var sample = 1
                    val halfW = sw0 / 2
                    val halfH = sh0 / 2
                    while (halfW / sample >= dw && halfH / sample >= dh) sample *= 2
                    return sample.coerceAtLeast(1)
                }
                val sample = calcInSampleSize(sigBounds.outWidth, sigBounds.outHeight, desiredSigW, desiredSigH)
                val sigBmp = BitmapFactory.decodeFile(signatureFile.absolutePath, BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                })

                if (sigBmp == null) {
                    Toast.makeText(ctx, getString(R.string.signature_image_invalid), Toast.LENGTH_LONG).show()
                    dismissWithResult(null, null)
                    return@post
                }

                if (sigView.parent !== inner) {
                    (sigView.parent as? ViewGroup)?.removeView(sigView)
                    inner.addView(
                        sigView,
                        FrameLayout.LayoutParams(desiredSigW, desiredSigH).apply { gravity = Gravity.TOP or Gravity.LEFT }
                    )
                } else {
                    sigView.layoutParams = (sigView.layoutParams as FrameLayout.LayoutParams).apply {
                        width = desiredSigW
                        height = desiredSigH
                    }
                }

                sigView.setImageBitmap(sigBmp)
                lastSigBitmap = sigBmp
                sigView.alpha = 1f
                sigView.visibility = View.VISIBLE
                sigView.bringToFront()
                sigView.requestLayout()

                pxPerMMX = pageBmp.width.toFloat() / a4Wmm
                pxPerMMY = pageBmp.height.toFloat() / a4Hmm

                val refAxisMm = if (isLand) a4Hmm else a4Wmm
                val mmPerSigPx = refAxisMm / currentSignatureRefPx()
                val imgWmm = sigBounds.outWidth  * mmPerSigPx
                val imgHmm = sigBounds.outHeight * mmPerSigPx
                val rawMaxXmm = (a4Wmm - imgWmm).coerceAtLeast(0f)
                val rawMaxYmm = (a4Hmm - imgHmm).coerceAtLeast(0f)
                allowedMaxXmm = floor(rawMaxXmm)
                allowedMaxYmm = floor(rawMaxYmm)
                val allowedMaxLeftPx = floor(allowedMaxXmm * pxPerMMX).toInt()
                val allowedMaxTopPx  = floor(allowedMaxYmm * pxPerMMY).toInt()

                val initialLeftWithin = (carryXmm * pxPerMMX).coerceIn(0f, allowedMaxLeftPx.toFloat())
                val initialTopWithin  = (carryYmm * pxPerMMY).coerceIn(0f, allowedMaxTopPx.toFloat())

                pageLeft = 0
                pageTop  = 0

                currentLeft = initialLeftWithin.toInt()
                currentTop  = initialTopWithin.toInt()

                sigView.minLeft = 0
                sigView.minTop  = 0

                sigView.maxLeft = allowedMaxLeftPx
                sigView.maxTop  = allowedMaxTopPx

                sigView.onMoved = { l, t ->
                    currentLeft = l
                    currentTop  = t
                }

                sigView.updatePosition(currentLeft, currentTop)

                okReady = true
            }
        }

        signaturePositionEditorRerender = {
            requestRender(true)
        }

        dialogView.post {
            requestRender(false)
        }

        layoutRerenderRunnable = Runnable {

            if (overlay.visibility != View.VISIBLE) return@Runnable
            requestRender(true)
        }

        layoutListener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->

            if (overlay.visibility != View.VISIBLE) return@OnLayoutChangeListener

            val wNow = stage.width
            if (wNow <= 0) return@OnLayoutChangeListener
            if (wNow == lastRenderedAvailW) return@OnLayoutChangeListener

            val rr = layoutRerenderRunnable
            stage.removeCallbacks(rr)
            stage.postDelayed(rr, 60)
        }

        stage.addOnLayoutChangeListener(layoutListener)
        scroller.addOnLayoutChangeListener(layoutListener)
        dialogView.addOnLayoutChangeListener(layoutListener)

        overlay.setOnClickListener {
            dismissWithResult(null, null)
        }
    }

    private fun readImageBounds(path: String): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        return (opts.outWidth to opts.outHeight)
    }

    private fun copySignatureToAppDir(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { inputStream ->
                var fileName = extractFileName(uri)
                if (!fileName.startsWith("sign_")) fileName = "sign_$fileName"
                if (!fileName.endsWith(".png", ignoreCase = true)) {
                    fileName = fileName.substringBeforeLast('.') + ".png"
                }

                val targetFile = File(signaturesDir, fileName)
                var uniqueFile = targetFile
                var counter = 1
                while (uniqueFile.exists()) {
                    val baseName = fileName.substringBeforeLast('.')
                    val extension = fileName.substringAfterLast('.', "png")
                    uniqueFile = File(signaturesDir, "${baseName}_${counter}.$extension"); counter++
                }

                FileOutputStream(uniqueFile).use { outputStream -> inputStream.copyTo(outputStream) }
                showSignatureDialog()
            }
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.error_copying_signature_with_msg, e.message), Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        super.onPause()

        try {
            if (!isChangingConfigurations) {
                val v = currentFocus
                if (v is EditText && v.isFocused) {
                    restoreImeAfterBackground = true
                    restoreImeAfterBackgroundEditTextId = v.id

                    restoreImeAfterBackgroundWasActive = try {
                        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.isActive(v)
                    } catch (_: Exception) {
                        true
                    }
                } else {
                    restoreImeAfterBackground = false
                    restoreImeAfterBackgroundEditTextId = View.NO_ID
                    restoreImeAfterBackgroundWasActive = false
                }
            } else {
                restoreImeAfterBackground = false
                restoreImeAfterBackgroundEditTextId = View.NO_ID
                restoreImeAfterBackgroundWasActive = false
            }
        } catch (_: Exception) { }

        val longOpRunning = runCatching {
            isUiBlockedByProgress ||
                    (::binding.isInitialized && (binding.overlayProgressDialog.isVisible || binding.overlayProgressDialogUpdateUi.isVisible))
        }.getOrDefault(false)

        if (!longOpRunning) {
            saveCurrentSettings()
        }

        if (pendingCacheCleanupAfterExternalReturn) {
            didPauseForExternalAction = true
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)

        hasWindowFocusFlag = hasFocus

        if (!hasFocus) {
            try {
                binding.rvThumbnails.parent?.requestDisallowInterceptTouchEvent(false)
            } catch (_: Exception) {
            }
        }

        if (hasFocus) {
            try {
                if (restoreImeAfterBackground && restoreImeAfterBackgroundWasActive) {
                    val v = findViewById<View>(restoreImeAfterBackgroundEditTextId)
                    if (v is EditText && v.isFocused) {
                        window?.decorView?.post {
                            try {
                                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                                imm.showSoftInput(v, 0)
                            } catch (_: Exception) { }
                        }
                    }
                }
            } catch (_: Exception) { }

            restoreImeAfterBackground = false
            restoreImeAfterBackgroundEditTextId = View.NO_ID
            restoreImeAfterBackgroundWasActive = false

            if (pendingRvUpdate) {
                pendingRvUpdate = false
                requestRvThumbnailsHeightUpdate()
            }

            window?.decorView?.post {
                if (isFinishing || isDestroyed) return@post
                maybeRunDeferredUiModeRecreate()
            }
        }
    }

    override fun onDestroy() {

        runCatching {
            if (::binding.isInitialized) {
                binding.overlayProgressDialog.visibility = View.GONE
                binding.overlayProgressDialogUpdateUi.visibility = View.GONE
            }
        }.onFailure {
        }

        signaturePositionEditorDialog?.let { dlg ->
            if (dlg.isShowing) dlg.dismiss()
        }
        signaturePositionEditorDialog = null
        signaturePositionEditorRerender = null
        saveCurrentSettings()
        (findViewById<RecyclerView>(R.id.rv_thumbnails).adapter as? ThumbnailAdapter)?.close()
        if (!isChangingConfigurations) clearCacheDir()
        super.onDestroy()
    }

    private fun snapshotInitialPrefsIfNeeded() {
        val sp = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)

        synchronized(prefsBackupLock) {
            if (sp.getBoolean(KEY_FIRST_RUN_INITIALIZED, false)) return

            sp.edit {
                putString(KEY_ROWS, "1")
                putString(KEY_NORMAL_ROWS, "1")
                putString(KEY_LABEL_ROWS, "2")
                putString(KEY_COLUMNS, "1")
                putString(KEY_NORMAL_COLUMNS, "1")
                putString(KEY_LABEL_COLUMNS, "2")
                putString(KEY_BATCH_PAGE, "20")
                putString(KEY_NORMAL_BATCH_PAGE, "20")
                putString(KEY_LABEL_BATCH_PAGE, "20")
                putBoolean(KEY_SCALE, false)
                putBoolean(KEY_NORMAL_SCALE, false)
                putBoolean(KEY_LABEL_SCALE, true)
                putBoolean(KEY_FIT, false)
                putBoolean(KEY_NORMAL_FIT, false)
                putBoolean(KEY_LABEL_FIT, false)
                putString(KEY_MARGIN, "0")
                putString(KEY_NORMAL_MARGIN, "0")
                putString(KEY_LABEL_MARGIN, "2")
                putBoolean(KEY_ORIENTATION, true)
                putBoolean(KEY_NORMAL_ORIENTATION, true)
                putBoolean(KEY_LABEL_ORIENTATION, true)
                putBoolean(KEY_DRAW_FRAME, false)
                putBoolean(KEY_NORMAL_DRAW_FRAME, false)
                putBoolean(KEY_LABEL_DRAW_FRAME, false)
                putString(KEY_SIG_POS_X, "155")
                putString(KEY_NORMAL_SIG_POS_X, "155")
                putString(KEY_LABEL_SIG_POS_X, "155")
                putString(KEY_SIG_POS_Y, "245")
                putString(KEY_NORMAL_SIG_POS_Y, "245")
                putString(KEY_LABEL_SIG_POS_Y, "245")
                putBoolean(KEY_PASSWORD_OUT, false)
                putBoolean(KEY_NORMAL_PASSWORD_OUT, false)
                putBoolean(KEY_LABEL_PASSWORD_OUT, false)
                putString(KEY_FILE_NAME_TEMPLATE, getString(R.string.default_tmpl_normal))
                putString(KEY_NORMAL_FILE_NAME_TEMPLATE, getString(R.string.default_tmpl_normal))
                putString(KEY_LABEL_FILE_NAME_TEMPLATE, getString(R.string.default_tmpl_label))
                putInt(KEY_LAST_SIG_DPI_INDEX, 0)
                putBoolean(KEY_LAST_SCAN_EFFECT, false)
                putBoolean(KEY_LAST_GRAYSCALE, false)
                putBoolean(KEY_LAST_INNER_PDF_READER, true)
                putString(KEY_LAST_LOADED_PROFILE, "normal")
                putString(KEY_THEME_MODE, "system")
                putBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, false)
                putBoolean(KEY_FIRST_RUN_INITIALIZED, true)
            }
        }
    }

    private fun saveSettings(type: String) {
        val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
        val fileNameEt: EditText = findViewById(R.id.file_name)

        synchronized(prefsBackupLock) {
            prefs.edit {
                val rows = numberOfRows.text.toString()
                val columns = numberOfColumns.text.toString()
                val marginVal = margin.text.toString()
                val isPortrait = portrait.isChecked
                val drawFrame = drawFrameSwitch.isChecked
                val sigX = signaturePosX.text.toString()
                val sigY = signaturePosY.text.toString()
                val scale = scaleSwitch.isChecked
                val fit = fitSwitch.isChecked
                val fileNameTemplate = fileNameEt.text?.toString() ?: ""
                val batchVal = batchPage.text.toString()
                val passwordOutChecked = passwordOutCb.isChecked

                when (type) {
                    "normal" -> {
                        putString(KEY_NORMAL_ROWS, rows)
                        putString(KEY_NORMAL_COLUMNS, columns)
                        putString(KEY_NORMAL_MARGIN, marginVal)
                        putBoolean(KEY_NORMAL_ORIENTATION, isPortrait)
                        putBoolean(KEY_NORMAL_DRAW_FRAME, drawFrame)
                        putString(KEY_NORMAL_SIG_POS_X, sigX)
                        putString(KEY_NORMAL_SIG_POS_Y, sigY)
                        putBoolean(KEY_NORMAL_SCALE, scale)
                        putBoolean(KEY_NORMAL_FIT, fit)
                        putString(KEY_NORMAL_BATCH_PAGE, batchVal)
                        putBoolean(KEY_NORMAL_PASSWORD_OUT, passwordOutChecked)
                        putString(KEY_NORMAL_FILE_NAME_TEMPLATE, fileNameTemplate)
                    }

                    "label" -> {
                        putString(KEY_LABEL_ROWS, rows)
                        putString(KEY_LABEL_COLUMNS, columns)
                        putString(KEY_LABEL_MARGIN, marginVal)
                        putBoolean(KEY_LABEL_ORIENTATION, isPortrait)
                        putBoolean(KEY_LABEL_DRAW_FRAME, drawFrame)
                        putString(KEY_LABEL_SIG_POS_X, sigX)
                        putString(KEY_LABEL_SIG_POS_Y, sigY)
                        putBoolean(KEY_LABEL_SCALE, scale)
                        putBoolean(KEY_LABEL_FIT, fit)
                        putString(KEY_LABEL_BATCH_PAGE, batchVal)
                        putBoolean(KEY_LABEL_PASSWORD_OUT, passwordOutChecked)
                        putString(KEY_LABEL_FILE_NAME_TEMPLATE, fileNameTemplate)
                    }
                }
                putString(KEY_ROWS, rows)
                putString(KEY_COLUMNS, columns)
                putString(KEY_MARGIN, marginVal)
                putBoolean(KEY_ORIENTATION, isPortrait)
                putBoolean(KEY_DRAW_FRAME, drawFrame)
                putString(KEY_SIG_POS_X, sigX)
                putString(KEY_SIG_POS_Y, sigY)
                putBoolean(KEY_SCALE, scale)
                putBoolean(KEY_FIT, fit)
                putString(KEY_BATCH_PAGE, batchVal)
                putBoolean(KEY_PASSWORD_OUT, passwordOutChecked)
                putString(KEY_FILE_NAME_TEMPLATE, fileNameTemplate)
            }
            Toast.makeText(this, getString(R.string.settings_saved), Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveCurrentSettings() {
        val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
        val fileNameEt: EditText = findViewById(R.id.file_name)

        synchronized(prefsBackupLock) {
            prefs.edit {
                putString(KEY_ROWS, numberOfRows.text.toString())
                putString(KEY_COLUMNS, numberOfColumns.text.toString())
                putString(KEY_MARGIN, margin.text.toString())
                putBoolean(KEY_ORIENTATION, portrait.isChecked)
                putBoolean(KEY_DRAW_FRAME, drawFrameSwitch.isChecked)
                putString(KEY_SIG_POS_X, signaturePosX.text.toString())
                putString(KEY_SIG_POS_Y, signaturePosY.text.toString())
                putBoolean(KEY_SCALE, scaleSwitch.isChecked)
                putBoolean(KEY_FIT, fitSwitch.isChecked)
                putString(KEY_BATCH_PAGE, batchPage.text.toString())
                putBoolean(KEY_PASSWORD_OUT, passwordOutCb.isChecked)
                putString(KEY_FILE_NAME_TEMPLATE, fileNameEt.text?.toString() ?: "")
            }
        }
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)

        val rows: String
        val columns: String
        val marginVal: String
        val isPortrait: Boolean
        val drawFrame: Boolean
        val sigX: String
        val sigY: String
        val scale: Boolean
        val fit: Boolean
        val batchVal: String
        val passwordOutChecked: Boolean

        synchronized(prefsBackupLock) {
            rows = prefs.getString(KEY_ROWS, "1") ?: "1"
            columns = prefs.getString(KEY_COLUMNS, "1") ?: "1"
            marginVal = prefs.getString(KEY_MARGIN, "0") ?: "0"
            isPortrait = prefs.getBoolean(KEY_ORIENTATION, true)
            drawFrame = prefs.getBoolean(KEY_DRAW_FRAME, false)
            sigX = prefs.getString(KEY_SIG_POS_X, DEFAULT_SIG_POS_X_MM.toString()) ?: DEFAULT_SIG_POS_X_MM.toString()
            sigY = prefs.getString(KEY_SIG_POS_Y, DEFAULT_SIG_POS_Y_MM.toString()) ?: DEFAULT_SIG_POS_Y_MM.toString()
            scale = prefs.getBoolean(KEY_SCALE, false)
            fit = prefs.getBoolean(KEY_FIT, false)
            batchVal = prefs.getString(KEY_BATCH_PAGE, "20") ?: "20"
            passwordOutChecked = prefs.getBoolean(KEY_PASSWORD_OUT, false)
        }

        numberOfRows.setText(rows)
        numberOfColumns.setText(columns)
        margin.setText(marginVal)
        portrait.isChecked = isPortrait
        landscape.isChecked = !isPortrait
        drawFrameSwitch.isChecked = drawFrame
        signaturePosX.setText(sigX)
        signaturePosY.setText(sigY)
        batchPage.setText(batchVal)
        passwordOutCb.isChecked = passwordOutChecked
        scaleSwitch.isChecked = scale
        fitSwitch.isChecked = fit
        fitSwitch.isEnabled = scaleSwitch.isChecked

        setupEnterClosesEditTextAndHidesKeyboard(numberOfRows)
        setupEnterClosesEditTextAndHidesKeyboard(numberOfColumns)
        setupEnterClosesEditTextAndHidesKeyboard(margin)
        setupEnterClosesEditTextAndHidesKeyboard(batchPage)
        setupEnterClosesEditTextAndHidesKeyboard(signaturePosX)
        setupEnterClosesEditTextAndHidesKeyboard(signaturePosY)

        val fileNameEt: EditText = findViewById(R.id.file_name)
        val defaultTemplate = getString(R.string.default_tmpl_normal)
        val tmpl = synchronized(prefsBackupLock) {
            prefs.getString(KEY_FILE_NAME_TEMPLATE, defaultTemplate) ?: defaultTemplate
        }
        fileNameEt.setText(tmpl)

        if (fileNameEt.getTag(R.id.file_name) != true) {
            fileNameEt.addTextChangedListener(SimpleTextWatcher {
                val sNow = fileNameEt.text?.toString()?.trim().orEmpty()
                validateIntField(
                    fileNameEt,
                    getString(R.string.file_name_optional),
                    isValid = sNow.isNotBlank()
                )
            })
            fileNameEt.setTag(R.id.file_name, true)
        }
        val sInit = fileNameEt.text?.toString()?.trim().orEmpty()
        validateIntField(
            fileNameEt,
            getString(R.string.file_name_optional),
            isValid = sInit.isNotBlank()
        )

        updateFileNameHintBasedOnRowsCols()
        validateInputs()
    }

    private fun loadSettings(type: String) {
        isLoadingSettingsProfile = true
        regenRequestedDuringProfileLoad = false

        lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) {
                val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                synchronized(prefsBackupLock) {
                    when (type) {
                        "normal" -> mapOf(
                            "nlRows" to (prefs.getString(KEY_NORMAL_ROWS, "1") ?: "1"),
                            "nlColumns" to (prefs.getString(KEY_NORMAL_COLUMNS, "1") ?: "1"),
                            "nlMargin" to (prefs.getString(KEY_NORMAL_MARGIN, "0") ?: "0"),
                            "nlOrientation" to prefs.getBoolean(KEY_NORMAL_ORIENTATION, true),
                            "nlDrawFrame" to prefs.getBoolean(KEY_NORMAL_DRAW_FRAME, false),
                            "nlSigPosX" to (prefs.getString(
                                KEY_NORMAL_SIG_POS_X,
                                DEFAULT_SIG_POS_X_MM.toString()
                            ) ?: DEFAULT_SIG_POS_X_MM.toString()),
                            "nlSigPosY" to (prefs.getString(
                                KEY_NORMAL_SIG_POS_Y,
                                DEFAULT_SIG_POS_Y_MM.toString()
                            ) ?: DEFAULT_SIG_POS_Y_MM.toString()),
                            "nlScale" to prefs.getBoolean(KEY_NORMAL_SCALE, false),
                            "nlFit" to prefs.getBoolean(KEY_NORMAL_FIT, false),
                            "nlBatchPage" to (prefs.getString(KEY_NORMAL_BATCH_PAGE, "20") ?: "20"),
                            "nlPasswordOut" to prefs.getBoolean(KEY_NORMAL_PASSWORD_OUT, false),
                            "nlFileNameTemplate" to (prefs.getString(
                                KEY_NORMAL_FILE_NAME_TEMPLATE,
                                getString(R.string.default_tmpl_normal)
                            ) ?: getString(R.string.default_tmpl_normal))
                        )

                        "label" -> mapOf(
                            "nlRows" to (prefs.getString(KEY_LABEL_ROWS, "2") ?: "2"),
                            "nlColumns" to (prefs.getString(KEY_LABEL_COLUMNS, "2") ?: "2"),
                            "nlMargin" to (prefs.getString(KEY_LABEL_MARGIN, "2") ?: "2"),
                            "nlOrientation" to prefs.getBoolean(KEY_LABEL_ORIENTATION, true),
                            "nlDrawFrame" to prefs.getBoolean(KEY_LABEL_DRAW_FRAME, false),
                            "nlSigPosX" to (prefs.getString(
                                KEY_LABEL_SIG_POS_X,
                                DEFAULT_SIG_POS_X_MM.toString()
                            ) ?: DEFAULT_SIG_POS_X_MM.toString()),
                            "nlSigPosY" to (prefs.getString(
                                KEY_LABEL_SIG_POS_Y,
                                DEFAULT_SIG_POS_Y_MM.toString()
                            ) ?: DEFAULT_SIG_POS_Y_MM.toString()),
                            "nlScale" to prefs.getBoolean(KEY_LABEL_SCALE, true),
                            "nlFit" to prefs.getBoolean(KEY_LABEL_FIT, false),
                            "nlBatchPage" to (prefs.getString(KEY_LABEL_BATCH_PAGE, "20") ?: "20"),
                            "nlPasswordOut" to prefs.getBoolean(KEY_LABEL_PASSWORD_OUT, false),
                            "nlFileNameTemplate" to (prefs.getString(
                                KEY_LABEL_FILE_NAME_TEMPLATE,
                                getString(R.string.default_tmpl_label)
                            ) ?: getString(R.string.default_tmpl_label))
                        )

                        else -> emptyMap()
                    }
                }
            }

            numberOfRows.setText(data["nlRows"] as String)
            numberOfColumns.setText(data["nlColumns"] as String)
            margin.setText(data["nlMargin"] as String)
            val isPortrait = data["nlOrientation"] as Boolean
            portrait.isChecked = isPortrait
            landscape.isChecked = !isPortrait
            drawFrameSwitch.isChecked = data["nlDrawFrame"] as Boolean
            signaturePosX.setText(data["nlSigPosX"] as String)
            signaturePosY.setText(data["nlSigPosY"] as String)
            scaleSwitch.isChecked = data["nlScale"] as Boolean
            fitSwitch.isChecked = data["nlFit"] as Boolean
            fitSwitch.isEnabled = scaleSwitch.isChecked
            batchPage.setText(data["nlBatchPage"] as String)
            passwordOutCb.isChecked = data["nlPasswordOut"] as Boolean

            val fileNameEt: EditText = findViewById(R.id.file_name)
            fileNameEt.setText(data["nlFileNameTemplate"] as String)

            val prefs2 = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            synchronized(prefsBackupLock) {
                prefs2.edit {
                    putString(KEY_FILE_NAME_TEMPLATE, fileNameEt.text?.toString() ?: "")
                    putString(KEY_LAST_LOADED_PROFILE, type)
                }
            }

            updateFileNameHintBasedOnRowsCols()
            validateInputs()

            isLoadingSettingsProfile = false

            if (regenRequestedDuringProfileLoad && plpTempFile().exists()) {
                regenRequestedDuringProfileLoad = false
                regeneratePlpAsyncAndReloadThumbnails()
            }
        }
    }

    private fun updateFileNameHintBasedOnRowsCols() {
        val rowsStr = numberOfRows.text?.toString()?.trim().orEmpty()
        val colsStr = numberOfColumns.text?.toString()?.trim().orEmpty()

        val rows = rowsStr.toIntOrNull()
        val cols = colsStr.toIntOrNull()

        val isRowsEmpty = rowsStr.isEmpty()
        val isColsEmpty = colsStr.isEmpty()

        val isNormal =
            (isRowsEmpty && isColsEmpty) ||
                    (isRowsEmpty && cols == 1) ||
                    (rows == 1 && isColsEmpty) ||
                    (rows == 1 && cols == 1)

        val fileNameEt: EditText = findViewById(R.id.file_name)
        val hintRes = if (isNormal) R.string.default_tmpl_normal else R.string.default_tmpl_label
        fileNameEt.hint = getString(hintRes)
    }

    private fun validateInputs() {
        nbColumnsValid = validateIntField(numberOfColumns, 1, getString(R.string.enter_value_1_100))
        nbRowsValid    = validateIntField(numberOfRows,    1, getString(R.string.enter_value_1_100))
        marginValid    = validateIntField(margin,          0, getString(R.string.enter_value_0_100))
        batchValid     = validateIntField(batchPage,       1, getString(R.string.enter_value_batch_1_100))
        val isPortrait = portrait.isChecked
        val maxX = if (isPortrait) 210 else 297
        val maxY = if (isPortrait) 297 else 210
        sigXValid = checkUpToMax(signaturePosX.text.toString(), maxX)
        sigYValid = checkUpToMax(signaturePosY.text.toString(), maxY)

        validateIntFieldX(signaturePosX, portrait)
        validateIntFieldY(signaturePosY, portrait)

        updateFileNameHintBasedOnRowsCols()
        updateButtonsState()
    }

    private fun checkUpToMax(s: String, max: Int): Boolean {
        return try { val v = s.toInt(); v in 0..max } catch (_: Exception) { false }
    }

    private fun buildErrorTextFromDimen(et: EditText, msg: String, dimenRes: Int): CharSequence {
        val sizePx = et.resources.getDimensionPixelSize(dimenRes)
        return SpannableString(msg).apply {
            setSpan(AbsoluteSizeSpan(sizePx), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun validateIntField(
        et: EditText,
        min: Int,
        errorMsg: String,
        max: Int = 100
    ): Boolean {
        val s = et.text.toString()
        val ok = s.isNotEmpty() && (s.toIntOrNull()?.let { it in min..max } == true)

        et.error = if (ok) {
            null
        } else {
            val sizePx = et.resources.getDimensionPixelSize(R.dimen.dp_14)
            SpannableString(errorMsg).apply {
                setSpan(
                    AbsoluteSizeSpan(sizePx),
                    0, length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        return ok
    }

    private fun validateIntField(
        et: EditText,
        errorMsg: String,
        isValid: Boolean
    ): Boolean {
        et.error = if (isValid) {
            null
        } else {
            val sizePx = et.resources.getDimensionPixelSize(R.dimen.dp_14)
            SpannableString(errorMsg).apply {
                setSpan(
                    AbsoluteSizeSpan(sizePx),
                    0, length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        return isValid
    }

    private fun validateIntFieldX(
        et: EditText,
        portrait: MaterialRadioButton
    ): Boolean {
        val isPortrait = portrait.isChecked

        val emptyMsg = if (isPortrait) {
            et.context.getString(R.string.enter_value_0_209)
        } else {
            et.context.getString(R.string.enter_value_0_296)
        }

        val s = et.text?.toString()?.trim().orEmpty()
        val ok = s.isNotEmpty()

        et.error = if (ok) {
            null
        } else {
            buildErrorTextFromDimen(et, emptyMsg, R.dimen.dp_14)
        }

        return ok
    }

    private fun validateIntFieldY(
        et: EditText,
        portrait: MaterialRadioButton
    ): Boolean {
        val isPortrait = portrait.isChecked

        val emptyMsg = if (isPortrait) {
            et.context.getString(R.string.enter_value_0_296)
        } else {
            et.context.getString(R.string.enter_value_0_209)
        }

        val s = et.text?.toString()?.trim().orEmpty()
        val ok = s.isNotEmpty()

        et.error = if (ok) {
            null
        } else {
            buildErrorTextFromDimen(et, emptyMsg, R.dimen.dp_14)
        }

        return ok
    }

    private fun updateButtonsState() {
        val hasPages = viewModel.pageItems.isNotEmpty()
        val hasSelection = viewModel.pageItems.any { it.isSelected }

        listStartButton.isEnabled = hasPages
        listEndButton.isEnabled = hasPages

        emptyPage.isEnabled = hasPages

        addSignature.isEnabled = hasSelection && hasPages

        printPdf.isEnabled = hasPages
        savePdf.isEnabled = hasPages
        sendPdf.isEnabled  = hasPages

        val allSelect = findViewById<AppCompatCheckBox>(R.id.all_select)
        if (allSelect.getTag(R.id.all_select) != true) {
            allSelect.setOnClickListener {
                val shouldSelectAll = allSelect.isChecked
                if (shouldSelectAll) {
                    adapter.selectAll()
                } else {
                    adapter.clearAllSelections()
                }
                updateButtonsState()
            }
            allSelect.setTag(R.id.all_select, true)
        }
        allSelect.isEnabled = hasPages
        val allChecked = hasPages && viewModel.pageItems.all { it.isSelected }
        if (allSelect.isChecked != allChecked) {
            allSelect.isChecked = allChecked
        }

        val deleteBtn = findViewById<AppCompatImageButton>(R.id.delete_select)
        if (deleteBtn.getTag(R.id.delete_select) != true) {
            deleteBtn.setOnClickListener {
                deleteSelectedPlpGroups()
            }
            deleteBtn.setTag(R.id.delete_select, true)
        }
        deleteBtn.isEnabled   = hasPages && hasSelection
        deleteBtn.isActivated = hasSelection

        val rotateLeftBtn = findViewById<AppCompatImageButton>(R.id.rotate_left_select)
        if (rotateLeftBtn.getTag(R.id.rotate_left_select) != true) {
            rotateLeftBtn.setOnClickListener {
                rotateLeftSelectedPlpGroups()
            }
            rotateLeftBtn.setTag(R.id.rotate_left_select, true)
        }
        rotateLeftBtn.isEnabled   = hasPages && hasSelection
        rotateLeftBtn.isActivated = hasSelection

        fastScroller?.setEnabledWhen(hasPages)

        val shouldNotify = (lastGlobalAllSelected == null || lastGlobalAllSelected != allChecked)
        lastGlobalAllSelected = allChecked
        if (shouldNotify) {

            val rv = findViewById<RecyclerView>(R.id.rv_thumbnails)
            val lm = rv.layoutManager as? LinearLayoutManager
            val first = lm?.findFirstVisibleItemPosition() ?: RecyclerView.NO_POSITION
            val last  = lm?.findLastVisibleItemPosition()  ?: RecyclerView.NO_POSITION
            if (first != RecyclerView.NO_POSITION && last >= first) {
                val count = last - first + 1
                if (rv.isComputingLayout) {
                    rv.post { adapter.notifyItemRangeChanged(first, count, "force") }
                } else {
                    adapter.notifyItemRangeChanged(first, count, "force")
                }
            }
        }
    }

    private fun resetThumbDocKey(reason: String) {
        (findViewById<RecyclerView>(R.id.rv_thumbnails).adapter as? ThumbnailAdapter)
            ?.resetForNewDocument("$reason|${System.nanoTime()}")
    }

    private fun showInProgressUpdateUI(
        message: String = getString(R.string.in_progress_ui),
    ) {
        val resolvedMessage = message.ifBlank { getString(R.string.in_progress_ui) }

        PdfProcessingForegroundService.start(this, resolvedMessage)

        runCatching {
            val panel = binding.overlayProgressDialogUpdateUiPanel
            panel.removeAllViews()
            val view = LayoutInflater.from(this).inflate(R.layout.progress_dialog_update_ui, panel, false)
            view.findViewById<MaterialTextView>(R.id.progress_bar_update_ui_simple_text)?.text = resolvedMessage
            panel.addView(view)
            binding.overlayProgressDialogUpdateUi.visibility = View.VISIBLE
        }.onFailure {
        }

        isUiBlockedByProgress = true
    }


    private fun hideInProgressIfShownUpdateUI() {
        PdfProcessingForegroundService.stop(this)

        runCatching {
            binding.overlayProgressDialogUpdateUi.visibility = View.GONE
        }.onFailure {
        }

        isUiBlockedByProgress = false
    }

    private suspend fun backupSelectionState() {
        val selectedCsv: String
        val firstPos: Int
        val topOffset: Int

        withContext(Dispatchers.Main.immediate) {
            selectedCsv = viewModel.pageItems
                .mapIndexedNotNull { idx, item -> if (item.isSelected) idx else null }
                .joinToString(",")

            val lm = binding.rvThumbnails.layoutManager as? LinearLayoutManager
            firstPos = lm?.findFirstVisibleItemPosition() ?: RecyclerView.NO_POSITION
            topOffset = if (firstPos != RecyclerView.NO_POSITION) {
                lm?.findViewByPosition(firstPos)?.top ?: 0
            } else 0
        }

        withContext(Dispatchers.IO) {
            val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            synchronized(prefsBackupLock) {
                prefs.edit {
                    remove(KEY_BACKUP_SELECTED)
                    remove(KEY_BACKUP_THUMB_FIRST)
                    remove(KEY_BACKUP_THUMB_OFFSET)

                    putString(KEY_BACKUP_SELECTED, selectedCsv)
                    putInt(KEY_BACKUP_THUMB_FIRST, firstPos)
                    putInt(KEY_BACKUP_THUMB_OFFSET, topOffset)
                }
            }
        }
    }

    private fun backupUiStateBeforeLongOperation() {
        runCatching {
            val cfg = lastBuiltNupConfig ?: currentNupConfigFromInputs()

            val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            val rotationCsv = sourceRotation.joinToString(",")

            synchronized(prefsBackupLock) {
                prefs.edit {
                    remove(KEY_BACKUP_ROWS)
                    remove(KEY_BACKUP_COLUMNS)
                    remove(KEY_BACKUP_MARGIN)
                    remove(KEY_BACKUP_ORIENTATION)
                    remove(KEY_BACKUP_DRAW_FRAME)
                    remove(KEY_BACKUP_SCALE)
                    remove(KEY_BACKUP_FIT)
                    remove(KEY_BACKUP_ROTATION)

                    putString(KEY_BACKUP_ROWS, cfg.rows.toString())
                    putString(KEY_BACKUP_COLUMNS, cfg.cols.toString())
                    putString(KEY_BACKUP_MARGIN, cfg.marginMm.toString())
                    putBoolean(KEY_BACKUP_ORIENTATION, !cfg.isLandscape)
                    putBoolean(KEY_BACKUP_DRAW_FRAME, cfg.drawFrame)
                    putBoolean(KEY_BACKUP_SCALE, cfg.scaleIndividually)
                    putBoolean(KEY_BACKUP_FIT, cfg.fitIndividually)
                    putString(KEY_BACKUP_ROTATION, rotationCsv)
                }
            }
        }.onFailure {
        }
    }

    private fun clearBackupStateKeysFromPrefs() {
        runCatching {
            val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            synchronized(prefsBackupLock) {
                prefs.edit {
                    remove(KEY_BACKUP_SELECTED)
                    remove(KEY_BACKUP_THUMB_FIRST)
                    remove(KEY_BACKUP_THUMB_OFFSET)
                    remove(KEY_BACKUP_ROWS)
                    remove(KEY_BACKUP_COLUMNS)
                    remove(KEY_BACKUP_MARGIN)
                    remove(KEY_BACKUP_ORIENTATION)
                    remove(KEY_BACKUP_DRAW_FRAME)
                    remove(KEY_BACKUP_SCALE)
                    remove(KEY_BACKUP_FIT)
                    remove(KEY_BACKUP_ROTATION)
                }
            }
        }.onFailure {
        }
    }

    private fun cancelLongRunningWorkAndCleanup() {
        isSigningCancelled = true

        reloadThumbnailsGeneration++

        activeJobs.forEach { it.cancel() }

        isPlpRebuilding = false
        isLoadingSettingsProfile = false

        lifecycleScope.launch {
            activeJobs.joinAll()
            activeJobs.clear()

            val selectedIdxBeforeCancel: Set<Int>
            val thumbFirstBeforeCancel: Int
            val thumbOffsetBeforeCancel: Int

            val rowsBeforeCancel: String
            val columnsBeforeCancel: String
            val marginBeforeCancel: String
            val isPortraitBeforeCancel: Boolean
            val drawFrameBeforeCancel: Boolean
            val scaleBeforeCancel: Boolean
            val fitBeforeCancel: Boolean
            val rotationCsvBeforeCancel: String

            withContext(Dispatchers.IO) {
                val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                synchronized(prefsBackupLock) {
                    selectedIdxBeforeCancel = prefs.getString(KEY_BACKUP_SELECTED, "")
                        ?.split(',')
                        ?.mapNotNull { it.toIntOrNull() }
                        ?.toSet()
                        ?: emptySet()

                    thumbFirstBeforeCancel = prefs.getInt(KEY_BACKUP_THUMB_FIRST, RecyclerView.NO_POSITION)
                    thumbOffsetBeforeCancel = prefs.getInt(KEY_BACKUP_THUMB_OFFSET, 0)

                    rowsBeforeCancel = prefs.getString(KEY_BACKUP_ROWS, "1") ?: "1"
                    columnsBeforeCancel = prefs.getString(KEY_BACKUP_COLUMNS, "1") ?: "1"
                    marginBeforeCancel = prefs.getString(KEY_BACKUP_MARGIN, "0") ?: "0"
                    isPortraitBeforeCancel = prefs.getBoolean(KEY_BACKUP_ORIENTATION, true)
                    drawFrameBeforeCancel = prefs.getBoolean(KEY_BACKUP_DRAW_FRAME, false)
                    scaleBeforeCancel = prefs.getBoolean(KEY_BACKUP_SCALE, false)
                    fitBeforeCancel = prefs.getBoolean(KEY_BACKUP_FIT, false)
                    rotationCsvBeforeCancel = prefs.getString(KEY_BACKUP_ROTATION, "") ?: ""
                }
            }

            clearBackupStateKeysFromPrefs()

            val sourceBackup = File(cacheDir, SOURCE_TEMP_COPY_NAME)
            val plpBackup = File(cacheDir, PLP_TEMP_COPY_NAME)

            var restoredPlpBackup = false

            cacheDir.listFiles()?.forEach { f ->
                if (f != sourceBackup && f != plpBackup) {
                    runCatching { f.delete() }
                }
            }

            if (sourceBackup.exists()) {
                val sourceFile = sourceTempFile()
                runCatching {
                    FileInputStream(sourceBackup).use { input ->
                        FileOutputStream(sourceFile, false).use { output ->
                            input.copyTo(output)
                        }
                    }
                }

                runCatching { sourceBackup.delete() }
            }

            if (plpBackup.exists()) {
                val plpFile = plpTempFile()
                runCatching {
                    FileInputStream(plpBackup).use { input ->
                        FileOutputStream(plpFile, false).use { output ->
                            input.copyTo(output)
                        }
                    }
                }.onSuccess {
                    restoredPlpBackup = true
                }

                runCatching { plpBackup.delete() }
            }

            resetThumbDocKey("cancelLongRunningWorkAndCleanup")

            if (restoredPlpBackup) {
                val prevSuppressNup = suppressNup
                runCatching {
                    suppressNup = true

                    numberOfRows.setText(rowsBeforeCancel)
                    numberOfColumns.setText(columnsBeforeCancel)
                    margin.setText(marginBeforeCancel)

                    portrait.isChecked = isPortraitBeforeCancel
                    landscape.isChecked = !isPortraitBeforeCancel

                    drawFrameSwitch.isChecked = drawFrameBeforeCancel
                    scaleSwitch.isChecked = scaleBeforeCancel
                    fitSwitch.isChecked = fitBeforeCancel
                    fitSwitch.isEnabled = scaleSwitch.isChecked

                    lastBuiltNupConfig = NupConfig(
                        rowsBeforeCancel.toIntOrNull() ?: 1,
                        columnsBeforeCancel.toIntOrNull() ?: 1,
                        marginBeforeCancel.toIntOrNull() ?: 0,
                        !isPortraitBeforeCancel,
                        drawFrameBeforeCancel,
                        scaleBeforeCancel,
                        fitBeforeCancel
                    )

                    sourceRotation = if (rotationCsvBeforeCancel.isNotEmpty()) {
                        rotationCsvBeforeCancel.split(',').mapNotNull { it.toIntOrNull() }.toIntArray()
                    } else {
                        IntArray(0)
                    }

                    suppressNup = prevSuppressNup
                }.onFailure {
                    suppressNup = prevSuppressNup
                }
            }

            reloadThumbnailsFromPlp(
                targetIndex = thumbFirstBeforeCancel.takeIf { it != RecyclerView.NO_POSITION },
                targetOffsetPx = thumbOffsetBeforeCancel,
                restorePrevious = true,
                indicesToSelect = selectedIdxBeforeCancel,
                releaseUiAtStart = false,
                onStarted = {
                    unlockScreenOrientation()
                    hideInProgressIfShownUpdateUI()
                    isSigningCancelled = false
                }
            )
        }
    }

    private fun showInProgress(
        message: String = getString(R.string.in_progress_my),
    ) {
        val resolvedMessage = message.ifBlank { getString(R.string.in_progress_my) }

        runCatching {
            val wasShowingForBackup = (binding.overlayProgressDialog.isVisible)
            if (!wasShowingForBackup) {
                backupUiStateBeforeLongOperation()
            }
        }.onFailure {
        }

        PdfProcessingForegroundService.start(this, resolvedMessage)

        runCatching {
            val wasShowing = (binding.overlayProgressDialog.isVisible)

            if (!wasShowing) {
                backupTempFilesBeforeLongOperation()
            }

            val panel = binding.overlayProgressDialogPanel
            panel.removeAllViews()
            val view = LayoutInflater.from(this).inflate(R.layout.progress_dialog, panel, false)
            view.findViewById<MaterialTextView>(R.id.progress_bar_simple_text)?.text = resolvedMessage

            val btnCancel = view.findViewById<MaterialButton>(R.id.progress_bar_cancel)
            btnCancel?.setOnClickListener {
                cancelLongRunningWorkAndCleanup()

                hideInProgressIfShown()

                showInProgressUpdateUI()
            }

            panel.addView(view)
            binding.overlayProgressDialog.visibility = View.VISIBLE
        }.onFailure {
        }

        isUiBlockedByProgress = true

        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun hideInProgressIfShown() {
        PdfProcessingForegroundService.stop(this)

        runCatching {
            binding.overlayProgressDialog.visibility = View.GONE
            binding.overlayProgressDialogUpdateUi.visibility = View.GONE
        }.onFailure {
        }

        isUiBlockedByProgress = false

        window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun readIntOr(et: EditText, min: Int, def: Int): Int {
        val v = et.text?.toString()?.trim()?.toIntOrNull()
        return (v ?: def).coerceIn(min, MAX_INPUT)
    }

    private fun currentNupConfigFromInputs(): NupConfig {
        val rows     = readIntOr(numberOfRows,    min = 1, def = 1)
        val cols     = readIntOr(numberOfColumns, min = 1, def = 1)
        val marginMm = readIntOr(margin,          min = 0, def = 0)
        val isLand = landscape.isChecked
        val drawFrame = drawFrameSwitch.isChecked
        val scaleInd = scaleSwitch.isChecked
        val fitInd = fitSwitch.isChecked
        return NupConfig(rows, cols, marginMm, isLand, drawFrame, scaleInd, fitInd)
    }

    private fun nupConfigChanged(): Boolean {
        val cur = currentNupConfigFromInputs()
        val last = lastBuiltNupConfig
        return last == null || last != cur
    }

    private fun maybeRegeneratePlpOnSettingChange() {
        if (suppressNup) {
            return
        }

        if (plpTempFile().exists()) {
            if (isLoadingSettingsProfile) {
                regenRequestedDuringProfileLoad = true
                return
            }
            regeneratePlpAsyncAndReloadThumbnails()
        }
    }

    private fun setupRegenerateOnBlur(et: EditText) {

        et.setOnFocusChangeListener { _, hasFocus ->if (hasFocus) {
            et.setTag(et.id, et.text?.toString())
        } else {
            if (suppressNup || !plpTempFile().exists()) {
                return@setOnFocusChangeListener
            }

            val valueOnBlur = et.text?.toString()

            val valueOnFocus = et.getTag(et.id) as? String

            val normalizedValueOnFocus = when (et.id) {
                R.id.number_of_rows, R.id.number_of_columns -> if (valueOnFocus.isNullOrEmpty()) "1" else valueOnFocus
                R.id.margin -> if (valueOnFocus.isNullOrEmpty()) "0" else valueOnFocus
                else -> valueOnFocus
            }

            val normalizedValueOnBlur = when (et.id) {
                R.id.number_of_rows, R.id.number_of_columns -> if (valueOnBlur.isNullOrEmpty()) "1" else valueOnBlur
                R.id.margin -> if (valueOnBlur.isNullOrEmpty()) "0" else valueOnBlur
                else -> valueOnBlur
            }

            if (normalizedValueOnFocus != normalizedValueOnBlur) {
                if (nupConfigChanged()) {
                    regeneratePlpAsyncAndReloadThumbnails()
                }
            }
        }
        }
    }

    private fun launchSelectPdf() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/pdf",
                    "image/jpeg",
                    "image/jpg",
                    "image/png"
                )
            )
        }
        pdfPickerLauncher.launch(i)
    }

    private fun handlePdfUri(uri: Uri) {

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val selectedIdx = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

        val oldPer = run {
            val last = lastBuiltNupConfig ?: currentNupConfigFromInputs()
            (last.rows.coerceAtLeast(1)) * (last.cols.coerceAtLeast(1))
        }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val mtLc = try { contentResolver.getType(uri)?.lowercase(Locale.ROOT) } catch (_: Exception) { null }
                val nameLcForType = try { extractFileName(uri).lowercase(Locale.ROOT) } catch (_: Exception) { "" }
                val isImage = isSupportedImageMime(mtLc) || isSupportedImageFileName(nameLcForType)

                val tempSrc = File(cacheDir, "${timeStamp}_${extractFileName(uri)}")
                contentResolver.openInputStream(uri)?.use { inputStream ->
                    FileOutputStream(tempSrc).use { outputStream ->
                        val buffer = ByteArray(4096)
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } > 0) {
                            outputStream.write(buffer, 0, bytesRead)
                        }
                    }
                } ?: throw IOException(getString(R.string.input_stream_is_null))

                try {

                    val oldPageCount = sourceTempPageCount()

                    val selectedSrcPages: Set<Int> = if (selectedIdx.isNotEmpty() && oldPageCount > 0) {
                        buildSet {
                            selectedIdx.forEach { g ->
                                val start = g * oldPer + 1
                                val end = min(oldPageCount, start + oldPer - 1)
                                for (p in start..end) add(p)
                            }
                        }
                    } else emptySet()

                    fun isBadPassword(t: Throwable): Boolean {
                        if (t is BadPasswordException) return true
                        val msg = t.message?.lowercase().orEmpty()
                        return msg.contains("bad user password") || msg.contains("bad password")
                    }

                    if (isImage) {

                        withContext(Dispatchers.Main) {
                            showInProgress(getString(R.string.in_progress_opening))
                            lockScreenOrientation()
                        }

                        val imagePdf = createTempPdfFromImageFile(tempSrc)
                        try {
                            appendPdfToSourceTemp(imagePdf, null)
                        } finally {
                            runCatching { imagePdf.delete() }.onFailure {

                            }
                        }
                    } else {
                        var passwordBytes: ByteArray? = null
                        var attempt = 0

                        while (true) {
                            val canOpen = try {
                                PdfDocument(rdr(tempSrc.absolutePath, passwordBytes)).use { }
                                true
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                if (!isBadPassword(e)) throw e
                                false
                            }

                            if (canOpen) break

                            val entered: String? = withContext(Dispatchers.Main) {
                                promptForPdfPassword(showError = (attempt > 0))
                            }

                            if (entered == null) {
                                withContext(Dispatchers.Main) {
                                    hideInProgressIfShown()
                                    unlockScreenOrientation()
                                }
                                runCatching { tempSrc.delete() }
                                return@launch
                            }

                            passwordBytes = entered.toByteArray(Charsets.UTF_8)
                            attempt++
                        }

                        withContext(Dispatchers.Main) {
                            showInProgress(getString(R.string.in_progress_opening))
                            lockScreenOrientation()
                        }

                        appendPdfToSourceTemp(tempSrc, passwordBytes)
                    }

                    runCatching { tempSrc.delete() }

                    createTempPdfInternal()

                    withContext(Dispatchers.Main) {
                        resetThumbDocKey("handlePdfUri:$uri")

                        val per = perGroup()
                        val indicesToSelectAfter: Set<Int> =
                            if (selectedSrcPages.isNotEmpty())
                                selectedSrcPages.map { p -> (p - 1) / per }.toSet()
                            else emptySet()

                        val onReloadStarted: () -> Unit = {
                            hideInProgressIfShown()
                            unlockScreenOrientation()
                        }

                        reloadThumbnailsFromPlp(
                            targetIndex = null,
                            targetOffsetPx = 0,
                            restorePrevious = true,
                            indicesToSelect = indicesToSelectAfter,
                            releaseUiAtStart = false,
                            onStarted = onReloadStarted
                        )

                        updateButtonsState()
                    }
                } finally {
                    runCatching { tempSrc.delete() }.onFailure {

                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.error_loading_pdf_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun isSupportedImageMime(mtLc: String?): Boolean {
        return when (mtLc) {
            "image/jpeg", "image/jpg", "image/png" -> true
            else -> false
        }
    }

    private fun isSupportedImageFileName(nameLc: String): Boolean {
        return nameLc.endsWith(".jpg") ||
                nameLc.endsWith(".jpeg") ||
                nameLc.endsWith(".png")
    }

    @WorkerThread
    @Throws(IOException::class)
    private fun createTempPdfFromImageFile(imageFile: File): File {
        val out = File(cacheDir, "${timeStamp}_from_image_${System.currentTimeMillis()}.pdf")

        val bounds0 = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(imageFile.absolutePath, bounds0)
        val w0 = bounds0.outWidth
        val h0 = bounds0.outHeight

        if (w0 <= 0 || h0 <= 0) throw IOException(getString(R.string.image_decode_failed))

        if (w0 > MAX_IMG_W || h0 > MAX_IMG_H) {
            throw IOException(getString(R.string.large_image))
        }

        return try {
            if (imageFile.isLikelyPng()) {
                createPdfFromPngTiled(imageFile, out, w0, h0)
            } else {
                val imageData = ImageDataFactory.create(imageFile.absolutePath)
                val imgW = imageData.width.coerceAtLeast(1f)
                val imgH = imageData.height.coerceAtLeast(1f)
                val pageRect = Rectangle(imgW, imgH)

                PdfDocument(PdfWriter(out.absolutePath, writerProps())).use { destDoc ->
                    destDoc.setFlushUnusedObjects(true)
                    val pg = destDoc.addNewPage(PageSize(pageRect))
                    PdfCanvas(pg).addImageFittedIntoRectangle(imageData, pageRect, false)
                    pg.flush()
                }
                out
            }
        } catch (e: OutOfMemoryError) {
            throw e
        } catch (e: Throwable) {
            throw e
        }
    }

    private fun File.isLikelyPng(): Boolean {
        return try {
            FileInputStream(this).use { fis ->
                val header = ByteArray(8)
                fis.read(header) == 8 &&
                        header[0] == 0x89.toByte() &&
                        header[1] == 0x50.toByte() &&
                        header[2] == 0x4E.toByte() &&
                        header[3] == 0x47.toByte() &&
                        header[4] == 0x0D.toByte() &&
                        header[5] == 0x0A.toByte() &&
                        header[6] == 0x1A.toByte() &&
                        header[7] == 0x0A.toByte()
            }
        } catch (_: Throwable) {
            name.lowercase().endsWith(".png")
        }
    }

    private object BitmapRegionDecoderCompat {

        @RequiresApi(VERSION_CODES.S)
        private object Api31Impl {
            @JvmStatic
            fun newInstance(path: String): BitmapRegionDecoder {
                return BitmapRegionDecoder.newInstance(path)
            }
        }

        private object LegacyImpl {
            @Suppress("DEPRECATION")
            @JvmStatic
            fun newInstance(path: String): BitmapRegionDecoder {
                return BitmapRegionDecoder.newInstance(path, false)
            }
        }

        fun newInstance(file: File): BitmapRegionDecoder {
            val path = file.absolutePath
            return if (Build.VERSION.SDK_INT >= VERSION_CODES.S) {
                Api31Impl.newInstance(path)
            } else {
                LegacyImpl.newInstance(path)
            }
        }
    }

    private fun newRegionDecoderCompat(pngFile: File): BitmapRegionDecoder {
        return BitmapRegionDecoderCompat.newInstance(pngFile)
    }

    private fun pickTileHeight(width: Int, bytesPerPixel: Int = 4): Int {
        val budgetBytes = 8 * 1024 * 1024
        val perRow = (width.toLong() * bytesPerPixel).coerceAtLeast(1L)
        return (budgetBytes / perRow).toInt().coerceIn(256, 2048)
    }

    @WorkerThread
    @Throws(IOException::class)
    private fun createPdfFromPngTiled(
        pngFile: File,
        outFile: File,
        width: Int,
        height: Int
    ): File {
        val pageRect = Rectangle(width.toFloat(), height.toFloat())
        val tileHeight = pickTileHeight(width)

        val flattenBgColor = runCatching {
            ContextCompat.getColor(this@MainActivity, R.color.white)
        }.getOrElse { Color.WHITE }

        PdfDocument(PdfWriter(outFile.absolutePath, writerProps())).use { pdf ->
            pdf.setFlushUnusedObjects(true)
            val page = pdf.addNewPage(PageSize(pageRect))
            val canvas = PdfCanvas(page)

            val decoder = try {
                newRegionDecoderCompat(pngFile)
            } catch (e: Throwable) {
                throw IOException(getString(R.string.bitmap_region_decoder_init_failed), e)
            }

            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            val bos = ByteArrayOutputStream(1 shl 20)
            try {
                var y = 0
                while (y < height) {
                    val h = min(tileHeight, height - y)
                    val srcRect = Rect(0, y, width, y + h)

                    val bmp: Bitmap = decoder.decodeRegion(srcRect, opts)
                        ?: throw IOException(getString(R.string.decode_region_returned_null_at, y))

                    var toRecycleFlattened: Bitmap? = null
                    try {
                        val toCompress: Bitmap = if (bmp.hasAlpha()) {
                            createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888).apply {
                                setHasAlpha(false)
                                Canvas(this).apply {
                                    drawColor(flattenBgColor)
                                    drawBitmap(bmp, 0f, 0f, null)
                                }
                            }.also { toRecycleFlattened = it }
                        } else {
                            bmp
                        }

                        bos.reset()
                        if (!toCompress.compress(Bitmap.CompressFormat.JPEG, 100, bos)) {
                            throw IOException(getString(R.string.jpeg_compress_failed_at, y))
                        }

                        val imgData = ImageDataFactory.create(bos.toByteArray())
                        val destY = (height - (y + h)).toFloat()
                        val destRect = Rectangle(0f, destY, width.toFloat(), h.toFloat())
                        canvas.addImageFittedIntoRectangle(imgData, destRect, false)
                    } finally {
                        toRecycleFlattened?.recycle()
                        bmp.recycle()
                    }

                    y += h
                }

                canvas.release()
                page.flush()
            } finally {
                try { bos.close() } catch (_: Throwable) {}
                decoder.recycle()
            }
        }

        return outFile
    }

    private fun applySoftInputModeForPasswordOverlay() {
        val secureFlag = WindowManager.LayoutParams.FLAG_SECURE
        if (!passwordOverlayOwnsSecureFlag && window.attributes.flags and secureFlag == 0) {
            window.addFlags(secureFlag)
            passwordOverlayOwnsSecureFlag = true
        }

        if (savedSoftInputModeForOverlay == null) {
            savedSoftInputModeForOverlay = window.attributes.softInputMode
        }
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        )
    }

    private fun restoreSoftInputModeAfterPasswordOverlay() {
        savedSoftInputModeForOverlay?.let { oldMode ->
            savedSoftInputModeForOverlay = null
            window.setSoftInputMode(oldMode)
        }

        if (passwordOverlayOwnsSecureFlag) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            passwordOverlayOwnsSecureFlag = false
        }
    }


    private fun setupPasswordInputForDialog(
        dialogView: View,
        showError: Boolean,
        errorHintResId: Int? = null
    ): PasswordToggleEditText {

        val et = dialogView.findViewById<PasswordToggleEditText>(R.id.pwd_edittext)

        runCatching { et.setInitialStateMasked() }

        et.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_DONE || isEnter) {

                dialogView.findViewById<Button>(R.id.pwd_ok)?.performClick()
                true
            } else {
                false
            }
        }

        val originalHintColor = ContextCompat.getColor(this, R.color.password_hint_text_color)
        runCatching { et.setHintTextColor(originalHintColor) }

        if (errorHintResId != null || showError) {
            et.hint = resources.getString(errorHintResId ?: R.string.wrong_password)
            runCatching {
                et.setHintTextColor(ContextCompat.getColor(this, R.color.password_error_text_color))
            }
            val watcher = object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (!s.isNullOrEmpty()) {
                        et.hint = resources.getString(R.string.password_hint)
                        runCatching { et.setHintTextColor(originalHintColor) }
                        et.removeTextChangedListener(this)
                    }
                }
            }
            et.addTextChangedListener(watcher)
        } else {
            et.hint = resources.getString(R.string.password_hint)
            runCatching { et.setHintTextColor(originalHintColor) }
        }

        return et
    }

    private suspend fun promptForPdfPassword(showError: Boolean = false): String? =
        suspendCancellableCoroutine { cont ->

            PdfProcessingForegroundService.stop(this@MainActivity)
            unlockScreenOrientation()

            applySoftInputModeForPasswordOverlay()

            val overlay = binding.overlayDialogPassword
            val panel = binding.overlayDialogPasswordPanel

            panel.removeAllViews()
            val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_password, panel, false)
            panel.addView(dialogView)

            overlay.visibility = View.VISIBLE

            overlay.setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)
                restoreSoftInputModeAfterPasswordOverlay()
                if (!cont.isCompleted) cont.resume(null)
            }
            panel.setOnClickListener {
            }

            (dialogView as? ViewGroup)?.let { vg ->
                (vg.getChildAt(0) as? TextView)?.setText(R.string.enter_pdf_password)
            }

            val et = setupPasswordInputForDialog(
                dialogView = dialogView,
                showError = showError,
                errorHintResId = null
            )

            val btnOk     = dialogView.findViewById<Button>(R.id.pwd_ok)
            val btnCancel = dialogView.findViewById<Button>(R.id.pwd_cancel)

            btnOk.setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                val pwd = et.text?.toString()?.trim().orEmpty()

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)

                restoreSoftInputModeAfterPasswordOverlay()

                if (!cont.isCompleted) cont.resume(pwd)
            }

            btnCancel.setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)

                restoreSoftInputModeAfterPasswordOverlay()

                if (!cont.isCompleted) cont.resume(null)
            }

            cont.invokeOnCancellation {
                runCatching {
                    val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                    val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                    runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                    overlay.visibility = View.GONE
                    overlay.setOnClickListener(null)

                    restoreSoftInputModeAfterPasswordOverlay()
                }.onFailure {
                }
            }

            runCatching {
                et.requestFocus()
            }.onFailure {
            }

            et.post {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }
            }
        }


    private fun extractFileName(uri: Uri): String {
        var result: String? = null
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        } catch (_: Exception) { }
        return result ?: uri.lastPathSegment ?: getString(R.string.unknown_pdf)
    }

    private fun writerProps(): WriterProperties =
        WriterProperties()
            .setFullCompressionMode(true)
            .setCompressionLevel(CompressionConstants.BEST_SPEED)

    private fun rdr(path: String, password: ByteArray? = null): PdfReader =
        PdfReader(
            path,
            ReaderProperties().apply {
                if (password != null) {
                    setPassword(password)
                }
            }
        ).apply {
            setMemorySavingMode(true)
            isCloseStream = true
            setUnethicalReading(true)
        }

    private fun batchValueOrDefault1(): Int {
        val sNow = batchPage.text?.toString()?.trim().orEmpty()
        val v = sNow.toIntOrNull()
        return if (v != null && v > 0) v else 1
    }

    private fun appendPdfToSourceTemp(srcPdf: File, passwordBytes: ByteArray? = null) {

        val outWork = sourceWorkFile()
        if (outWork.exists()) outWork.delete()

        val pageBatch = batchValueOrDefault1()

        PdfDocument(
            PdfWriter(outWork.absolutePath, writerProps())
        ).use { dest ->
            dest.setFlushUnusedObjects(true)

            fun totalPagesOf(path: String, pw: ByteArray?): Int =
                PdfDocument(rdr(path, pw)).use { it.numberOfPages }

            fun copyInBatches(inputPath: String, pw: ByteArray?) {
                val total = totalPagesOf(inputPath, pw)
                var from = 1
                while (from <= total) {
                    val to = min(from + pageBatch - 1, total)

                    PdfDocument(rdr(inputPath, pw)).use { src ->
                        src.copyPagesTo(from, to, dest, PdfVisibleAppearanceCopier(cacheDir))
                        runCatching { PdfCopySupport.flushCopiedObjects(dest, src) }
                    }

                    val added = to - from + 1
                    for (i in 0 until added) {
                        val p = dest.numberOfPages - i
                        if (p >= 1) runCatching { dest.getPage(p).flush() }
                    }
                    from = to + 1
                }
            }

            val sourceTemp = sourceTempFile()
            if (sourceTemp.exists()) copyInBatches(sourceTemp.absolutePath, null)
            copyInBatches(srcPdf.absolutePath, passwordBytes)
        }

        val target = sourceTempFile()
        if (target.exists()) target.delete()
        outWork.renameTo(target)

        val newTotal = sourceTempPageCount()
        if (sourceRotation.size < newTotal) {
            val oldRotation = sourceRotation
            sourceRotation = IntArray(newTotal)
            oldRotation.copyInto(sourceRotation)
        }
    }

    private fun addEmptyPageToSource() {
        val count = sourceTempPageCount()
        if (count <= 0) {
            Toast.makeText(this, getString(R.string.select_a_page), Toast.LENGTH_SHORT).show()
            return
        }

        showInProgress(getString(R.string.in_progress_adding_empty_page))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val selectedIdx = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

        val oldPer = run {
            val last = lastBuiltNupConfig ?: currentNupConfigFromInputs()
            (last.rows.coerceAtLeast(1)) * (last.cols.coerceAtLeast(1))
        }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val source = sourceTempFile()

                val firstPageSize: PageSize = PdfDocument(rdr(source.absolutePath)).use { src ->
                    val p = src.getPage(1).pageSize
                    PageSize(p.width, p.height)
                }

                val outWork = sourceWorkFile()
                if (outWork.exists()) outWork.delete()

                val oldPageCount = sourceTempPageCount()

                val selectedSrcPages: Set<Int> = if (selectedIdx.isNotEmpty() && oldPageCount > 0) {
                    buildSet {
                        selectedIdx.forEach { g ->
                            val start = g * oldPer + 1
                            val end = min(oldPageCount, start + oldPer - 1)
                            for (p in start..end) add(p)
                        }
                    }
                } else emptySet()

                PdfDocument(PdfWriter(outWork.absolutePath, writerProps())).use { dest ->
                    dest.setFlushUnusedObjects(true)

                    val pageBatch = batchValueOrDefault1()

                    fun copyRange1BasedPaged(from1: Int, to1: Int) {
                        var from = from1
                        while (from <= to1) {
                            val to = min(from + pageBatch - 1, to1)

                            PdfDocument(rdr(source.absolutePath)).use { src ->
                                src.copyPagesTo(from, to, dest)
                                runCatching { PdfCopySupport.flushCopiedObjects(dest, src) }
                            }

                            val added = to - from + 1
                            for (i in 0 until added) {
                                val p = dest.numberOfPages - i
                                if (p >= 1) runCatching { dest.getPage(p).flush() }
                            }

                            from = to + 1
                        }
                    }

                    if (oldPageCount > 0) copyRange1BasedPaged(1, oldPageCount)

                    val newPage = dest.addNewPage(firstPageSize)
                    runCatching { newPage.flush() }
                }

                val target = sourceTempFile()
                if (target.exists()) target.delete()
                outWork.renameTo(target)

                val newTotal = oldPageCount + 1
                if (sourceRotation.size < newTotal) {
                    val oldRotation = sourceRotation
                    sourceRotation = IntArray(newTotal)
                    oldRotation.copyInto(sourceRotation)
                }

                createTempPdfInternal()

                withContext(Dispatchers.Main) {
                    resetThumbDocKey("addEmptyPageToSource")

                    val per = perGroup()
                    val indicesToSelectAfter: Set<Int> =
                        if (selectedSrcPages.isNotEmpty())
                            selectedSrcPages.map { p -> (p - 1) / per }.toSet()
                        else emptySet()

                    val onReloadStarted: () -> Unit = {
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }

                    reloadThumbnailsFromPlp(
                        targetIndex = null,
                        targetOffsetPx = 0,
                        restorePrevious = true,
                        indicesToSelect = indicesToSelectAfter,
                        releaseUiAtStart = false,
                        onStarted = onReloadStarted
                    )

                    updateButtonsState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.failed_to_add_empty_page_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private suspend fun createTempPdfInternal() = withContext(Dispatchers.IO) {
        val final = plpTempFile()
        val work  = File(cacheDir, "${PLP_TEMP_NAME}.part")

        if (work.exists()) work.delete()
        createNupPdf(work)

        if (final.exists()) final.delete()
        work.renameTo(final)

        lastBuiltNupConfig = currentNupConfigFromInputs()
    }

    private fun regeneratePlpAsyncAndReloadThumbnails() {
        if (suppressNup) return

        if (isPlpRebuilding) return
        isPlpRebuilding = true

        showInProgress(getString(R.string.in_progress_page_layout))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val selectedIdx = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

        val totalSrcPages = sourceTempPageCount()

        val oldPer = run {
            val last = lastBuiltNupConfig ?: currentNupConfigFromInputs()
            (last.rows.coerceAtLeast(1)) * (last.cols.coerceAtLeast(1))
        }

        val newPer = run {
            val cur = currentNupConfigFromInputs()
            (cur.rows.coerceAtLeast(1)) * (cur.cols.coerceAtLeast(1))
        }

        val applySelection = !clearSelectionOnNextRebuild

        val indicesToSelectAfter: Set<Int> =
            if (applySelection && selectedIdx.isNotEmpty() && totalSrcPages > 0) {
                val selectedPages = mutableSetOf<Int>()
                selectedIdx.forEach { g ->
                    val start = g * oldPer + 1
                    val end = min(totalSrcPages, start + oldPer - 1)
                    for (p in start..end) selectedPages.add(p)
                }
                selectedPages.map { p -> (p - 1) / newPer }.toSet()
            } else emptySet()

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                createTempPdfInternal()
                withContext(Dispatchers.Main) {
                    resetThumbDocKey("regeneratePlp")

                    val onReloadStarted: () -> Unit = {
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }

                    reloadThumbnailsFromPlp(
                        targetIndex = null,
                        targetOffsetPx = 0,
                        restorePrevious = true,
                        indicesToSelect = indicesToSelectAfter,
                        releaseUiAtStart = false,
                        onStarted = onReloadStarted
                    )

                    updateButtonsState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.failed_to_build_pages_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    isPlpRebuilding = false
                    clearSelectionOnNextRebuild = false
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun clearThumbnails() {
        val oldCount = viewModel.pageItems.size
        viewModel.pageItems.forEach { it.thumbnail?.recycle() }
        if (oldCount > 0) {
            viewModel.pageItems.clear()
            adapter.notifyItemRangeRemoved(0, oldCount)
        } else {
            viewModel.pageItems.clear()
        }
    }

    private fun reloadThumbnailsFromPlp(
        targetIndex: Int? = null,
        targetOffsetPx: Int = 0,
        restorePrevious: Boolean = true,
        indicesToSelect: Set<Int>? = null,
        releaseUiAtStart: Boolean = false,
        onStarted: (() -> Unit)? = null
    ) {
        val myGen = ++reloadThumbnailsGeneration

        if (releaseUiAtStart) {
            hideInProgressIfShown()
        }

        val shouldDeferUnlock = (orientationLockPrevRequested != null)
        if (shouldDeferUnlock) {
            deferOrientationUnlockUntilThumbnailsReady = true
            deferredOrientationUnlockRequested = false
        }

        val lm = binding.rvThumbnails.layoutManager as LinearLayoutManager
        val firstVisiblePosition = lm.findFirstVisibleItemPosition()
        val offset = lm.findViewByPosition(firstVisiblePosition)?.top ?: 0

        clearThumbnails()

        var releasedUiOnce = false
        var preDrawListener: ViewTreeObserver.OnPreDrawListener? = null
        var timeoutRunnable: Runnable? = null
        val pendingKeys = LinkedHashSet<String>()

        fun cleanupWaitersIfOwner() {
            try {
                preDrawListener?.let { l ->
                    if (binding.rvThumbnails.viewTreeObserver.isAlive) {
                        binding.rvThumbnails.viewTreeObserver.removeOnPreDrawListener(l)
                    }
                }
            } catch (_: Exception) {
            }
            preDrawListener = null

            timeoutRunnable?.let { r ->
                binding.rvThumbnails.removeCallbacks(r)
            }
            timeoutRunnable = null

            if (myGen == reloadThumbnailsGeneration) {
                runCatching { adapter.setOnThumbnailCachedListener(null) }
            }

            pendingKeys.clear()
        }

        fun releaseDeferredUnlockAndInvokeOnStarted() {
            if (releasedUiOnce) return

            if (myGen != reloadThumbnailsGeneration) {
                releasedUiOnce = true
                cleanupWaitersIfOwner()
                return
            }

            releasedUiOnce = true
            cleanupWaitersIfOwner()

            if (shouldDeferUnlock) {
                deferOrientationUnlockUntilThumbnailsReady = false
            }

            onStarted?.invoke()

            runCatching {
                binding.overlayProgressDialog.findViewById<MaterialButton>(R.id.progress_bar_cancel)?.isEnabled = false

                clearBackupStateKeysFromPrefs()
            }

            binding.overlayProgressDialog.post {
                if (binding.overlayProgressDialog.isVisible) return@post
                if (isSigningCancelled) return@post

                runCatching {
                    val srcCopy = File(cacheDir, SOURCE_TEMP_COPY_NAME)
                    if (srcCopy.exists()) srcCopy.delete()
                }
                runCatching {
                    val plpCopy = File(cacheDir, PLP_TEMP_COPY_NAME)
                    if (plpCopy.exists()) plpCopy.delete()
                }
            }

            if (shouldDeferUnlock && deferredOrientationUnlockRequested) {
                deferredOrientationUnlockRequested = false
                unlockScreenOrientation()
            }

            binding.rvThumbnails.post {
                if (isFinishing || isDestroyed) return@post
                maybeRunDeferredUiModeRecreate()
            }
        }

        val job = lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                try {
                    val plp = plpTempFile()
                    val srcFile = sourceTempFile()
                    if (!plp.exists() || !srcFile.exists()) return@withContext emptyList()

                    val per = perGroup()
                    val totalSrcPages = sourceTempPageCount()
                    if (totalSrcPages <= 0) return@withContext emptyList()

                    val plpPages = (totalSrcPages + per - 1) / per
                    val list = ArrayList<PageItem>(plpPages)

                    val cfg = mappingConfig()
                    val rows = max(1, min(100, cfg.rows))
                    val cols = max(1, min(100, cfg.cols))
                    val isLandscape = cfg.isLandscape
                    val basePs = if (isLandscape) PageSize.A4.rotate() else PageSize.A4
                    val isSingleUp = (rows * cols) == 1

                    val psForPlpPageFallback = if (isSingleUp) {
                        if (!isLandscape) PageSize.A4 else basePs
                    } else {
                        basePs
                    }
                    val fallbackW = psForPlpPageFallback.width
                    val fallbackH = psForPlpPageFallback.height

                    val skipReadingAnyPdfSize = (rows > 1 || cols > 1)

                    if (skipReadingAnyPdfSize) {
                        for (g in 0 until plpPages) {
                            val pageNumberText = if (per == 1) {
                                "${g + 1}/$totalSrcPages"
                            } else {
                                val totalGroups = (totalSrcPages + per - 1) / per
                                "${g + 1}/$totalGroups"
                            }

                            list.add(
                                PageItem(
                                    thumbnail = null,
                                    filePath = plp.absolutePath,
                                    pageIndex = g,
                                    widthPts = fallbackW,
                                    heightPts = fallbackH,
                                    pageNumberText = pageNumberText
                                )
                            )
                        }
                    } else {
                        val batchSize = batchValueOrDefault1()

                        val widths  = FloatArray(totalSrcPages) { fallbackW }
                        val heights = FloatArray(totalSrcPages) { fallbackH }

                        var startPage = 0
                        while (startPage < totalSrcPages) {
                            val endExclusive = min(totalSrcPages, startPage + batchSize)

                            val reader = PdfReader(srcFile.absolutePath)
                            val pdfDoc = PdfDocument(reader)
                            try {
                                val srcPageCount = pdfDoc.numberOfPages
                                val lastPageToRead = min(endExclusive, srcPageCount)

                                for (pageZeroBased in startPage until lastPageToRead) {
                                    val pageIndex1Based = pageZeroBased + 1
                                    runCatching {
                                        val page = pdfDoc.getPage(pageIndex1Based)

                                        val box = page.cropBox ?: page.mediaBox
                                        val w = box.width
                                        val h = box.height

                                        widths[pageZeroBased] = w
                                        heights[pageZeroBased] = h
                                    }.onFailure {
                                    }
                                }
                            } finally {
                                runCatching { pdfDoc.close() }
                            }

                            startPage = endExclusive
                        }

                        for (g in 0 until plpPages) {
                            val pageNumberText = if (per == 1) {
                                "${g + 1}/$totalSrcPages"
                            } else {
                                val totalGroups = (totalSrcPages + per - 1) / per
                                "${g + 1}/$totalGroups"
                            }

                            val firstSrcPageZeroBased = g * per

                            val wPtsForLabel =
                                if (firstSrcPageZeroBased in 0 until totalSrcPages) widths[firstSrcPageZeroBased]
                                else fallbackW

                            val hPtsForLabel =
                                if (firstSrcPageZeroBased in 0 until totalSrcPages) heights[firstSrcPageZeroBased]
                                else fallbackH

                            list.add(
                                PageItem(
                                    thumbnail = null,
                                    filePath = plp.absolutePath,
                                    pageIndex = g,
                                    widthPts = wPtsForLabel,
                                    heightPts = hPtsForLabel,
                                    pageNumberText = pageNumberText
                                )
                            )
                        }
                    }

                    list
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    emptyList()
                }
            }

            if (items.isEmpty()) {
                updateButtonsState()

                releaseDeferredUnlockAndInvokeOnStarted()
                return@launch
            }

            viewModel.pageItems.addAll(items)
            adapter.notifyItemRangeInserted(0, items.size)

            binding.rvThumbnails.post {
                val lm2 = binding.rvThumbnails.layoutManager as? LinearLayoutManager

                when {
                    targetIndex != null -> lm2?.scrollToPositionWithOffset(targetIndex, targetOffsetPx)
                    restorePrevious && firstVisiblePosition != RecyclerView.NO_POSITION ->
                        lm2?.scrollToPositionWithOffset(firstVisiblePosition, offset)
                }

                indicesToSelect?.let { set ->
                    val max = viewModel.pageItems.size
                    set.forEach { i ->
                        if (i in 0 until max) {
                            viewModel.pageItems[i].isSelected = true
                            adapter.notifyItemChanged(i, "force")
                        }
                    }
                    updateButtonsState()
                }

                timeoutRunnable = Runnable {
                    if (isFinishing || isDestroyed) return@Runnable

                    if (!releasedUiOnce && myGen == reloadThumbnailsGeneration) {
                        releaseDeferredUnlockAndInvokeOnStarted()
                    }
                }
                binding.rvThumbnails.postDelayed(timeoutRunnable!!, 10 * 60 * 1000L)

                preDrawListener = object : ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        if (releasedUiOnce) return true
                        if (myGen != reloadThumbnailsGeneration) {
                            releaseDeferredUnlockAndInvokeOnStarted()
                            return true
                        }

                        val f = lm2?.findFirstVisibleItemPosition() ?: RecyclerView.NO_POSITION
                        val l = lm2?.findLastVisibleItemPosition() ?: RecyclerView.NO_POSITION
                        if (f == RecyclerView.NO_POSITION || l == RecyclerView.NO_POSITION || l < f) {
                            return true
                        }

                        try {
                            if (binding.rvThumbnails.viewTreeObserver.isAlive) {
                                binding.rvThumbnails.viewTreeObserver.removeOnPreDrawListener(this)
                            }
                        } catch (_: Exception) {
                        }
                        preDrawListener = null

                        adapter.notifyItemRangeChanged(f, l - f + 1, "force")

                        val start = (f - 4).coerceAtLeast(0)
                        val end = (l + 4).coerceAtMost(adapter.itemCount - 1)
                        if (start > end) {
                            releaseDeferredUnlockAndInvokeOnStarted()
                            return true
                        }

                        val rangeToWait = start..end
                        adapter.prefetchAroundVisible(this@MainActivity, rangeToWait)

                        pendingKeys.clear()
                        for (i in rangeToWait) {
                            adapter.getCacheKeyForPosition(i)?.let { pendingKeys.add(it) }
                        }

                        run {
                            val it = pendingKeys.iterator()
                            while (it.hasNext()) {
                                val k = it.next()
                                if (adapter.isThumbnailCachedByKey(k)) it.remove()
                            }
                        }

                        if (pendingKeys.isEmpty()) {
                            releaseDeferredUnlockAndInvokeOnStarted()
                            return true
                        }

                        adapter.setOnThumbnailCachedListener { key ->
                            if (releasedUiOnce) return@setOnThumbnailCachedListener
                            if (myGen != reloadThumbnailsGeneration) return@setOnThumbnailCachedListener

                            if (pendingKeys.remove(key)) {
                                if (pendingKeys.isEmpty()) {
                                    binding.rvThumbnails.post {
                                        releaseDeferredUnlockAndInvokeOnStarted()
                                    }
                                }
                            }
                        }

                        run {
                            val it = pendingKeys.iterator()
                            while (it.hasNext()) {
                                val k = it.next()
                                if (adapter.isThumbnailCachedByKey(k)) it.remove()
                            }
                        }
                        if (pendingKeys.isEmpty()) {
                            releaseDeferredUnlockAndInvokeOnStarted()
                        }

                        return true
                    }
                }

                try {
                    binding.rvThumbnails.viewTreeObserver.addOnPreDrawListener(preDrawListener)
                } catch (_: Exception) {
                    releaseDeferredUnlockAndInvokeOnStarted()
                }
            }

            updateButtonsState()
        }

        activeJobs.add(job)
        job.invokeOnCompletion { cause ->
            activeJobs.remove(job)

            if (cause != null) {
                binding.rvThumbnails.post {
                    releaseDeferredUnlockAndInvokeOnStarted()
                }
            }
        }
    }

    private fun mappingConfig(): NupConfig {
        return lastBuiltNupConfig ?: currentNupConfigFromInputs()
    }

    private fun perGroup(): Int {
        val cfg = mappingConfig()
        val r = max(1, min(100, cfg.rows))
        val c = max(1, min(100, cfg.cols))
        return r * c
    }

    private fun persistPlpOrderToSourceTemp() {
        if (viewModel.pageItems.isEmpty()) return

        showInProgress(getString(R.string.in_progress_reordering))
        lockScreenOrientation()

        val selectedIdx = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

        val ordered = viewModel.pageItems.toList()
        val per = perGroup()

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val srcFile = sourceTempFile()
                if (!srcFile.exists()) {
                    withContext(Dispatchers.Main) {
                        hideInProgressIfShown()
                    }
                    return@launch
                }

                val totalSrcPages = sourceTempPageCount()

                val outWork = sourceWorkFile()
                if (outWork.exists()) outWork.delete()

                PdfDocument(PdfWriter(outWork.absolutePath, writerProps())).use { dest ->
                    dest.setFlushUnusedObjects(true)

                    val pageBatch = batchValueOrDefault1()

                    fun copyRange1BasedPaged(from1: Int, to1: Int) {
                        var from = from1
                        while (from <= to1) {
                            val to = min(from + pageBatch - 1, to1)
                            PdfDocument(rdr(srcFile.absolutePath)).use { src ->
                                src.copyPagesTo(from, to, dest)
                                runCatching { PdfCopySupport.flushCopiedObjects(dest, src) }
                            }
                            val added = to - from + 1
                            for (i in 0 until added) {
                                val p = dest.numberOfPages - i
                                if (p >= 1) runCatching { dest.getPage(p).flush() }
                            }
                            from = to + 1
                        }
                    }

                    var runStartGroup: Int? = null
                    var runEndGroup: Int? = null

                    fun flushRunIfAny() {
                        val rs = runStartGroup
                        val re = runEndGroup
                        if (rs != null && re != null) {
                            val firstStart0 = rs * per
                            val lastEnd0 = min(totalSrcPages - 1, re * per + (per - 1))
                            if (firstStart0 <= lastEnd0) {
                                val from1 = firstStart0 + 1
                                val to1   = lastEnd0 + 1
                                copyRange1BasedPaged(from1, to1)
                            }
                        }
                        runStartGroup = null
                        runEndGroup = null
                    }

                    for (item in ordered) {
                        val gi = item.pageIndex
                        if (runStartGroup == null) {
                            runStartGroup = gi
                            runEndGroup = gi
                        } else if (gi == (runEndGroup!! + 1)) {
                            runEndGroup = gi
                        } else {
                            flushRunIfAny()
                            runStartGroup = gi
                            runEndGroup = gi
                        }
                    }
                    flushRunIfAny()
                }

                if (srcFile.exists()) srcFile.delete()
                outWork.renameTo(srcFile)

                val newRotation = IntArray(totalSrcPages)
                var destIndex = 0
                val oldRotation = sourceRotation.copyOf()
                ordered.forEach { item ->
                    val originalPlpIndex = item.pageIndex
                    val start = originalPlpIndex * per
                    val end = min(totalSrcPages - 1, start + per - 1)
                    if (start < totalSrcPages) {
                        for (i in start..end) {
                            if (destIndex < newRotation.size) {
                                newRotation[destIndex++] = oldRotation.getOrElse(i) { 0 }
                            }
                        }
                    }
                }
                sourceRotation = newRotation

                createTempPdfInternal()

                withContext(Dispatchers.Main) {
                    resetThumbDocKey("reorder")

                    val onReloadStarted: () -> Unit = {
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }

                    reloadThumbnailsFromPlp(
                        targetIndex = null,
                        targetOffsetPx = 0,
                        restorePrevious = true,
                        indicesToSelect = selectedIdx.toSet(),
                        releaseUiAtStart = false,
                        onStarted = onReloadStarted
                    )

                    updateButtonsState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.reorder_failed_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun rotateLeftPlpPageGroupAndMirrorSource(plpIndex: Int) {
        updateRotationForPlpIndices(listOf(plpIndex), "rotateGroup:$plpIndex")
    }

    private fun rotateLeftSelectedPlpGroups() {        val selectedIdx = viewModel.pageItems
        .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }
        .sorted()

        if (selectedIdx.isEmpty()) return

        updateRotationForPlpIndices(selectedIdx, "rotateSelected")
    }

    private fun updateRotationForPlpIndices(plpIndices: List<Int>, resetKey: String) {
        val total = sourceTempPageCount()
        if (total <= 0) return

        showInProgress(getString(R.string.in_progress_rotation))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val selectedIdxBefore = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val per = perGroup()
                if (sourceRotation.size != total) {
                    sourceRotation = IntArray(total)
                }

                for (plpIndex in plpIndices) {
                    val groupStart = plpIndex * per
                    val groupEnd = min(total - 1, groupStart + per - 1)
                    if (groupStart <= groupEnd) {
                        for (i in groupStart..groupEnd) {
                            sourceRotation[i] = (sourceRotation[i] + 1) % 4
                        }
                    }
                }

                createTempPdfInternal()

                withContext(Dispatchers.Main) {
                    resetThumbDocKey(resetKey)

                    val onReloadStarted: () -> Unit = {
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }

                    reloadThumbnailsFromPlp(
                        targetIndex = null,
                        targetOffsetPx = 0,
                        restorePrevious = true,
                        indicesToSelect = selectedIdxBefore.toSet(),
                        releaseUiAtStart = false,
                        onStarted = onReloadStarted
                    )

                    updateButtonsState()
                }

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.failed_to_rotate_selected_groups_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun deletePlpPageGroupAndMirrorSource(plpIndex: Int) {
        val total = sourceTempPageCount()
        if (total <= 0) return
        val per = perGroup()

        showInProgress(getString(R.string.in_progress_delete))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val selectedIdxBefore = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

        val toReselectAfter: List<Int> = selectedIdxBefore
            .filter { it != plpIndex }
            .map { if (it > plpIndex) it - 1 else it }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val source = sourceTempFile()

                val totalBefore = sourceTempPageCount()
                if (sourceRotation.size != totalBefore) {
                    sourceRotation = IntArray(totalBefore)
                }

                val groupStart = plpIndex * per
                val groupEnd = min(total - 1, groupStart + per - 1)
                val toSkipCount = if (groupStart <= groupEnd) (groupEnd - groupStart + 1) else 0
                val remaining = total - toSkipCount

                if (remaining <= 0) {
                    clearCacheDir()
                    sourceRotation = IntArray(0)

                    withContext(Dispatchers.Main) {
                        clearThumbnails()
                        updateButtonsState()
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }
                    return@launch
                }

                val outWork = sourceWorkFile()
                if (outWork.exists()) outWork.delete()

                val pageBatch = batchValueOrDefault1()

                fun copyRange1BasedPaged(from1: Int, to1: Int, dest: PdfDocument, srcPath: String) {
                    var from = from1
                    while (from <= to1) {
                        val to = min(from + pageBatch - 1, to1)
                        PdfDocument(rdr(srcPath)).use { src ->
                            src.copyPagesTo(from, to, dest)
                            runCatching { PdfCopySupport.flushCopiedObjects(dest, src) }
                        }
                        val added = to - from + 1
                        for (i in 0 until added) {
                            val p = dest.numberOfPages - i
                            if (p >= 1) runCatching { dest.getPage(p).flush() }
                        }
                        from = to + 1
                    }
                }

                PdfDocument(PdfWriter(outWork.absolutePath, writerProps())).use { dest ->
                    dest.setFlushUnusedObjects(true)

                    var runStart: Int? = null
                    var currentRunEnd = -1

                    fun flushRun(rs0: Int, re0: Int) {
                        if (rs0 <= re0) {
                            val from1 = rs0 + 1
                            val to1   = re0 + 1
                            copyRange1BasedPaged(from1, to1, dest, source.absolutePath)
                        }
                    }

                    for (pZero in 0 until total) {
                        if (pZero in groupStart..groupEnd) {
                            runStart?.let { flushRun(it, currentRunEnd) }
                            runStart = null
                            continue
                        }
                        if (runStart == null) {
                            runStart = pZero
                            currentRunEnd = pZero
                        } else if (pZero == currentRunEnd + 1) {
                            currentRunEnd = pZero
                        } else {
                            flushRun(runStart, currentRunEnd)
                            runStart = pZero
                            currentRunEnd = pZero
                        }
                    }
                    runStart?.let { flushRun(it, currentRunEnd) }
                }

                if (source.exists()) source.delete()
                outWork.renameTo(source)

                val newRotationList = sourceRotation.toMutableList()
                val groupStartIdx = plpIndex * per
                val groupEndIdx = min(totalBefore - 1, groupStartIdx + per - 1)
                if (groupStartIdx <= groupEndIdx) {
                    for (i in groupEndIdx downTo groupStartIdx) {
                        if (i < newRotationList.size) {
                            newRotationList.removeAt(i)
                        }
                    }
                }
                sourceRotation = newRotationList.toIntArray()

                createTempPdfInternal()

                withContext(Dispatchers.Main) {
                    resetThumbDocKey("deleteGroup:$plpIndex")

                    val onReloadStarted: () -> Unit = {
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }

                    reloadThumbnailsFromPlp(
                        targetIndex = null,
                        targetOffsetPx = 0,
                        restorePrevious = true,
                        indicesToSelect = toReselectAfter.toSet(),
                        releaseUiAtStart = false,
                        onStarted = onReloadStarted
                    )

                    updateButtonsState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.failed_to_delete_page_group_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun deleteSelectedPlpGroups() {
        val total = sourceTempPageCount()
        if (total <= 0) return

        val selectedPlp = viewModel.pageItems
            .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }
            .sorted()

        if (selectedPlp.isEmpty()) return

        showInProgress(getString(R.string.in_progress_delete))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val per = perGroup()
                val source = sourceTempFile()

                val totalBefore = sourceTempPageCount()
                if (sourceRotation.size != totalBefore) {
                    sourceRotation = IntArray(totalBefore)
                }

                val toSkip = HashSet<Int>().apply {
                    for (pi in selectedPlp) {
                        val start = pi * per
                        val end = min(total - 1, start + per - 1)
                        for (i in start..end) add(i)
                    }
                }

                val remaining = total - toSkip.size
                if (remaining <= 0) {
                    clearCacheDir()
                    sourceRotation = IntArray(0)

                    withContext(Dispatchers.Main) {
                        clearThumbnails()
                        updateButtonsState()
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }
                    return@launch
                }

                val outWork = sourceWorkFile()
                if (outWork.exists()) outWork.delete()

                val pageBatch = batchValueOrDefault1()

                fun copyRange1BasedPaged(from1: Int, to1: Int, dest: PdfDocument, srcPath: String) {
                    var from = from1
                    while (from <= to1) {
                        val to = min(from + pageBatch - 1, to1)
                        PdfDocument(rdr(srcPath)).use { src ->
                            src.copyPagesTo(from, to, dest)
                            runCatching { PdfCopySupport.flushCopiedObjects(dest, src) }
                        }
                        val added = to - from + 1
                        for (i in 0 until added) {
                            val p = dest.numberOfPages - i
                            if (p >= 1) runCatching { dest.getPage(p).flush() }
                        }
                        from = to + 1
                    }
                }

                PdfDocument(PdfWriter(outWork.absolutePath, writerProps())).use { dest ->
                    dest.setFlushUnusedObjects(true)

                    var runStart: Int? = null
                    var currentRunEnd = -1

                    fun flushRun(rs0: Int, re0: Int) {
                        if (rs0 <= re0) {
                            val from1 = rs0 + 1
                            val to1   = re0 + 1
                            copyRange1BasedPaged(from1, to1, dest, source.absolutePath)
                        }
                    }

                    for (pZero in 0 until total) {
                        if (pZero in toSkip) {
                            runStart?.let { flushRun(it, currentRunEnd) }
                            runStart = null
                            continue
                        }
                        if (runStart == null) {
                            runStart = pZero
                            currentRunEnd = pZero
                        } else if (pZero == currentRunEnd + 1) {
                            currentRunEnd = pZero
                        } else {
                            flushRun(runStart, currentRunEnd)
                            runStart = pZero
                            currentRunEnd = pZero
                        }
                    }
                    runStart?.let { flushRun(it, currentRunEnd) }
                }

                if (source.exists()) source.delete()
                outWork.renameTo(source)

                val toSkipIndices = HashSet<Int>()
                selectedPlp.forEach { plpIdx ->
                    val start = plpIdx * per
                    val end = min(totalBefore - 1, start + per - 1)
                    (start..end).forEach { toSkipIndices.add(it) }
                }
                val newRotation = sourceRotation.filterIndexed { index, _ -> !toSkipIndices.contains(index) }
                sourceRotation = newRotation.toIntArray()

                createTempPdfInternal()

                withContext(Dispatchers.Main) {
                    resetThumbDocKey("deleteSelected")

                    for (i in selectedPlp.asReversed()) {
                        if (i in viewModel.pageItems.indices) {
                            val removed = viewModel.pageItems.removeAt(i)
                            removed.thumbnail = null
                            adapter.notifyItemRemoved(i)
                        }
                    }

                    val onReloadStarted: () -> Unit = {
                        hideInProgressIfShown()
                        unlockScreenOrientation()
                    }

                    reloadThumbnailsFromPlp(
                        releaseUiAtStart = false,
                        onStarted = onReloadStarted
                    )

                    updateButtonsState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.failed_to_delete_selected_groups_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun exportNamedOutputPdf(plp: File): File {
        cleanupOldExports()

        val baseName = buildOutputFileName().ifBlank { defaultDateForFileName() }
        val safe = sanitizeFileNameBase(baseName)
        val out = File(cacheDir, "$safe.pdf")
        return try {
            FileInputStream(plp).use { inp ->
                FileOutputStream(out).use { outP -> inp.copyTo(outP) }
            }
            out
        } catch (_: Exception) {
            plp
        }
    }

    private fun cleanupOldExports(keepRecent: Int = KEEP_RECENT_EXPORTS) {
        val protected = setOf(
            PLP_TEMP_NAME,
            SOURCE_TEMP_NAME,
            SOURCE_TEMP_WORK,
            SOURCE_TEMP_COPY_NAME,
            PLP_TEMP_COPY_NAME
        )

        val pdfs = cacheDir
            .listFiles { f -> f.isFile && f.extension.equals("pdf", true) && f.name !in protected }
            ?.toList()
            .orEmpty()

        val sorted = pdfs.sortedByDescending { it.lastModified() }

        if (sorted.size > keepRecent) {
            sorted.drop(keepRecent).forEach { it.delete() }
        }
    }

    private fun requestRvThumbnailsHeightUpdate() {
        if (!::binding.isInitialized) return

        val allowUpdateWithoutWindowFocus: Boolean = try {
            val anyTrackedDialogShowing = plpSizedDialogs.any { it.isShowing }

            val progressShowing = (
                    binding.overlayProgressDialog.isVisible ||
                            binding.overlayProgressDialogUpdateUi.isVisible
                    )
            val sigPosShowing = (binding.overlayDialogSignaturePosition.isVisible)

            anyTrackedDialogShowing || progressShowing || sigPosShowing
        } catch (_: Exception) {
            false
        }

        if (!hasWindowFocusFlag && !allowUpdateWithoutWindowFocus) {
            pendingRvUpdate = true
            return
        }

        if (isFinishing || isDestroyed) return

        val v = binding.rootScroll
        if (!v.isAttachedToWindow) return

        v.removeCallbacks(rvHeightUpdateRunnable)
        v.postDelayed(rvHeightUpdateRunnable, 80)
    }

    private fun setRvHeightSafely(newHeight: Int) {
        if (!::binding.isInitialized) return
        val rv = binding.rvThumbnails
        val lp = rv.layoutParams ?: return
        if (lp.height == newHeight) return

        suppressRootScrollLayoutCallback = true
        lp.height = newHeight
        rv.layoutParams = lp

        binding.rootScroll.postOnAnimation {
            suppressRootScrollLayoutCallback = false
        }
    }

    override fun onStart() {
        super.onStart()

        lastConfigSnapshotForDiff = Configuration(resources.configuration)

        startFoldableLayoutTracking()
    }

    private fun startFoldableLayoutTracking() {
        if (foldableInfoJob != null) return

        foldableInfoJob = lifecycleScope.launch {
            try {
                WindowInfoTracker.getOrCreate(this@MainActivity)
                    .windowLayoutInfo(this@MainActivity)
                    .collect { info ->
                        val foldableNow = info.displayFeatures.any { it is FoldingFeature }
                        isFoldableDevice = isFoldableDevice || foldableNow
                        requestRvThumbnailsHeightUpdate()
                    }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }

    private fun applyRvThumbnailsHeight() {
        if (!::binding.isInitialized) return
        if (isFinishing || isDestroyed) return

        val c = resources.configuration
        val portrait = (c.screenHeightDp >= c.screenWidthDp)

        val shouldFillLikeTabletPortrait =
            (!isFoldableDevice) && portrait && isTabletLikeDevice

        val minPx = resources.getDimensionPixelSize(R.dimen.dp_420)

        if (!shouldFillLikeTabletPortrait) {
            setRvHeightSafely(minPx)
            return
        }

        binding.rootScroll.post {
            if (!::binding.isInitialized) return@post
            if (isFinishing || isDestroyed) return@post

            val rv = binding.rvThumbnails
            val scroll = binding.rootScroll

            val bottom = bottomPanelView

            val locRv = IntArray(2)
            val locScroll = IntArray(2)
            rv.getLocationInWindow(locRv)
            scroll.getLocationInWindow(locScroll)

            val bottomShown = (bottom != null && bottom.isShown && bottom.height > 0)
            val reservedForBottomPanel = if (bottomShown) bottom.height else 0

            val extraPaddingBottom = max(0, scroll.paddingBottom - reservedForBottomPanel)

            val scrollBottomInWindow = locScroll[1] + scroll.height - extraPaddingBottom

            var effectiveBottomInWindow = scrollBottomInWindow
            if (bottomShown) {
                val locBottom = IntArray(2)
                bottom.getLocationInWindow(locBottom)
                effectiveBottomInWindow = min(effectiveBottomInWindow, locBottom[1])
            }

            val scrollTopInWindow = locScroll[1] + scroll.paddingTop
            val rvTopInWindow = max(locRv[1], scrollTopInWindow)

            var availablePx = effectiveBottomInWindow - rvTopInWindow
            if (availablePx < 0) availablePx = 0

            val section = rv.parent as? View
            val sectionLp = section?.layoutParams as? ViewGroup.MarginLayoutParams
            if (sectionLp != null && !bottomShown) {
                availablePx -= sectionLp.bottomMargin
                if (availablePx < 0) availablePx = 0
            }

            val targetPx = max(minPx, availablePx)
            setRvHeightSafely(targetPx)
        }
    }

    override fun onStop() {
        try {
            if (::binding.isInitialized) {
                binding.rootScroll.removeCallbacks(rvHeightUpdateRunnable)
            }
        } catch (_: Exception) { }

        suppressRootScrollLayoutCallback = false

        pendingRvUpdate = false
        hasWindowFocusFlag = false

        try {
            val u = lastGrantedViewUri
            if (u != null) {
                revokeUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (_: Exception) { }
        lastGrantedViewUri = null
        lastGrantedPkg = null
        foldableInfoJob?.cancel()
        foldableInfoJob = null

        super.onStop()
    }

    private fun isAndroidxPdfAvailable(): Boolean =
        try {
            Class.forName("androidx.pdf.viewer.fragment.PdfViewerFragment")
            true
        } catch (_: Throwable) { false }

    private fun isPdfViewerDeclared(): Boolean =
        try {
            packageManager.getActivityInfo(
                ComponentName(this, PdfViewer::class.java),
                0
            )
            true
        } catch (_: Exception) { false }

    private fun cleanupCacheExceptTemps() {
        val keep = setOf(SOURCE_TEMP_NAME, PLP_TEMP_NAME)
        cacheDir.listFiles()?.forEach { f ->
            if (f.name !in keep) {
                runCatching { f.deleteRecursively() }
            }
        }
    }

    private fun handleEditedPdfFromViewer(uri: Uri) {
        showInProgressUpdateUI(getString(R.string.in_progress_ui))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val work = File(cacheDir, "${PLP_TEMP_NAME}.edited")
                if (work.exists()) work.delete()

                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(work).use { output ->
                        input.copyTo(output)
                        output.flush()
                    }
                } ?: throw IOException(getString(R.string.input_stream_is_null))

                PdfDocument(rdr(work.absolutePath)).use { }

                val target = plpTempFile()
                if (target.exists()) target.delete()
                if (!work.renameTo(target)) {
                    FileInputStream(work).use { input ->
                        FileOutputStream(target).use { output ->
                            input.copyTo(output)
                            output.flush()
                        }
                    }
                    work.delete()
                }

                cleanupCacheExceptTemps()

                withContext(Dispatchers.Main) {
                    resetThumbDocKey("pdfViewerEdit")
                    reloadThumbnailsFromPlp(
                        targetIndex = null,
                        targetOffsetPx = 0,
                        restorePrevious = true,
                        releaseUiAtStart = false,
                        onStarted = {
                            hideInProgressIfShownUpdateUI()
                            unlockScreenOrientation()
                        }
                    )
                    updateButtonsState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.pdf_edits_save_failed, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShownUpdateUI()
                    unlockScreenOrientation()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    unlockScreenOrientation()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun scheduleCacheCleanupAfterExternalReturn() {
        pendingCacheCleanupAfterExternalReturn = true
        didPauseForExternalAction = false
    }

    private fun openPdfWithDriveOrOther(initialPageIndex: Int) {
        showInProgress(getString(R.string.in_progress_pdf_reading))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val job = lifecycleScope.launch {
            try {
                val plp = withContext(Dispatchers.IO) {
                    val f = plpTempFile()
                    if (!f.exists()) {
                        throw IllegalStateException(getString(R.string.temporary_pdf_not_found))
                    }
                    f
                }
                val named = withContext(Dispatchers.IO) { exportNamedOutputPdf(plp) }

                val uri = withContext(Dispatchers.IO) {
                    FileProvider.getUriForFile(this@MainActivity, "${packageName}.provider", named)
                }

                hideInProgressIfShown()
                unlockScreenOrientation()

                val shouldUseInternal: Boolean =
                    Build.VERSION.SDK_INT >= VERSION_CODES.P &&
                        runCatching {
                            val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                            synchronized(prefsBackupLock) {
                                prefs.getBoolean(KEY_LAST_INNER_PDF_READER, true)
                            }
                        }.getOrDefault(true)

                if (shouldUseInternal && isAndroidxPdfAvailable() && isPdfViewerDeclared()) {
                    try {
                        val i = Intent(this@MainActivity, PdfViewer::class.java).apply {
                            putExtra(PdfViewer.EXTRA_URI, uri.toString())
                            putExtra(PdfViewer.EXTRA_INITIAL_PAGE_INDEX, initialPageIndex)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        pdfViewerLauncher.launch(i)
                        return@launch
                    } catch (_: Exception) {
                    }
                }

                val baseViewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

                val pm = packageManager
                val chooserTitle = runCatching { getString(R.string.open_with) }.getOrElse { "Open with" }

                if (Build.VERSION.SDK_INT >= VERSION_CODES.S) {
                    val resolves = pm.queryIntentActivities(baseViewIntent, 0)
                    val hasOther = resolves.any { it.activityInfo.packageName != packageName }
                    if (!hasOther) {
                        Toast.makeText(this@MainActivity, getString(R.string.no_app_can_open_pdf), Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    val ownComponents = resolves
                        .filter { it.activityInfo.packageName == packageName }
                        .map { ComponentName(it.activityInfo.packageName, it.activityInfo.name) }
                        .toTypedArray()

                    val chooser = Intent.createChooser(baseViewIntent, chooserTitle).apply {
                        if (ownComponents.isNotEmpty()) {
                            putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, ownComponents)
                        }
                    }

                    val old = StrictMode.allowThreadDiskReads()
                    try {
                        startActivity(chooser)
                        scheduleCacheCleanupAfterExternalReturn()
                    } finally {
                        StrictMode.setThreadPolicy(old)
                    }
                } else {
                    val resolves = pm.queryIntentActivities(baseViewIntent, 0)
                    val others = resolves.filter { it.activityInfo.packageName != packageName }
                    if (others.isEmpty()) {
                        Toast.makeText(this@MainActivity, getString(R.string.no_app_can_open_pdf), Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    val ownComponents = resolves
                        .filter { it.activityInfo.packageName == packageName }
                        .map { ComponentName(it.activityInfo.packageName, it.activityInfo.name) }

                    ownComponents.forEach {
                        pm.setComponentEnabledSetting(
                            it,
                            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                            PackageManager.DONT_KILL_APP
                        )
                    }

                    val old = StrictMode.allowThreadDiskReads()
                    try {
                        startActivity(Intent.createChooser(baseViewIntent, chooserTitle))
                        scheduleCacheCleanupAfterExternalReturn()
                    } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, getString(R.string.no_app_can_open_pdf), Toast.LENGTH_LONG).show()
                    } finally {
                        StrictMode.setThreadPolicy(old)
                        Handler(Looper.getMainLooper()).postDelayed({
                            ownComponents.forEach { comp ->
                                pm.setComponentEnabledSetting(
                                    comp,
                                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                                    PackageManager.DONT_KILL_APP
                                )
                            }
                        }, 500)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                hideInProgressIfShown()
                unlockScreenOrientation()
                Toast.makeText(this@MainActivity, getString(R.string.failed_to_open_pdf_with_msg, e.message), Toast.LENGTH_LONG).show()
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun printNupPdf() {
        showInProgress(getString(R.string.in_progress_print))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val job = lifecycleScope.launch {
            try {
                val (namedPath, namedName) = withContext(Dispatchers.IO) {
                    val plp = run {
                        val f = plpTempFile()
                        if (!f.exists()) {
                            throw IllegalStateException(getString(R.string.temporary_pdf_not_found))
                        }
                        f
                    }
                    val named = exportNamedOutputPdf(plp)
                    named.absolutePath to named.name
                }

                hideInProgressIfShown()
                unlockScreenOrientation()

                val printManager = getSystemService(PrintManager::class.java)
                if (printManager == null) {
                    Toast.makeText(this@MainActivity, getString(R.string.print_service_not_available), Toast.LENGTH_LONG).show()
                    return@launch
                }

                val adapter = PdfDocumentAdapter(namedPath, namedName)
                printManager.print(namedName, adapter, PrintAttributes.Builder().build())
                scheduleCacheCleanupAfterExternalReturn()

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                hideInProgressIfShown()
                unlockScreenOrientation()
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.failed_to_generate_pdf_with_msg, e.message),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun saveNupPdf() {

        val needsOutputPassword = passwordOutCb.isChecked
        if (!needsOutputPassword) {
            showInProgress(getString(R.string.in_progress_save))
            lockScreenOrientation()
        }

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val job = lifecycleScope.launch {
            try {
                val outputPasswordBytes: ByteArray? = if (needsOutputPassword) {
                    val pw = withContext(Dispatchers.Main) { getConfirmedOutputPasswordOrNull() }
                    if (pw == null) {
                        return@launch
                    }

                    showInProgress(getString(R.string.in_progress_save))
                    lockScreenOrientation()

                    pw
                } else null

                val (namedPath, namedName) = withContext(Dispatchers.IO) {
                    val plp = run {
                        val f = plpTempFile()
                        if (!f.exists()) {
                            throw IllegalStateException(getString(R.string.temporary_pdf_not_found))
                        }
                        f
                    }
                    val named = exportNamedOutputPdf(plp)

                    if (outputPasswordBytes != null) {
                        encryptPdfInPlace(named, outputPasswordBytes)
                    }

                    named.absolutePath to named.name
                }

                pendingSaveNamedPath = namedPath
                pendingSaveNamedDisplayName = namedName

                hideInProgressIfShown()
                unlockScreenOrientation()

                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_TITLE, namedName)
                }
                saveDocumentLauncher.launch(intent)

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                hideInProgressIfShown()
                unlockScreenOrientation()
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.failed_to_generate_pdf_with_msg, e.message),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun shareNupPdf() {

        val needsOutputPassword = passwordOutCb.isChecked
        if (!needsOutputPassword) {
            showInProgress(getString(R.string.in_progress_send))
            lockScreenOrientation()
        }

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        val job = lifecycleScope.launch {
            try {
                val outputPasswordBytes: ByteArray? = if (needsOutputPassword) {
                    val pw = withContext(Dispatchers.Main) { getConfirmedOutputPasswordOrNull() }
                    if (pw == null) {
                        return@launch
                    }

                    showInProgress(getString(R.string.in_progress_send))
                    lockScreenOrientation()

                    pw
                } else null

                val plp = withContext(Dispatchers.IO) {
                    val f = plpTempFile()
                    if (!f.exists()) {
                        throw IllegalStateException(getString(R.string.temporary_pdf_not_found))
                    }
                    f
                }
                val named = withContext(Dispatchers.IO) {
                    val nf = exportNamedOutputPdf(plp)
                    if (outputPasswordBytes != null) {
                        encryptPdfInPlace(nf, outputPasswordBytes)
                    }
                    nf
                }

                val uri = withContext(Dispatchers.IO) {
                    FileProvider.getUriForFile(this@MainActivity, "$packageName.provider", named)
                }

                hideInProgressIfShown()
                unlockScreenOrientation()
                sharePdfWithViewOptions(uri)

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                hideInProgressIfShown()
                unlockScreenOrientation()
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.failed_to_generate_share_pdf_with_msg, e.message),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private suspend fun promptForPasswordForOutput(titleResId: Int, errorHintResId: Int? = null): String? =
        suspendCancellableCoroutine { cont ->

            PdfProcessingForegroundService.stop(this@MainActivity)
            unlockScreenOrientation()

            applySoftInputModeForPasswordOverlay()

            val overlay = binding.overlayDialogPassword
            val panel = binding.overlayDialogPasswordPanel

            panel.removeAllViews()
            val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_password, panel, false)
            panel.addView(dialogView)

            overlay.visibility = View.VISIBLE

            overlay.bringToFront()

            overlay.setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)
                restoreSoftInputModeAfterPasswordOverlay()
                if (!cont.isCompleted) cont.resume(null)
            }
            panel.setOnClickListener {
            }

            (dialogView as? ViewGroup)?.let { vg ->
                (vg.getChildAt(0) as? TextView)?.setText(titleResId)
            }

            val et = setupPasswordInputForDialog(
                dialogView = dialogView,
                showError = (errorHintResId != null),
                errorHintResId = errorHintResId
            )

            val btnOk     = dialogView.findViewById<Button>(R.id.pwd_ok)
            val btnCancel = dialogView.findViewById<Button>(R.id.pwd_cancel)

            btnOk.setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                val pwd = et.text?.toString()?.trim().orEmpty()

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)

                restoreSoftInputModeAfterPasswordOverlay()

                if (!cont.isCompleted) cont.resume(pwd)
            }

            btnCancel.setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                overlay.visibility = View.GONE
                overlay.setOnClickListener(null)

                restoreSoftInputModeAfterPasswordOverlay()

                if (!cont.isCompleted) cont.resume(null)
            }

            cont.invokeOnCancellation {
                runCatching {
                    val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                    val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                    runCatching { imm?.hideSoftInputFromWindow(token, 0) }

                    overlay.visibility = View.GONE
                    overlay.setOnClickListener(null)

                    restoreSoftInputModeAfterPasswordOverlay()
                }.onFailure {
                }
            }

            runCatching {
                et.requestFocus()
            }.onFailure {
            }

            et.post {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                val token = currentFocus?.windowToken ?: runCatching { overlay.windowToken }.getOrNull()
                runCatching { imm?.hideSoftInputFromWindow(token, 0) }
            }
        }

    private suspend fun getConfirmedOutputPasswordOrNull(): ByteArray? {
        var needErrorOnFirst = false
        while (true) {
            val first = promptForPasswordForOutput(
                titleResId = R.string.enter_pdf_password,
                errorHintResId = if (needErrorOnFirst) R.string.password_do_not_match else null
            ) ?: return null
            val second = promptForPasswordForOutput(
                titleResId = R.string.password_again,
                errorHintResId = null
            ) ?: return null

            if (first == second) {
                return first.toByteArray(Charsets.UTF_8)
            } else {
                needErrorOnFirst = true
            }
        }
    }

    private fun encryptPdfInPlace(file: File, password: ByteArray) {
        val tmp = File(file.parentFile, file.nameWithoutExtension + "_enc.pdf")

        val wp = writerProps().apply {
            setStandardEncryption(
                password,
                password,
                0,
                EncryptionConstants.ENCRYPTION_AES_256
            )
        }

        PdfDocument(
            PdfWriter(tmp.absolutePath, wp)
        ).use { dest ->
            dest.setFlushUnusedObjects(true)

            val batch = batchValueOrDefault1()
            PdfDocument(rdr(file.absolutePath)).use { src ->
                val total = src.numberOfPages
                var from = 1
                while (from <= total) {
                    val to = min(from + batch - 1, total)
                    src.copyPagesTo(from, to, dest)
                    runCatching { PdfCopySupport.flushCopiedObjects(dest, src) }
                    val added = to - from + 1
                    for (i in 0 until added) {
                        val p = dest.numberOfPages - i
                        if (p >= 1) runCatching { dest.getPage(p).flush() }
                    }
                    from = to + 1
                }
            }
        }

        if (!file.delete()) {
            runCatching { tmp.delete() }
            throw IOException(getString(R.string.failed_to_replace_original_pdf_with_encrypted_version))
        }
        if (!tmp.renameTo(file)) {
            throw IOException(getString(R.string.failed_to_rename_encrypted_pdf))
        }
    }

    @Throws(Exception::class)
    fun createNupPdf(outFile: File) {

        if (::adapter.isInitialized) runCatching { adapter.pausePrefetchAndCancel() }

        val writerProps = writerProps()

        try {

            val cfg = currentNupConfigFromInputs()
            val rows = cfg.rows
            val cols = cfg.cols
            val marginMm = cfg.marginMm
            val land = cfg.isLandscape
            val drawFrame = cfg.drawFrame
            val scaleIndRequested = cfg.scaleIndividually
            val fitIndRequested = cfg.fitIndividually
            val basePs = if (land) PageSize.A4.rotate()
            else PageSize.A4

            val source = sourceTempFile()
            if (!source.exists()) throw IllegalStateException(getString(R.string.no_source_pages))

            val totalSrcPages = PdfDocument(rdr(source.absolutePath)).use { it.numberOfPages }
            if (sourceRotation.size != totalSrcPages) {
                sourceRotation = IntArray(totalSrcPages)
            }

            val marginPt = marginMm * 72f / 25.4f
            val per      = (rows * cols).coerceAtLeast(1)
            val isPortraitMode = !land
            val isSingleUp     = (per == 1)

            val totalOutPages = if (totalSrcPages == 0) 0 else (totalSrcPages + per - 1) / per
            if (totalOutPages == 0) {
                FileOutputStream(outFile).use {

                }
                return
            }

            val outPagesPerChunk = batchValueOrDefault1()
            val partFiles = mutableListOf<File>()

            var outPageStart = 0
            var chunkIndex = 0
            while (outPageStart < totalOutPages) {

                val outPageEndInclusive = min(totalOutPages - 1, outPageStart + outPagesPerChunk - 1)

                val srcStart = outPageStart * per
                val srcEnd   = min(totalSrcPages - 1, (outPageEndInclusive + 1) * per - 1)

                val partFile = File((outFile.parentFile ?: cacheDir), outFile.name + ".p" + chunkIndex.toString())

                PdfDocument(rdr(source.absolutePath)).use { src ->
                    PdfDocument(
                        PdfWriter(partFile.absolutePath, writerProps)
                    ).use { pdf ->
                        pdf.setFlushUnusedObjects(true)

                        var idxLocal = 0
                        var globalIdx = srcStart
                        while (globalIdx <= srcEnd) {
                            val page1Based = globalIdx + 1
                            val sp = src.getPage(page1Based)
                            val sz = PdfCopySupport.visibleBox(sp)

                            var contentWidth  = sz.width
                            var contentHeight = sz.height

                            var contentOriginX = sz.x
                            var contentOriginY = sz.y
                            var hasBoundingBox = false

                            if (scaleIndRequested && fitIndRequested) {
                                runCatching {
                                    val fitGeometry = PdfFitGeometry()
                                    val listener = object : IEventListener {

                                        var box: Rectangle? = null

                                        private fun includeRect(r: Rectangle) {
                                            if (box == null) {
                                                box = Rectangle(r)
                                            } else {
                                                val b = box!!
                                                val bx1 = b.x
                                                val by1 = b.y
                                                val bx2 = b.x + b.width
                                                val by2 = b.y + b.height

                                                val rx1 = r.x
                                                val ry1 = r.y
                                                val rx2 = r.x + r.width
                                                val ry2 = r.y + r.height

                                                val nx1 = min(bx1, rx1)
                                                val ny1 = min(by1, ry1)
                                                val nx2 = max(bx2, rx2)
                                                val ny2 = max(by2, ry2)

                                                box = Rectangle(nx1, ny1, nx2 - nx1, ny2 - ny1)
                                            }
                                        }

                                        override fun eventOccurred(data: IEventData?, type: EventType?) {
                                            if (data == null || type == null) return
                                            when (type) {
                                                EventType.RENDER_TEXT -> {
                                                    val tri = data as TextRenderInfo
                                                    fitGeometry.includeText(tri, ::includeRect)
                                                }
                                                EventType.RENDER_IMAGE -> {
                                                    val iri = data as ImageRenderInfo
                                                    val ctm = iri.imageCtm
                                                    val p0 = Vector(0f, 0f, 1f).cross(ctm)
                                                    val p1 = Vector(1f, 0f, 1f).cross(ctm)
                                                    val p2 = Vector(0f, 1f, 1f).cross(ctm)
                                                    val p3 = Vector(1f, 1f, 1f).cross(ctm)

                                                    val xs = floatArrayOf(
                                                        p0.get(Vector.I1),
                                                        p1.get(Vector.I1),
                                                        p2.get(Vector.I1),
                                                        p3.get(Vector.I1)
                                                    )
                                                    val ys = floatArrayOf(
                                                        p0.get(Vector.I2),
                                                        p1.get(Vector.I2),
                                                        p2.get(Vector.I2),
                                                        p3.get(Vector.I2)
                                                    )

                                                    var minX = xs[0]
                                                    var maxX = xs[0]
                                                    var minY = ys[0]
                                                    var maxY = ys[0]
                                                    for (i in 1 until xs.size) {
                                                        val xx = xs[i]
                                                        val yy = ys[i]
                                                        if (xx < minX) minX = xx
                                                        if (xx > maxX) maxX = xx
                                                        if (yy < minY) minY = yy
                                                        if (yy > maxY) maxY = yy
                                                    }
                                                    val w = maxX - minX
                                                    val h = maxY - minY
                                                    if (w > 0 && h > 0) {
                                                        includeRect(Rectangle(minX, minY, w, h))
                                                    }
                                                }
                                                EventType.RENDER_PATH -> {
                                                    val pri = data as PathRenderInfo
                                                    PdfFitGeometry.includePath(pri, ::includeRect)
                                                }
                                                else -> {
                                                }
                                            }
                                        }

                                        override fun getSupportedEvents(): Set<EventType> {
                                            return setOf(
                                                EventType.RENDER_TEXT,
                                                EventType.RENDER_IMAGE,
                                                EventType.RENDER_PATH
                                            )
                                        }
                                    }

                                    val processor = PdfFitGeometry.Processor(listener)
                                    processor.processPageContent(sp)
                                    val box = listener.box
                                    if (box != null && box.width > 0f && box.height > 0f &&
                                        box.width.isFinite() && box.height.isFinite()
                                    ) {

                                        var effectiveBox = box

                                        val tol = 2f

                                        val bLeft = box.x
                                        val bBottom = box.y
                                        val bRight = box.x + box.width
                                        val bTop = box.y + box.height

                                        val pLeft = sz.x
                                        val pBottom = sz.y
                                        val pRight = sz.x + sz.width
                                        val pTop = sz.y + sz.height

                                        val looksFullPage =
                                            abs(bLeft - pLeft) <= tol &&
                                                    abs(bBottom - pBottom) <= tol &&
                                                    abs(bRight - pRight) <= tol &&
                                                    abs(bTop - pTop) <= tol

                                        val overshootsPage =
                                            bLeft < pLeft - 0.1f || bBottom < pBottom - 0.1f || bRight > pRight + 0.1f || bTop > pTop + 0.1f

                                        if (looksFullPage || overshootsPage) {

                                            val listenerNoOpFiltered = object : IEventListener {

                                                private var bbox: Rectangle? = null

                                                private val clipBox = Rectangle(
                                                    sz.x - tol,
                                                    sz.y - tol,
                                                    sz.width + 2f * tol,
                                                    sz.height + 2f * tol
                                                )

                                                private fun intersect(a: Rectangle, b: Rectangle): Rectangle? {
                                                    val x1 = max(a.x, b.x)
                                                    val y1 = max(a.y, b.y)
                                                    val x2 = min(a.x + a.width,  b.x + b.width)
                                                    val y2 = min(a.y + a.height, b.y + b.height)
                                                    if (x2 < x1 || y2 < y1) return null
                                                    return Rectangle(x1, y1, x2 - x1, y2 - y1)
                                                }

                                                private fun includeRect(r: Rectangle) {
                                                    val rr = intersect(r, clipBox) ?: return
                                                    val cur = bbox
                                                    if (cur == null) {
                                                        bbox = Rectangle(rr.x, rr.y, rr.width, rr.height)
                                                        return
                                                    }
                                                    val nx1 = min(cur.x, rr.x)
                                                    val ny1 = min(cur.y, rr.y)
                                                    val nx2 = max(cur.x + cur.width, rr.x + rr.width)
                                                    val ny2 = max(cur.y + cur.height, rr.y + rr.height)
                                                    bbox = Rectangle(nx1, ny1, nx2 - nx1, ny2 - ny1)
                                                }

                                                override fun eventOccurred(data: IEventData?, type: EventType?) {
                                                    if (data == null || type == null) return

                                                    when (type) {
                                                        EventType.RENDER_TEXT -> {
                                                            val tri = data as TextRenderInfo
                                                            fitGeometry.includeText(tri, ::includeRect)
                                                        }

                                                        EventType.RENDER_IMAGE -> {
                                                            val iri = data as ImageRenderInfo
                                                            val ctm = iri.imageCtm
                                                            val p0 = Vector(0f, 0f, 1f).cross(ctm)
                                                            val p1 = Vector(1f, 0f, 1f).cross(ctm)
                                                            val p2 = Vector(0f, 1f, 1f).cross(ctm)
                                                            val p3 = Vector(1f, 1f, 1f).cross(ctm)

                                                            val xs = floatArrayOf(p0.get(Vector.I1), p1.get(Vector.I1), p2.get(Vector.I1), p3.get(Vector.I1))
                                                            val ys = floatArrayOf(p0.get(Vector.I2), p1.get(Vector.I2), p2.get(Vector.I2), p3.get(Vector.I2))

                                                            var minX = xs[0]; var maxX = xs[0]
                                                            var minY = ys[0]; var maxY = ys[0]
                                                            for (i in 1 until 4) {
                                                                val xx = xs[i]; val yy = ys[i]
                                                                if (xx < minX) minX = xx
                                                                if (xx > maxX) maxX = xx
                                                                if (yy < minY) minY = yy
                                                                if (yy > maxY) maxY = yy
                                                            }
                                                            val w = maxX - minX
                                                            val h = maxY - minY
                                                            if (w > 0 && h > 0) includeRect(Rectangle(minX, minY, w, h))
                                                        }

                                                        EventType.RENDER_PATH -> {
                                                            val pri = data as PathRenderInfo

                                                            if (pri.operation == PathRenderInfo.NO_OP) return

                                                            PdfFitGeometry.includePath(pri, ::includeRect)
                                                        }

                                                        else -> Unit
                                                    }
                                                }

                                                override fun getSupportedEvents(): Set<EventType> =
                                                    setOf(EventType.RENDER_TEXT, EventType.RENDER_IMAGE, EventType.RENDER_PATH)

                                                fun getBounds(): Rectangle? = bbox
                                            }

                                            PdfFitGeometry.Processor(listenerNoOpFiltered).processPageContent(sp)
                                            val box2 = listenerNoOpFiltered.getBounds()

                                            if (box2 != null) {
                                                val shrinkW = box2.width < box.width - 2f
                                                val shrinkH = box2.height < box.height - 2f
                                                if (shrinkW || shrinkH) {
                                                    effectiveBox = box2
                                                }
                                            }
                                        }

                                        contentWidth = effectiveBox.width
                                        contentHeight = effectiveBox.height
                                        contentOriginX = effectiveBox.x
                                        contentOriginY = effectiveBox.y
                                        hasBoundingBox = true
                                    }
                                }
                            }

                            val rotation = sourceRotation.getOrElse(globalIdx) { 0 }
                            val isSideways = rotation == 1 || rotation == 3

                            val srcPageW = if (isSideways) sz.height else sz.width
                            val srcPageH = if (isSideways) sz.width else sz.height

                            if (idxLocal % per == 0) {
                                val psForThisPage =
                                    if (isPortraitMode && isSingleUp) PageSize.A4
                                    else basePs
                                pdf.addNewPage(psForThisPage)
                            }

                            val currentPage = pdf.lastPage
                            val canvas      = PdfCanvas(currentPage)

                            val psForThisPage = currentPage.pageSize
                            val cellW = (psForThisPage.width  - marginPt * (cols + 1)) / cols
                            val cellH = (psForThisPage.height - marginPt * (rows + 1)) / rows

                            val scale: Float
                            if (scaleIndRequested) {
                                val fitContentW = if (isSideways) contentHeight else contentWidth
                                val fitContentH = if (isSideways) contentWidth else contentHeight
                                scale = min(cellW / fitContentW, cellH / fitContentH)
                            } else {
                                val srcIsPortrait = srcPageH >= srcPageW
                                val refW = if (srcIsPortrait) PageSize.A4.width else PageSize.A4.height
                                val refH = if (srcIsPortrait) PageSize.A4.height else PageSize.A4.width
                                scale = min(min(cellW / refW, cellH / refH), 1f)
                            }

                            val col     = idxLocal % cols
                            val row     = (idxLocal / cols) % rows
                            val cellX   = marginPt + col * (cellW + marginPt)
                            val cellY   = marginPt + (rows - 1 - row) * (cellH + marginPt)

                            val finalScale: Float
                            if (isPortraitMode && isSingleUp) {
                                val fit =
                                    if (scaleIndRequested && fitIndRequested) {
                                        val fitContentW = if (isSideways) contentHeight else contentWidth
                                        val fitContentH = if (isSideways) contentWidth else contentHeight
                                        min(cellW / fitContentW, cellH / fitContentH)
                                    } else {
                                        min(cellW / srcPageW, cellH / srcPageH)
                                    }
                                val s = if (scaleIndRequested) fit else min(fit, 1f)
                                finalScale = if (!scaleIndRequested) {
                                    if (s < 1f) s else scale
                                } else {
                                    s
                                }
                            } else {
                                val fitToCell = min(cellW / srcPageW, cellH / srcPageH)
                                finalScale =
                                    if (!scaleIndRequested) {
                                        val fitNoUpscale = min(fitToCell, 1f)
                                        if (isSingleUp) {
                                            if (fitNoUpscale < 1f) fitNoUpscale else scale
                                        } else {
                                            val srcIsPortrait = srcPageH >= srcPageW
                                            val orientationMismatch =
                                                (land && srcIsPortrait) || (!land && !srcIsPortrait)

                                            if (!orientationMismatch) {
                                                min(scale, fitNoUpscale)
                                            } else {
                                                val fitW = cellW / sz.width
                                                val fitH = cellH / sz.height
                                                val limitIsWidth = fitW <= fitH
                                                val refW = if (srcIsPortrait) PageSize.A4.width else PageSize.A4.height
                                                val refH = if (srcIsPortrait) PageSize.A4.height else PageSize.A4.width
                                                val srcRel = if (limitIsWidth) (sz.width / refW) else (sz.height / refH)
                                                val threshold = 0.5f
                                                val preferFit = srcRel >= threshold
                                                val candidate = if (preferFit) fitNoUpscale else scale
                                                min(candidate, fitNoUpscale)
                                            }
                                        }
                                    } else {
                                        scale
                                    }
                            }

                            val fx  = sp.copyAsFormXObject(pdf)
                            fx.bBox = PdfArray(sz)
                            canvas.saveState()

                            val useBoundingBox = scaleIndRequested && fitIndRequested && hasBoundingBox

                            val scaledW: Float
                            val scaledH: Float
                            val originX: Float
                            val originY: Float

                            if (useBoundingBox) {
                                scaledW = contentWidth * finalScale
                                scaledH = contentHeight * finalScale
                                originX = contentOriginX
                                originY = contentOriginY
                            } else {
                                scaledW = sz.width * finalScale
                                scaledH = sz.height * finalScale
                                originX = sz.x
                                originY = sz.y
                            }

                            val rotatedScaledW = if (isSideways) scaledH else scaledW
                            val rotatedScaledH = if (isSideways) scaledW else scaledH

                            val offsetX = cellX + (cellW - rotatedScaledW) / 2
                            val offsetY = cellY + (cellH - rotatedScaledH) / 2

                            val a: Double
                            val b: Double
                            val c: Double
                            val d: Double
                            val e: Double
                            val f: Double

                            when (rotation) {
                                1 -> {
                                    a = 0.0
                                    b = finalScale.toDouble()
                                    c = -finalScale.toDouble()
                                    d = 0.0
                                    e = offsetX.toDouble() + scaledH + originY * finalScale
                                    f = offsetY.toDouble() - originX * finalScale
                                }
                                2 -> {
                                    a = -finalScale.toDouble()
                                    b = 0.0
                                    c = 0.0
                                    d = -finalScale.toDouble()
                                    e = offsetX.toDouble() + scaledW + originX * finalScale
                                    f = offsetY.toDouble() + scaledH + originY * finalScale
                                }
                                3 -> {
                                    a = 0.0
                                    b = -finalScale.toDouble()
                                    c = finalScale.toDouble()
                                    d = 0.0
                                    e = offsetX.toDouble() - originY * finalScale
                                    f = offsetY.toDouble() + scaledW + originX * finalScale
                                }
                                else -> {
                                    a = finalScale.toDouble()
                                    b = 0.0
                                    c = 0.0
                                    d = finalScale.toDouble()
                                    e = offsetX.toDouble() - originX * finalScale
                                    f = offsetY.toDouble() - originY * finalScale
                                }
                            }

                            PdfCopySupport.concatPlacementMatrix(canvas, a, b, c, d, e, f)

                            canvas.addXObjectWithTransformationMatrix(fx, 1f, 0f, 0f, 1f, 0f, 0f)
                            runCatching { fx.flush() }
                            canvas.restoreState()

                            if (drawFrame) {
                                canvas.setStrokeColor(ColorConstants.BLACK)
                                    .setLineWidth(1f)
                                    .rectangle(cellX.toDouble(), cellY.toDouble(), cellW.toDouble(), cellH.toDouble())
                                    .stroke()
                            }

                            if (idxLocal % per == per - 1 || globalIdx == srcEnd) {
                                runCatching { currentPage.flush() }
                            }

                            idxLocal++
                            globalIdx++
                        }
                    }
                }

                partFiles += partFile
                outPageStart = outPageEndInclusive + 1
                chunkIndex++
            }

            PdfDocument(
                PdfWriter(outFile.absolutePath, writerProps)
            ).use { destDoc ->
                destDoc.setFlushUnusedObjects(true)
                val partBatch = batchValueOrDefault1()

                for (pf in partFiles) {
                    val total = PdfDocument(rdr(pf.absolutePath)).use { it.numberOfPages }

                    var from = 1
                    while (from <= total) {
                        val to = min(from + partBatch - 1, total)

                        PdfDocument(rdr(pf.absolutePath)).use { partDoc ->
                            partDoc.copyPagesTo(from, to, destDoc)
                            runCatching { PdfCopySupport.flushCopiedObjects(destDoc, partDoc) }
                        }

                        val count = to - from + 1
                        for (i in 0 until count) {
                            val p = destDoc.numberOfPages - i
                            if (p >= 1) runCatching { destDoc.getPage(p).flush() }
                        }

                        from = to + 1
                    }
                }
            }

            partFiles.forEach { runCatching { it.delete() } }

        } finally {
            if (::adapter.isInitialized) runCatching { adapter.resumePrefetch() }
        }
    }

    @SuppressLint("RtlHardcoded")
    private fun showTimestampDialog() {

        val overlay = binding.overlayDialogTimestamp
        val panel = binding.overlayDialogTimestampPanel

        panel.removeAllViews()
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_timestamp, panel, false)
        panel.addView(dialogView)

        overlay.visibility = View.VISIBLE

        overlay.setOnClickListener {
            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)
        }
        panel.setOnClickListener {
        }

        val listView = dialogView.findViewById<ListView>(R.id.dts_listview)
        listView.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        val options = listOf(
            getString(R.string.opt_year_yyyy) to "[YYYY]",
            getString(R.string.opt_year_yy)   to "[YY]",
            getString(R.string.opt_month_mm)  to "[MM]",
            getString(R.string.opt_day_dd)    to "[DD]",
            getString(R.string.opt_hour_hh)   to "[hh]",
            getString(R.string.opt_minute_mm) to "[mm]",
            getString(R.string.opt_second_ss) to "[ss]"
        )
        val labels = options.map { it.first }
        val checked = BooleanArray(labels.size) { false }

        run {
            data class RowViews(
                val text: MaterialTextView,
                val cb: MaterialCheckBox
            )
            fun Int.dp(parent: ViewGroup) = (this * parent.resources.displayMetrics.density).toInt()

            val adapter = object : BaseAdapter() {
                override fun getCount(): Int = labels.size
                override fun getItem(position: Int): Any = labels[position]
                override fun getItemId(position: Int): Long = position.toLong()

                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val row = if (convertView == null) {
                        val container = LinearLayout(parent.context).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            )
                            setPadding(16.dp(parent), 12.dp(parent), 16.dp(parent), 12.dp(parent))
                            isClickable = true
                            isFocusable = true
                        }
                        val tv = MaterialTextView(parent.context).apply {
                            layoutParams = LinearLayout.LayoutParams(
                                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                            )
                            textAlignment = View.TEXT_ALIGNMENT_GRAVITY
                            gravity = Gravity.LEFT
                            TextViewCompat.setTextAppearance(
                                this, R.style.TextAppearance_PdfLabelPrinting_ListItem
                            )
                        }
                        val cb = MaterialCheckBox(parent.context).apply {
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { gravity = Gravity.RIGHT }
                            text = ""
                            isClickable = true
                            isFocusable = false

                            isUseMaterialThemeColors = false
                            buttonDrawable = AppCompatResources.getDrawable(context, R.drawable.ic_checkbox)
                            buttonTintList = AppCompatResources.getColorStateList(context, R.color.ic_checkbox_filename_color)

                            background = null
                            contentDescription = null
                        }
                        container.addView(tv)
                        container.addView(cb)
                        container.tag = RowViews(tv, cb)
                        container
                    } else convertView

                    val holder = row.tag as RowViews
                    holder.text.text = labels[position]
                    holder.cb.isChecked = checked[position]

                    val onToggle: (Int) -> Unit = { idx ->
                        checked[idx] = !checked[idx]
                        holder.cb.isChecked = checked[idx]
                    }
                    row.setOnClickListener { onToggle(position) }
                    holder.cb.setOnClickListener { onToggle(position) }

                    return row
                }
            }

            listView.adapter = adapter
        }

        val btnOk     = dialogView.findViewById<Button>(R.id.dts_btn_ok)
        val btnCancel = dialogView.findViewById<Button>(R.id.dts_btn_cancel)

        val fileNameEt: EditText = findViewById(R.id.file_name)

        btnOk?.setOnClickListener {
            val tokens = buildList {
                for (i in labels.indices) if (checked[i]) add(options[i].second)
            }
            if (tokens.isNotEmpty()) {
                val insert = tokens.joinToString(separator = "")
                val editable = fileNameEt.text ?: Editable.Factory.getInstance().newEditable("")
                val start = fileNameEt.selectionStart.coerceAtLeast(0).coerceAtMost(editable.length)
                editable.insert(start, insert)
                fileNameEt.text = editable
                fileNameEt.setSelection((start + insert.length).coerceAtMost(editable.length))
            }

            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)
        }

        btnCancel?.setOnClickListener {
            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)
        }
    }

    private fun buildOutputFileName(): String {
        val fileNameEt: EditText = findViewById(R.id.file_name)
        val tmpl = fileNameEt.text?.toString().orEmpty().trim()

        if (tmpl.isNotBlank()) return replaceTimeTokensIn(tmpl)

        val rowsStr = numberOfRows.text?.toString()?.trim().orEmpty()
        val colsStr = numberOfColumns.text?.toString()?.trim().orEmpty()
        val rows = rowsStr.toIntOrNull() ?: 1
        val cols = colsStr.toIntOrNull() ?: 1
        val isNormalByRowsCols = (rows in 0..1) && (cols in 0..1)

        val defTemplate = if (isNormalByRowsCols) {
            getString(R.string.default_tmpl_normal)
        } else {
            getString(R.string.default_tmpl_label)
        }

        return replaceTimeTokensIn(defTemplate)
    }

    private fun replaceTimeTokensIn(template: String): String {
        val now = Date()
        var s = template
        fun fmt(pat: String): String = SimpleDateFormat(pat, Locale.getDefault()).format(now)
        s = s.replace("[YYYY]", fmt("yyyy"))
        s = s.replace("[YY]",   fmt("yy"))
        s = s.replace("[MM]",   fmt("MM"))
        s = s.replace("[DD]",   fmt("dd"))
        s = s.replace("[hh]",   fmt("HH"))
        s = s.replace("[mm]",   fmt("mm"))
        s = s.replace("[ss]",   fmt("ss"))
        return s
    }

    private fun defaultDateForFileName(): String =
        SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())

    private fun sanitizeFileNameBase(name: String): String {
        if (name.isBlank()) return defaultDateForFileName()

        val cleaned = buildString(name.length) {
            for (ch in name) {
                if (ch.code in 0x00..0x1F ||
                    ch == '"' || ch == '<' || ch == '>' || ch == '|' ||
                    ch == ':' || ch == '*' || ch == '?' || ch == '/' || ch == '\\'
                ) append('_') else append(ch)
            }
        }

        var trimmed = cleaned.trimEnd { it == ' ' || it == '.' }
        if (trimmed.isEmpty()) trimmed = "_"

        if (trimmed == "." || trimmed == "..") trimmed = "_$trimmed"
        val reserved = setOf(
            "CON","PRN","AUX","NUL",
            "COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9",
            "LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9"
        )
        if (trimmed.uppercase() in reserved) trimmed = "_$trimmed"

        if (trimmed.length > MAX_BASE_LEN) trimmed = trimmed.take(MAX_BASE_LEN)

        return trimmed
    }

    private fun sharePdfWithViewOptions(uri: Uri) {
        val chooserTitle = getString(R.string.send_pdf_file)

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val displayName = (buildOutputFileName().ifBlank { defaultDateForFileName() }) + ".pdf"
            putExtra(Intent.EXTRA_TITLE, displayName)
            putExtra(Intent.EXTRA_SUBJECT, displayName)
        }

        val pm = packageManager

        if (Build.VERSION.SDK_INT >= VERSION_CODES.S) {
            val resolves = pm.queryIntentActivities(sendIntent, 0)
            val ownComponents = resolves
                .filter { it.activityInfo.packageName == packageName }
                .map { ComponentName(it.activityInfo.packageName, it.activityInfo.name) }
                .toTypedArray()

            val chooser = Intent.createChooser(sendIntent, chooserTitle).apply {
                if (ownComponents.isNotEmpty()) {
                    putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, ownComponents)
                }
            }
            try {
                startActivity(chooser)
                scheduleCacheCleanupAfterExternalReturn()
            } catch (_: Exception) {
                Toast.makeText(this, getString(R.string.no_app_can_share_pdf), Toast.LENGTH_LONG).show()
                lifecycleScope.launch(Dispatchers.IO) { cleanupCacheExceptTemps() }
            }
        } else {
            val resolves = pm.queryIntentActivities(sendIntent, 0)
            val ownComponents = resolves
                .filter { it.activityInfo.packageName == packageName }
                .map { ComponentName(it.activityInfo.packageName, it.activityInfo.name) }

            ownComponents.forEach {
                pm.setComponentEnabledSetting(
                    it,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }

            try {
                startActivity(Intent.createChooser(sendIntent, chooserTitle))
                scheduleCacheCleanupAfterExternalReturn()
            } catch (_: Exception) {
                Toast.makeText(this, getString(R.string.no_app_can_share_pdf), Toast.LENGTH_LONG).show()
                lifecycleScope.launch(Dispatchers.IO) { cleanupCacheExceptTemps() }
            } finally {
                Handler(Looper.getMainLooper()).postDelayed({
                    ownComponents.forEach { comp ->
                        pm.setComponentEnabledSetting(
                            comp,
                            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                            PackageManager.DONT_KILL_APP
                        )
                    }
                }, 500)
            }
        }
    }

    private fun signSelectedPagesOnSourceTemp(
        signatureFilePath: String,
        inputXMM: Float,
        inputYMM: Float,
        applyScanEffect: Boolean,
        applyGrayscalePage: Boolean
    ) {
        isSigningCancelled = false
        showInProgress(getString(R.string.in_progress_signing))
        lockScreenOrientation()

        val backupJob = lifecycleScope.launch {
            backupSelectionState()
        }
        activeJobs.add(backupJob)
        backupJob.invokeOnCompletion { activeJobs.remove(backupJob) }

        if (::adapter.isInitialized) runCatching { adapter.pausePrefetchAndCancel() }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            var handedOffToNupRebuild = false

            val isLand = landscape.isChecked
            val a4Wmm = if (isLand) 297f else 210f
            val a4Hmm = if (isLand) 210f else 297f

            val refPx = currentSignatureRefPx()

            val sigBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(signatureFilePath, sigBounds)
            if (sigBounds.outWidth <= 0 || sigBounds.outHeight <= 0) {
                withContext(Dispatchers.Main) {
                    hideInProgressIfShown()
                    Toast.makeText(this@MainActivity, getString(R.string.signature_image_invalid), Toast.LENGTH_LONG).show()
                }
                return@launch
            }

            val selectedPlpIndices = viewModel.pageItems
                .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }
                .sorted()

            if (selectedPlpIndices.isEmpty()) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.select_a_page), Toast.LENGTH_SHORT).show()
                    hideInProgressIfShown()
                }
                return@launch
            }

            if (isSigningCancelled) {
                return@launch
            }

            val plp = plpTempFile()
            if (!plp.exists()) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.select_a_page), Toast.LENGTH_SHORT).show()
                    hideInProgressIfShown()
                }
                return@launch
            }

            fun calcInSampleSize(srcW: Int, srcH: Int, dstW: Int, dstH: Int): Int {
                var sample = 1
                val halfW = srcW / 2
                val halfH = srcH / 2
                while (halfW / sample >= dstW && halfH / sample >= dstH) {
                    sample *= 2
                }
                return sample.coerceAtLeast(1)
            }

            fun applyScanEffectToBitmap(src: Bitmap): Bitmap {
                val w = src.width
                val h = src.height
                val out = createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val c = Canvas(out)

                val cm = ColorMatrix().apply { setSaturation(0.95f) }
                val contrast = 1.05f
                val brightness = -5f
                val m = floatArrayOf(
                    contrast, 0f, 0f, 0f, brightness,
                    0f, contrast, 0f, 0f, brightness,
                    0f, 0f, contrast, 0f, brightness,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.postConcat(ColorMatrix(m))
                val basePaint = Paint(
                    Paint.ANTI_ALIAS_FLAG
                            or Paint.DITHER_FLAG
                            or Paint.FILTER_BITMAP_FLAG
                ).apply {
                    colorFilter = ColorMatrixColorFilter(cm)
                }
                c.drawBitmap(src, 0f, 0f, basePaint)

                run {
                    val edgeAlpha = 12
                    val p = Paint(Paint.ANTI_ALIAS_FLAG)
                    p.shader = LinearGradient(
                        0f, 0f, 0f, h.toFloat(),
                        Color.argb(edgeAlpha, 0, 0, 0),
                        Color.TRANSPARENT,
                        Shader.TileMode.CLAMP
                    )
                    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
                    p.shader = LinearGradient(
                        0f, 0f, w.toFloat(), 0f,
                        Color.argb(edgeAlpha, 0, 0, 0),
                        Color.TRANSPARENT,
                        Shader.TileMode.CLAMP
                    )
                    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
                }

                return out
            }

            val writerProps = writerProps()
                .setFullCompressionMode(true)
                .setCompressionLevel(CompressionConstants.BEST_COMPRESSION)

            val tmpSigned = mutableMapOf<Int, File>()

            try {
                ParcelFileDescriptor.open(plp, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        for (idx in selectedPlpIndices) {
                            if (isSigningCancelled) {
                                return@launch
                            }

                            if (idx < 0 || idx >= renderer.pageCount) continue

                            renderer.openPage(idx).use { page: PdfRenderer.Page ->
                                val (targetW, targetH) = if (!isLand) {
                                    val k = refPx / page.width.toFloat()
                                    val w = refPx.toInt()
                                    val h = max(1, round(page.height * k).toInt())
                                    w to h
                                } else {
                                    val k = refPx / page.height.toFloat()
                                    val h = refPx.toInt()
                                    val w = max(1, round(page.width * k).toInt())
                                    w to h
                                }

                                var pageBmp = createBitmap(
                                    targetW,
                                    targetH,
                                    Bitmap.Config.ARGB_8888
                                )
                                var pageCanvas = Canvas(pageBmp)
                                pageCanvas.drawColor(Color.WHITE)

                                val s = min(
                                    targetW.toFloat() / page.width.toFloat(),
                                    targetH.toFloat() / page.height.toFloat()
                                )
                                val dx = (targetW - page.width * s) / 2f
                                val dy = (targetH - page.height * s) / 2f
                                val mat = Matrix().apply {
                                    postScale(s, s)
                                    postTranslate(dx, dy)
                                }
                                page.render(pageBmp, null, mat, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                                if (applyGrayscalePage) {
                                    val grayBmp = createBitmap(pageBmp.width, pageBmp.height, Bitmap.Config.ARGB_8888)
                                    val grayCanvas = Canvas(grayBmp)
                                    val cm = ColorMatrix().apply { setSaturation(0f) }
                                    val paint = Paint(
                                        Paint.ANTI_ALIAS_FLAG or
                                                Paint.DITHER_FLAG or
                                                Paint.FILTER_BITMAP_FLAG
                                    ).apply {
                                        colorFilter = ColorMatrixColorFilter(cm)
                                    }
                                    grayCanvas.drawBitmap(pageBmp, 0f, 0f, paint)
                                    if (!pageBmp.isRecycled) pageBmp.recycle()
                                    pageBmp = grayBmp
                                    pageCanvas = Canvas(pageBmp)
                                }

                                val pxPerMMX = targetW.toFloat() / a4Wmm
                                val pxPerMMY = targetH.toFloat() / a4Hmm
                                val pxX = inputXMM * pxPerMMX
                                val pxY = inputYMM * pxPerMMY

                                val refAxisPx = if (isLand) targetH.toFloat() else targetW.toFloat()
                                val sigScale = refAxisPx / refPx

                                val desiredSigW = max(1, round(sigBounds.outWidth  * sigScale).toInt())
                                val desiredSigH = max(1, round(sigBounds.outHeight * sigScale).toInt())

                                val sample = calcInSampleSize(sigBounds.outWidth, sigBounds.outHeight, desiredSigW, desiredSigH)
                                val sigOpts = BitmapFactory.Options().apply {
                                    inSampleSize = sample
                                    inPreferredConfig = Bitmap.Config.ARGB_8888
                                }
                                val sigBmp = BitmapFactory.decodeFile(signatureFilePath, sigOpts)
                                    ?: run {
                                        Log.w("MainActivity", "Signature decode failed at page $idx")
                                        if (!pageBmp.isRecycled) pageBmp.recycle()
                                        return@use
                                    }

                                val dst = RectF(pxX, pxY, pxX + desiredSigW, pxY + desiredSigH)
                                pageCanvas.drawBitmap(sigBmp, null, dst, null)
                                sigBmp.recycle()

                                val bitmapForExport: Bitmap =
                                    if (applyScanEffect) {
                                        val b = applyScanEffectToBitmap(pageBmp)
                                        if (!pageBmp.isRecycled) pageBmp.recycle()
                                        b
                                    } else {
                                        pageBmp
                                    }

                                val out = File(cacheDir, "${timeStamp}_signed_${System.currentTimeMillis()}_${idx}.pdf")
                                ByteArrayOutputStream().use { _ ->
                                    val wBmp = bitmapForExport.width
                                    val hBmp = bitmapForExport.height
                                    val intPixels = IntArray(wBmp * hBmp)
                                    bitmapForExport.getPixels(intPixels, 0, wBmp, 0, 0, wBmp, hBmp)
                                    val rgb = ByteArray(wBmp * hBmp * 3)
                                    var pIx = 0
                                    for (i in intPixels.indices) {
                                        val c = intPixels[i]
                                        rgb[pIx++] = ((c ushr 16) and 0xFF).toByte()
                                        rgb[pIx++] = ((c ushr 8) and 0xFF).toByte()
                                        rgb[pIx++] = (c and 0xFF).toByte()
                                    }
                                    val imageData = ImageDataFactory.create(
                                        wBmp,
                                        hBmp,
                                        3,
                                        8,
                                        rgb,
                                        null
                                    )

                                    val pageSize = if (isLand) PageSize.A4.rotate() else PageSize.A4

                                    PdfDocument(PdfWriter(out.absolutePath, writerProps)).use { destDoc: PdfDocument ->
                                        destDoc.setFlushUnusedObjects(true)

                                        val pg = destDoc.addNewPage(pageSize)

                                        val imgRatio = bitmapForExport.width.toFloat() / bitmapForExport.height.toFloat()
                                        val pageRatio = pageSize.width / pageSize.height
                                        val (destW, destH) = if (imgRatio > pageRatio) {
                                            val w = pageSize.width
                                            val h = w / imgRatio
                                            w to h
                                        } else {
                                            val h = pageSize.height
                                            val w = h * imgRatio
                                            w to h
                                        }
                                        val offX = (pageSize.width - destW) / 2f
                                        val offY = (pageSize.height - destH) / 2f

                                        PdfCanvas(pg).addImageFittedIntoRectangle(
                                            imageData,
                                            Rectangle(offX, offY, destW, destH),
                                            false
                                        )
                                        pg.flush()
                                    }
                                }

                                tmpSigned[idx] = out

                                if (!bitmapForExport.isRecycled) bitmapForExport.recycle()
                            }

                            yield()
                            delay(5L.milliseconds)
                        }
                    }
                }

                if (isSigningCancelled) {
                    return@launch
                }

                val plpWork = File(cacheDir, "${PLP_TEMP_NAME}.work")
                if (plpWork.exists()) plpWork.delete()

                PdfDocument(PdfWriter(plpWork.absolutePath, writerProps)).use { destDoc ->
                    destDoc.setFlushUnusedObjects(true)

                    val pageBatch = batchValueOrDefault1()

                    fun copyRange1BasedPaged(srcPath: String, from1: Int, to1: Int) {
                        var from = from1
                        while (from <= to1) {
                            val to = min(from + pageBatch - 1, to1)
                            PdfDocument(rdr(srcPath)).use { src ->
                                src.copyPagesTo(from, to, destDoc)
                                runCatching { PdfCopySupport.flushCopiedObjects(destDoc, src) }
                            }
                            val added = to - from + 1
                            for (i in 0 until added) {
                                val p = destDoc.numberOfPages - i
                                if (p >= 1) runCatching { destDoc.getPage(p).flush() }
                            }
                            from = to + 1
                        }
                    }

                    val totalPlpPages = PdfDocument(rdr(plp.absolutePath)).use { it.numberOfPages }

                    var runStart: Int? = null
                    for (p in 1..totalPlpPages) {
                        if (isSigningCancelled) {
                            return@launch
                        }
                        val zeroIdx = p - 1
                        val replacement = tmpSigned[zeroIdx]
                        if (replacement != null) {
                            runStart?.let { copyRange1BasedPaged(plp.absolutePath, it, p - 1) }
                            runStart = null

                            PdfDocument(rdr(replacement.absolutePath)).use { replDoc ->
                                replDoc.copyPagesTo(1, 1, destDoc)
                                runCatching { PdfCopySupport.flushCopiedObjects(destDoc, replDoc) }
                            }
                            runCatching { destDoc.lastPage?.flush() }
                        } else {
                            if (runStart == null) runStart = p
                        }
                    }
                    runStart?.let { copyRange1BasedPaged(plp.absolutePath, it, totalPlpPages) }
                }

                if (isSigningCancelled) {
                    runCatching { plpWork.delete() }
                    return@launch
                }

                if (plp.exists()) plp.delete()
                plpWork.renameTo(plp)

                val signedList = tmpSigned.entries.map { it.key to it.value.absolutePath }
                tmpSigned.clear()

                withContext(Dispatchers.Main) {
                    updateButtonsState()
                    currentSigFile = null
                    updateSignatureInputFilters()
                }

                if (isSigningCancelled) {
                    return@launch
                }

                handedOffToNupRebuild = true
                updateSourceWithSignedGroups(signedList) {
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, getString(R.string.signing_failed_with_msg, e.message), Toast.LENGTH_LONG).show()
                    hideInProgressIfShown()
                    unlockScreenOrientation()
                }
            } finally {
                tmpSigned.values.forEach { runCatching { it.delete() } }
                withContext(Dispatchers.Main) {
                    if (::adapter.isInitialized) runCatching { adapter.resumePrefetch() }

                    if (!handedOffToNupRebuild) {
                        unlockScreenOrientation()
                    }
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private fun updateSourceWithSignedGroups(
        signedList: List<Pair<Int, String>>,
        onReloadStarted: (() -> Unit)? = null
    ) {
        try {
            if (isSigningCancelled) {
                runCatching {
                    signedList.forEach { (_, path) -> runCatching { File(path).delete() } }
                }
                return
            }

            val srcFile = sourceTempFile()
            if (!srcFile.exists()) return

            val writerProps = writerProps()
            val signedMap = signedList.toMap()

            val outWorkSrc = sourceWorkFile()
            if (outWorkSrc.exists()) outWorkSrc.delete()

            val pageBatch = batchValueOrDefault1()

            fun copyRange1BasedPaged(srcPath: String, dest: PdfDocument, from1: Int, to1: Int) {
                var from = from1
                while (from <= to1) {
                    val to = min(from + pageBatch - 1, to1)
                    PdfDocument(rdr(srcPath)).use { src ->
                        src.copyPagesTo(from, to, dest)
                        runCatching { PdfCopySupport.flushCopiedObjects(dest, src) }
                    }
                    val added = to - from + 1
                    for (i in 0 until added) {
                        val p = dest.numberOfPages - i
                        if (p >= 1) runCatching { dest.getPage(p).flush() }
                    }
                    from = to + 1
                }
            }

            PdfDocument(PdfWriter(outWorkSrc.absolutePath, writerProps)).use { destSrcDoc ->
                destSrcDoc.setFlushUnusedObjects(true)

                val totalPages = PdfDocument(rdr(srcFile.absolutePath)).use { it.numberOfPages }
                val per = perGroup()

                var p = 1
                var runStart: Int? = null

                while (p <= totalPages) {
                    if (isSigningCancelled) {
                        return
                    }

                    val groupIndex = (p - 1) / per
                    val replPath = signedMap[groupIndex]

                    if (replPath != null) {
                        runStart?.let { copyRange1BasedPaged(srcFile.absolutePath, destSrcDoc, it, p - 1) }
                        runStart = null

                        PdfDocument(rdr(replPath)).use { repl ->
                            repl.copyPagesTo(1, 1, destSrcDoc)
                            runCatching { PdfCopySupport.flushCopiedObjects(destSrcDoc, repl) }
                        }
                        runCatching { destSrcDoc.lastPage?.flush() }

                        val groupStart = groupIndex * per + 1
                        val groupEnd = min(totalPages, groupStart + per - 1)
                        p = groupEnd + 1
                    } else {
                        if (runStart == null) runStart = p
                        p++
                    }
                }

                runStart?.let { copyRange1BasedPaged(srcFile.absolutePath, destSrcDoc, it, totalPages) }
            }

            if (isSigningCancelled) {
                runCatching { outWorkSrc.delete() }
                return
            }

            if (srcFile.exists()) srcFile.delete()
            outWorkSrc.renameTo(srcFile)

            val per = perGroup()
            val totalPages = sourceTempPageCount()
            if (sourceRotation.size == totalPages) {
                signedMap.keys.forEach { plpIndex ->
                    val start = plpIndex * per
                    val end = min(totalPages - 1, start + per - 1)
                    if (start < totalPages) {
                        for (i in start..end) {
                            sourceRotation[i] = 0
                        }
                    }
                }
            }

        } catch (_: Exception) {

        } finally {
            runCatching {
                signedList.forEach { (_, path) -> runCatching { File(path).delete() } }
            }

            if (!isSigningCancelled) {
                scheduleNupRebuild(onReloadStarted)
            }
        }
    }

    private fun scheduleNupRebuild(onReloadStarted: (() -> Unit)? = null) {
        runCatching {

            if (::binding.isInitialized && (
                        binding.overlayProgressDialog.isVisible ||
                                binding.overlayProgressDialogUpdateUi.isVisible
                        )
            ) {
                lockScreenOrientation()
            }
        }.onFailure {

        }

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                createTempPdfInternal()
            } finally {
                withContext(Dispatchers.Main) {
                    resetThumbDocKey("nup_rebuilt_${System.currentTimeMillis()}")

                    reloadThumbnailsFromPlp(
                        releaseUiAtStart = false,
                        onStarted = {
                            unlockScreenOrientation()
                            onReloadStarted?.invoke()
                        }
                    )

                    updateButtonsState()
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    private class SimpleTextWatcher(private val cb: () -> Unit) : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) { cb() }
    }

    private fun setThemedBackArrow() {
        binding.toolbar.navigationIcon = AppCompatResources.getDrawable(this, R.drawable.ic_arrow_back_24)
    }

    override fun onResume() {
        super.onResume()
        setThemedBackArrow()
        suppressNup = false
        runCatching { snapshotInitialPrefsIfNeeded() }

        runCatching {
            val showing = (
                    binding.overlayProgressDialog.isVisible ||
                            binding.overlayProgressDialogUpdateUi.isVisible
                    )

            if (showing) {
                var indicator = binding.overlayProgressDialogPanel.findViewById<BaseProgressIndicator<*>>(R.id.progress_bar_indicator)

                if (indicator == null) {
                    indicator = binding.overlayProgressDialogUpdateUiPanel.findViewById(R.id.progress_bar_indicator_update_ui)
                }

                indicator?.post {
                    indicator.hide()
                    indicator.show()
                }
            }
        }.onFailure {
        }

        if (Build.VERSION.SDK_INT <= VERSION_CODES.N_MR1 && !didRunNScrollColdStartFix && isFirstCreate) {
            val sv = binding.rootScroll

            sv.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            sv.isFocusable = true
            sv.isFocusableInTouchMode = true

            sv.post {
                sv.scrollTo(0, 0)
                sv.fullScroll(View.FOCUS_UP)

                sv.descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
                sv.requestFocusFromTouch()

                didRunNScrollColdStartFix = true
            }
        }

        if (Build.VERSION.SDK_INT <= VERSION_CODES.N_MR1 && !isFirstCreate) {
            val sv = binding.rootScroll

            sv.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS

            sv.post {
                sv.descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS

                sv.isFocusable = true
                sv.isFocusableInTouchMode = true
                sv.requestFocusFromTouch()
            }
        }

        if (pendingCacheCleanupAfterExternalReturn && didPauseForExternalAction) {
            pendingCacheCleanupAfterExternalReturn = false
            didPauseForExternalAction = false
            lifecycleScope.launch(Dispatchers.IO) {
                cleanupCacheExceptTemps()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)

        MenuCompat.setGroupDividerEnabled(menu, true)

        runCatching {
            val item = menu.findItem(R.id.action_inner_pdf_reader)
            if (item != null) {
                val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                val enabled = synchronized(prefsBackupLock) {
                    prefs.getBoolean(KEY_LAST_INNER_PDF_READER, true)
                }
                item.isCheckable = true
                item.isChecked = enabled
                item.isEnabled = Build.VERSION.SDK_INT >= VERSION_CODES.P
            }
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_theme_light -> { setThemeMode("light"); true }
            R.id.action_theme_dark  -> { setThemeMode("dark");  true }
            R.id.action_theme_system-> { setThemeMode("system");true }

            R.id.action_inner_pdf_reader -> {
                val newChecked = !item.isChecked
                item.isChecked = newChecked
                synchronized(prefsBackupLock) {
                    getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
                        .edit { putBoolean(KEY_LAST_INNER_PDF_READER, newChecked) }
                }
                true
            }

            R.id.action_battery_optimization -> {
                launchBatteryOptimizationSettings()
                true
            }

            R.id.action_save -> {
                launchSaveSharedPreferences()
                true
            }

            R.id.action_load -> {
                launchLoadSharedPreferences()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun launchBatteryOptimizationSettings() {

        val overlay = binding.overlayDialogBatteryOptimization
        val panel = binding.overlayDialogBatteryOptimizationPanel

        panel.removeAllViews()
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_battery_optimization, panel, false)
        panel.addView(dialogView)

        overlay.visibility = View.VISIBLE

        overlay.setOnClickListener {
            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)
        }
        panel.setOnClickListener {
        }

        val btnOk     = dialogView.findViewById<Button>(R.id.bo_btn_ok)
        val btnCancel = dialogView.findViewById<Button>(R.id.bo_btn_cancel)

        btnCancel?.setOnClickListener {

            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)
        }

        btnOk?.setOnClickListener {

            overlay.visibility = View.GONE
            overlay.setOnClickListener(null)

            try {
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                startActivity(intent)
            } catch (_: Exception) {

            }
        }
    }

    private fun launchSaveSharedPreferences() {
        val suggestedName = "PLP_settings.xml"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/xml"
            putExtra(Intent.EXTRA_TITLE, suggestedName)
        }
        savePrefsLauncher.launch(intent)
    }

    private fun launchLoadSharedPreferences() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/xml",
                    "text/xml",
                    "text/plain",
                    "application/octet-stream"
                )
            )
        }
        loadPrefsLauncher.launch(intent)
    }

    private fun exportAllSharedPreferencesXml(): String {
        val serializer = Xml.newSerializer()
        val sw = StringWriter()

        serializer.setOutput(sw)
        serializer.startDocument("UTF-8", true)
        serializer.startTag(null, "preferences")

        fun writeMap(name: String) {
            val all = synchronized(prefsBackupLock) {
                getSharedPreferences(name, MODE_PRIVATE).all
            }
            serializer.startTag(null, "map")
            serializer.attribute(null, "name", name)

            val allowedKeys = setOf(
                KEY_NORMAL_ROWS, KEY_LABEL_ROWS,
                KEY_NORMAL_COLUMNS, KEY_LABEL_COLUMNS,
                KEY_NORMAL_BATCH_PAGE, KEY_LABEL_BATCH_PAGE,
                KEY_NORMAL_SCALE, KEY_LABEL_SCALE,
                KEY_NORMAL_FIT, KEY_LABEL_FIT,
                KEY_NORMAL_MARGIN, KEY_LABEL_MARGIN,
                KEY_NORMAL_ORIENTATION, KEY_LABEL_ORIENTATION,
                KEY_NORMAL_DRAW_FRAME, KEY_LABEL_DRAW_FRAME,
                KEY_NORMAL_SIG_POS_X, KEY_LABEL_SIG_POS_X,
                KEY_NORMAL_SIG_POS_Y, KEY_LABEL_SIG_POS_Y,
                KEY_NORMAL_PASSWORD_OUT, KEY_LABEL_PASSWORD_OUT,
                KEY_NORMAL_FILE_NAME_TEMPLATE, KEY_LABEL_FILE_NAME_TEMPLATE,
                KEY_LAST_SIG_DPI_INDEX, KEY_LAST_SCAN_EFFECT, KEY_LAST_GRAYSCALE,
                KEY_LAST_INNER_PDF_READER, KEY_LAST_LOADED_PROFILE,
                KEY_RESTORE_LOCK_UNTIL_RELOAD, KEY_FIRST_RUN_INITIALIZED
            )

            for ((key, value) in all) {
                if (!allowedKeys.contains(key)) continue

                serializer.startTag(null, "entry")
                serializer.attribute(null, "key", key)
                when (value) {
                    is String -> { serializer.attribute(null, "type", "string"); serializer.text(value) }
                    is Int -> { serializer.attribute(null, "type", "int"); serializer.text(value.toString()) }
                    is Long -> { serializer.attribute(null, "type", "long"); serializer.text(value.toString()) }
                    is Float -> { serializer.attribute(null, "type", "float"); serializer.text(value.toString()) }
                    is Boolean -> { serializer.attribute(null, "type", "boolean"); serializer.text(value.toString()) }
                    is Set<*> -> {
                        val items = value.filterIsInstance<String>()
                        serializer.attribute(null, "type", "string_set")
                        serializer.text(items.joinToString("\u0001"))
                    }
                    else -> {

                    }
                }
                serializer.endTag(null, "entry")
            }
            serializer.endTag(null, "map")
        }

        writeMap(PREFS_NAME_FRAGMENT)

        serializer.endTag(null, "preferences")
        serializer.endDocument()

        return sw.toString()
    }

    private fun importAllSharedPreferencesFromXml(xml: String) {
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xml))

        val spFragment = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)

        var editor: SharedPreferences.Editor? = null
        var inTargetMap = false

        var currentKey: String? = null
        var currentType: String? = null
        val textBuf = StringBuilder()

        var foundTargetMap = false

        val allowedKeys = setOf(
            KEY_NORMAL_ROWS, KEY_LABEL_ROWS,
            KEY_NORMAL_COLUMNS, KEY_LABEL_COLUMNS,
            KEY_NORMAL_BATCH_PAGE, KEY_LABEL_BATCH_PAGE,
            KEY_NORMAL_SCALE, KEY_LABEL_SCALE,
            KEY_NORMAL_FIT, KEY_LABEL_FIT,
            KEY_NORMAL_MARGIN, KEY_LABEL_MARGIN,
            KEY_NORMAL_ORIENTATION, KEY_LABEL_ORIENTATION,
            KEY_NORMAL_DRAW_FRAME, KEY_LABEL_DRAW_FRAME,
            KEY_NORMAL_SIG_POS_X, KEY_LABEL_SIG_POS_X,
            KEY_NORMAL_SIG_POS_Y, KEY_LABEL_SIG_POS_Y,
            KEY_NORMAL_PASSWORD_OUT, KEY_LABEL_PASSWORD_OUT,
            KEY_NORMAL_FILE_NAME_TEMPLATE, KEY_LABEL_FILE_NAME_TEMPLATE,
            KEY_LAST_SIG_DPI_INDEX, KEY_LAST_SCAN_EFFECT, KEY_LAST_GRAYSCALE,
            KEY_LAST_INNER_PDF_READER, KEY_LAST_LOADED_PROFILE,
            KEY_RESTORE_LOCK_UNTIL_RELOAD, KEY_FIRST_RUN_INITIALIZED
        )

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "map" -> {
                            val nameAttr = (0 until parser.attributeCount)
                                .firstOrNull { parser.getAttributeName(it) == "name" }
                                ?.let { parser.getAttributeValue(it) }
                            inTargetMap = (nameAttr == PREFS_NAME_FRAGMENT)
                            if (inTargetMap) {
                                foundTargetMap = true
                                synchronized(prefsBackupLock) {
                                    editor = spFragment.edit()
                                }
                            }
                        }
                        "entry" -> {
                            if (inTargetMap) {
                                currentKey = (0 until parser.attributeCount)
                                    .firstOrNull { parser.getAttributeName(it) == "key" }
                                    ?.let { parser.getAttributeValue(it) }
                                currentType = (0 until parser.attributeCount)
                                    .firstOrNull { parser.getAttributeName(it) == "type" }
                                    ?.let { parser.getAttributeValue(it) }
                                textBuf.setLength(0)
                            }
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inTargetMap) {
                        textBuf.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "entry" -> {
                            if (inTargetMap) {
                                val key = currentKey
                                val type = currentType
                                val valueText = textBuf.toString()

                                if (key != null && type != null && editor != null) {
                                    if (allowedKeys.contains(key)) {
                                        when (type) {
                                            "string"     -> editor.putString(key, valueText)
                                            "int"        -> editor.putInt(key, valueText.toIntOrNull() ?: 0)
                                            "long"       -> editor.putLong(key, valueText.toLongOrNull() ?: 0L)
                                            "float"      -> editor.putFloat(key, valueText.toFloatOrNull() ?: 0f)
                                            "boolean"    -> editor.putBoolean(key, valueText.equals("true", ignoreCase = true))
                                            "string_set" -> {
                                                val set = if (valueText.isEmpty()) emptySet() else valueText.split('\u0001').toSet()
                                                editor.putStringSet(key, set)
                                            }
                                        }
                                    }
                                }
                                currentKey = null
                                currentType = null
                                textBuf.setLength(0)
                            }
                        }
                        "map" -> {
                            if (inTargetMap) {
                                inTargetMap = false
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }

        if (foundTargetMap) {
            synchronized(prefsBackupLock) {
                editor?.apply()
            }
        } else {
            throw IllegalArgumentException(getString(R.string.error_invalid_prefs_file, PREFS_NAME_FRAGMENT))
        }
    }

    fun setThemeMode(mode: String) {
        val prefs = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
        synchronized(prefsBackupLock) {
            prefs.edit { putString(KEY_THEME_MODE, mode) }
        }

        val nightMode = when (mode) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }

        runCatching {
            val lm = binding.rvThumbnails.layoutManager as? LinearLayoutManager
            val first = lm?.findFirstVisibleItemPosition() ?: RecyclerView.NO_POSITION
            val offset = if (first != RecyclerView.NO_POSITION) {
                lm?.findViewByPosition(first)?.top ?: 0
            } else 0
            val selectedIdx = viewModel.pageItems
                .mapIndexedNotNull { idx, it -> if (it.isSelected) idx else null }

            val nsv = findViewById<NestedScrollView>(R.id.root_scroll)
            val nsvY = nsv?.scrollY ?: -1

            val csv = selectedIdx.joinToString(",")
            val rotationCsv = sourceRotation.joinToString(",")

            val sp = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            synchronized(prefsBackupLock) {
                sp.edit {
                    putInt(KEY_THEME_RESTORE_FIRST, first)
                    putInt(KEY_THEME_RESTORE_OFFSET, offset)
                    putString(KEY_THEME_RESTORE_SELECTED_CSV, csv)
                    putString(KEY_THEME_RESTORE_ROTATION_CSV, rotationCsv)
                    putInt(KEY_THEME_RESTORE_NSV_Y, nsvY)
                }
            }
        }

        runCatching {
            val sp2 = getSharedPreferences(PREFS_NAME_FRAGMENT, MODE_PRIVATE)
            synchronized(prefsBackupLock) {
                sp2.edit { putBoolean(KEY_RESTORE_LOCK_UNTIL_RELOAD, true) }
            }
        }.onFailure {

        }

        if (Build.VERSION.SDK_INT >= VERSION_CODES.S) {
            val uiModeManager = getSystemService(UI_MODE_SERVICE) as UiModeManager
            val appNightMode = when (mode) {
                "light" -> UiModeManager.MODE_NIGHT_NO
                "dark" -> UiModeManager.MODE_NIGHT_YES
                else -> UiModeManager.MODE_NIGHT_AUTO
            }
            uiModeManager.setApplicationNightMode(appNightMode)

            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        } else {
            AppCompatDelegate.setDefaultNightMode(nightMode)
        }
    }
}

@Suppress("DEPRECATION")
fun Intent.getParcelableCompat(name: String): Uri? =
    if (Build.VERSION.SDK_INT >= VERSION_CODES.TIRAMISU) getParcelableExtra(name, Uri::class.java)
    else getParcelableExtra(name)

@Suppress("DEPRECATION")
fun Intent.getParcelableArrayListCompat(name: String): ArrayList<Uri>? =
    if (Build.VERSION.SDK_INT >= VERSION_CODES.TIRAMISU) getParcelableArrayListExtra(name, Uri::class.java)
    else getParcelableArrayListExtra(name)