package hu.reelee81.pdflabelprinting

import com.itextpdf.kernel.geom.Rectangle
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.kernel.pdf.PdfArray
import com.itextpdf.kernel.pdf.PdfDictionary
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfName
import com.itextpdf.kernel.pdf.PdfNumber
import com.itextpdf.kernel.pdf.PdfPage
import com.itextpdf.kernel.pdf.PdfResources
import com.itextpdf.kernel.pdf.PdfStream
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.canvas.PdfCanvas
import com.itextpdf.kernel.pdf.canvas.parser.EventType
import com.itextpdf.kernel.pdf.canvas.parser.data.IEventData
import com.itextpdf.kernel.pdf.canvas.parser.data.PathRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.data.TextRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.listener.IEventListener
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PdfFitGeometryTest {
    @Test
    fun trueTypeGlyphBoundsAndCmapAreReadWithoutBuildingGlyphObjects() {
        val metrics = PdfTrueTypeBounds(fontBytes())
        assertEquals(1000, metrics.unitsPerEm)
        assertEquals(1, metrics.glyphForUnicode(65))
        assertArrayEquals(intArrayOf(-10, -50, 720, 800), metrics.glyphBox(1))
    }

    @Test
    fun symbolicByteCodesSelectGlyphsWithoutTreatingThemAsUnicode() {
        val metrics = PdfTrueTypeBounds(fontBytes(symbolicCode = 1))
        assertEquals(1, metrics.glyphForSymbolicByte(1))
        assertNull(metrics.glyphForUnicode(65))
        assertNull(metrics.glyphForSymbolicByte(65))
        assertNull(metrics.glyphForSymbolicByte(-1))
        assertNull(metrics.glyphForSymbolicByte(256))
        assertArrayEquals(intArrayOf(-10, -50, 720, 800), metrics.glyphBox(1))
    }

    @Test
    fun unicodeFontsAreNotReadAsDirectByteMappings() {
        val metrics = PdfTrueTypeBounds(fontBytes())
        assertNull(metrics.glyphForSymbolicByte(65))
        assertEquals(1, metrics.glyphForUnicode(65))
    }

    @Test
    fun theHighestByteCodeIsReadAsUnsigned() {
        val metrics = PdfTrueTypeBounds(fontBytes(symbolicCode = 255))
        assertEquals(1, metrics.glyphForSymbolicByte(255))
    }

    @Test
    fun anOutOfTableByteMappingOffsetIsNotUsed() {
        val bytes = fontBytes(symbolicCode = 1)
        val buffer = ByteBuffer.wrap(bytes)
        val cmap = buffer.getInt(12 + 4 * 16 + 8)
        buffer.putInt(cmap + 8, Int.MAX_VALUE)
        assertNull(PdfTrueTypeBounds(bytes).glyphForSymbolicByte(1))
    }

    @Test
    fun truncatedByteMappingIsNotUsed() {
        val bytes = fontBytes(symbolicCode = 1)
        val buffer = ByteBuffer.wrap(bytes)
        val record = 12 + 4 * 16
        buffer.putInt(record + 12, 273)
        assertNull(PdfTrueTypeBounds(bytes).glyphForSymbolicByte(1))
    }

    @Test
    fun multipleMappingRecordsRetainTheExistingFallback() {
        val bytes = fontBytes(symbolicCode = 1)
        val buffer = ByteBuffer.wrap(bytes)
        val cmap = buffer.getInt(12 + 4 * 16 + 8)
        buffer.putShort(cmap + 2, 2)
        assertNull(PdfTrueTypeBounds(bytes).glyphForSymbolicByte(1))
    }

    @Test
    fun aSymbolicSubsetUsesIndividualInkBoundsInsteadOfTheWholeFontBox() {
        val bounds = byteMappedTextBounds(byteMappedFontDictionary())
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(172f, bounds.right, 0.001f)
        assertEquals(95f, bounds.bottom, 0.001f)
        assertTrue(bounds.top in 180f..<200f)
    }

    @Test
    fun anUnencodedSubsetAlsoUsesDirectByteCodes() {
        val dictionary = byteMappedFontDictionary()
        dictionary.getAsDictionary(PdfName.FontDescriptor).put(PdfName.Flags, PdfNumber(32))
        val bounds = byteMappedTextBounds(dictionary)
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(172f, bounds.right, 0.001f)
    }

    @Test
    fun theSymbolicFlagTakesPrecedenceOverTheEncodingEntry() {
        val dictionary = byteMappedFontDictionary()
        dictionary.put(PdfName.Encoding, PdfName.WinAnsiEncoding)
        val bounds = byteMappedTextBounds(dictionary)
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(172f, bounds.right, 0.001f)
    }

    @Test
    fun anExplicitNonSymbolicEncodingRetainsTheConservativeBounds() {
        val dictionary = byteMappedFontDictionary(65)
        dictionary.put(PdfName.Encoding, PdfName.WinAnsiEncoding)
        dictionary.getAsDictionary(PdfName.FontDescriptor).put(PdfName.Flags, PdfNumber(32))
        val bounds = byteMappedTextBounds(dictionary, 65)
        assertEquals(0f, bounds.left, 0.001f)
        assertEquals(300f, bounds.right, 0.001f)
    }

    @Test
    fun anUnmappedByteDoesNotLoseTheConservativeFontBox() {
        val bounds = byteMappedTextBounds(byteMappedFontDictionary(), 2)
        assertEquals(0f, bounds.left, 0.001f)
        assertEquals(300f, bounds.right, 0.001f)
    }

    @Test
    fun embeddedType1RetainsTextGeometryWithoutReadingItsOutlines() {
        assertMetricTextBounds(metricFontDictionary(PdfName.Type1, PdfName.FontFile, byteArrayOf(1)))
    }

    @Test
    fun embeddedCompactFontRetainsTextGeometryWithoutReadingItsOutlines() {
        assertMetricTextBounds(metricFontDictionary(PdfName.Type1, PdfName.FontFile3, byteArrayOf(1)))
    }

    @Test
    fun fontMetadataIncludesOverhangBeyondTheTextMetrics() {
        val dictionary = metricFontDictionary(PdfName.Type1, PdfName.FontFile, byteArrayOf(1))
        dictionary.getAsDictionary(PdfName.FontDescriptor)
            .put(PdfName.FontBBox, PdfArray(intArrayOf(-100, -300, 800, 900)))
        val bounds = byteMappedTextBounds(dictionary, 65)
        assertEquals(90f, bounds.left, 0.001f)
        assertEquals(70f, bounds.bottom, 0.001f)
        assertEquals(180f, bounds.right, 0.001f)
        assertEquals(190f, bounds.top, 0.001f)
    }

    @Test
    fun theNormalEmbeddedFontMatrixKeepsTheMetricBounds() {
        assertMetricTextBounds(metricFontDictionary(PdfName.Type1, PdfName.FontFile,
            "/FontMatrix [0.001 0 0 0.001 0 0] readonly def".toByteArray(Charsets.US_ASCII)))
    }

    @Test
    fun aSkewedAndReflectedEmbeddedFontMatrixIncludesAllCorners() {
        val dictionary = metricFontDictionary(PdfName.Type1, PdfName.FontFile,
            "/FontMatrix [0.001 0.002 0.003 -0.004 0 0] readonly def".toByteArray(Charsets.US_ASCII))
        val bounds = byteMappedTextBounds(dictionary, 65)
        assertEquals(40f, bounds.left, 0.001f)
        assertEquals(-220f, bounds.bottom, 0.001f)
        assertEquals(390f, bounds.right, 0.001f)
        assertEquals(280f, bounds.top, 0.001f)
    }

    @Test
    fun fontMatrixTranslationIsNotLost() {
        val dictionary = metricFontDictionary(PdfName.Type1, PdfName.FontFile,
            "/FontMatrix [0.001 0 0 0.001 -0.1 0.2] def".toByteArray(Charsets.US_ASCII))
        val bounds = byteMappedTextBounds(dictionary, 65)
        assertEquals(90f, bounds.left, 0.001f)
        assertEquals(80f, bounds.bottom, 0.001f)
        assertEquals(150f, bounds.right, 0.001f)
        assertEquals(200f, bounds.top, 0.001f)
    }

    @Test
    fun anEncryptedHeaderIsNeverSearchedForAnotherFontMatrix() {
        assertMetricTextBounds(metricFontDictionary(PdfName.Type1, PdfName.FontFile,
            "currentfile eexec /FontMatrix [100 0 0 100 0 0] def".toByteArray(Charsets.US_ASCII)))
    }

    @Test
    fun aNonLiteralFontMatrixIsNotExecuted() {
        assertMetricTextBounds(metricFontDictionary(PdfName.Type1, PdfName.FontFile,
            "/FontMatrix { 100 0 0 100 0 0 } def".toByteArray(Charsets.US_ASCII)))
    }

    @Test
    fun extremeFontMatrixValuesStillStopUnsafeAnalysis() {
        val dictionary = metricFontDictionary(PdfName.Type1, PdfName.FontFile,
            "/FontMatrix [999999999999999999999999999999999999 0 0 1 0 0] def".toByteArray(Charsets.US_ASCII))
        val result = runCatching { byteMappedTextBounds(dictionary, 65) }
        assertTrue(result.isFailure)
        assertEquals("PDF fit analysis limit reached", result.exceptionOrNull()?.message)
    }

    @Test
    fun cidInkBoundsUseThePdfCodeEvenWithoutAUnicodeMapping() {
        val bounds = byteMappedTextBounds(cidFontDictionary())
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(80f, bounds.bottom, 0.001f)
        assertEquals(172f, bounds.right, 0.001f)
        assertEquals(180f, bounds.top, 0.001f)
    }

    @Test
    fun cidInkBoundsFollowTheExplicitGlyphMapping() {
        val dictionary = cidFontDictionary(byteArrayOf(0, 0, 0, 0, 0, 1))
        val bounds = byteMappedTextBounds(dictionary, 2)
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(172f, bounds.right, 0.001f)
    }

    @Test
    fun aShortCidGlyphMappingRetainsTheMetadataBounds() {
        val bounds = byteMappedTextBounds(cidFontDictionary(byteArrayOf(0, 0)))
        assertEquals(0f, bounds.left, 0.001f)
        assertEquals(300f, bounds.right, 0.001f)
    }

    @Test
    fun missingUnicodeUsesDeclaredCidWidthsBetweenTextOperations() {
        val dictionary = cidFontDictionary()
        dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
            .put(PdfName.W, PdfArray().apply { add(PdfNumber(1)); add(PdfArray(intArrayOf(900))) })
        val bounds = byteMappedTextBounds(dictionary, content =
            "BT /F1 100 Tf 1 0 0 1 100 100 Tm <0001> Tj <0001> Tj ET")
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(262f, bounds.right, 0.001f)
    }

    @Test
    fun missingUnicodeUsesDeclaredCidWidthsWithinOneTextOperation() {
        val dictionary = cidFontDictionary()
        dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
            .put(PdfName.W, PdfArray().apply { add(PdfNumber(1)); add(PdfNumber(2)); add(PdfNumber(900)) })
        val bounds = byteMappedTextBounds(dictionary, content =
            "BT /F1 100 Tf 1 0 0 1 100 100 Tm <00010001> Tj ET")
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(262f, bounds.right, 0.001f)
    }

    @Test
    fun explicitTextArrayAdjustmentsArePreservedWithMissingUnicode() {
        val dictionary = cidFontDictionary()
        dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
            .put(PdfName.W, PdfArray().apply { add(PdfNumber(1)); add(PdfArray(intArrayOf(900))) })
        val bounds = byteMappedTextBounds(dictionary, content =
            "BT /F1 100 Tf 1 0 0 1 100 100 Tm [<0001> 100 <0001>] TJ ET")
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(252f, bounds.right, 0.001f)
    }

    @Test
    fun lineAndSpacingOperatorsKeepTheirExistingSemantics() {
        val dictionary = cidFontDictionary()
        dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
            .put(PdfName.W, PdfArray().apply { add(PdfNumber(1)); add(PdfArray(intArrayOf(900))) })
        val bounds = byteMappedTextBounds(dictionary, content =
            "BT /F1 100 Tf 200 TL 1 0 0 1 100 100 Tm <0001> Tj <0001> ' 0 10 <0001> \" <0001> Tj ET")
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(272f, bounds.right, 0.001f)
        assertEquals(-320f, bounds.bottom, 0.001f)
        assertEquals(180f, bounds.top, 0.001f)
    }

    @Test
    fun aNonDirectEncodingUsesCidsRatherThanUnicodeOrRawCodesForGlyphsAndWidths() {
        val dictionary = cidFontDictionary()
        dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
            .put(PdfName.W, PdfArray().apply { add(PdfNumber(1)); add(PdfArray(intArrayOf(900))) })
        dictionary.put(PdfName.Encoding, PdfStream("""
            /CIDInit /ProcSet findresource begin
            12 dict begin begincmap
            /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> def
            /CMapName /SyntheticEncoding def /CMapType 1 def
            1 begincodespacerange <0000> <ffff> endcodespacerange
            1 begincidchar <0002> 1 endcidchar
            endcmap CMapName currentdict /CMap defineresource pop end end
        """.trimIndent().toByteArray(Charsets.US_ASCII)).apply {
            put(PdfName.CMapName, PdfName("SyntheticEncoding"))
        })
        val bounds = byteMappedTextBounds(dictionary, content =
            "BT /F1 100 Tf 1 0 0 1 100 100 Tm <0002> Tj <0002> Tj ET")
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(262f, bounds.right, 0.001f)
    }

    @Test
    fun malformedTrueTypeRetainsTextGeometry() {
        assertMetricTextBounds(metricFontDictionary(PdfName.TrueType, PdfName.FontFile2, byteArrayOf(1)))
    }

    @Test
    fun oversizedTrueTypeRetainsTextGeometryWithoutLiftingTheFontLimit() {
        assertMetricTextBounds(metricFontDictionary(PdfName.TrueType, PdfName.FontFile2, ByteArray(512 * 1024 + 1)))
    }

    @Test
    fun rotatedTextGeometryKeepsAllFourCorners() {
        assertMetricTextBounds(metricFontDictionary(PdfName.Type1, PdfName.FontFile, byteArrayOf(1)),
            "0 1 -1 0 100 100")
    }

    @Test
    fun reflectedTextGeometryDoesNotLoseNegativeDirections() {
        assertMetricTextBounds(metricFontDictionary(PdfName.Type1, PdfName.FontFile, byteArrayOf(1)),
            "-1 0 0 -1 100 100")
    }

    @Test
    fun textRiseKeepsItsSignAndIsTransformedOnlyOnce() {
        for (rise in listOf(10, -10)) {
            val dictionary = metricFontDictionary(PdfName.Type1, PdfName.FontFile, byteArrayOf(1))
            val bounds = byteMappedTextBounds(dictionary, 65, content =
                "q 0 2 -3 0 900 100 cm BT /F1 100 Tf $rise Ts 1 0 0 1 100 100 Tm (A) Tj ET Q")
            assertEquals(360f - 3 * rise, bounds.left, 0.001f)
            assertEquals(660f - 3 * rise, bounds.right, 0.001f)
            assertEquals(300f, bounds.bottom, 0.001f)
            assertEquals(400f, bounds.top, 0.001f)
        }
    }

    @Test
    fun aKnownSymbolicGlyphDoesNotRequireAUnicodeMapping() {
        val dictionary = byteMappedFontDictionary()
        dictionary.remove(PdfName.ToUnicode)
        val bounds = byteMappedTextBounds(dictionary)
        assertEquals(99f, bounds.left, 0.001f)
        assertEquals(172f, bounds.right, 0.001f)
    }

    @Test
    fun fontCacheLimitDoesNotDiscardTheFifthFontsTextGeometry() {
        val geometry = PdfFitGeometry()
        repeat(5) { index ->
            val dictionary = metricFontDictionary(PdfName.TrueType, PdfName.FontFile2, fontBytes())
            if (index < 4) {
                byteMappedTextBounds(dictionary, 65, geometry)
            } else {
                assertMetricTextBounds(dictionary, geometry = geometry)
            }
        }
    }

    @Test
    fun type3RetainsTextGeometryInsteadOfDiscardingThePageMeasurement() {
        val dictionary = metricFontDictionary(PdfName.Type3)
        dictionary.put(PdfName.FontBBox, PdfArray(intArrayOf(0, -200, 500, 800)))
        dictionary.put(PdfName.FontMatrix, PdfArray(floatArrayOf(0.001f, 0f, 0f, 0.001f, 0f, 0f)))
        dictionary.put(PdfName.CharProcs, PdfDictionary().apply {
            put(PdfName("A"), PdfStream("500 0 0 -200 500 800 d1 0 0 500 700 re f".toByteArray(Charsets.US_ASCII)))
        })
        dictionary.put(PdfName.Resources, PdfDictionary())
        assertMetricTextBounds(dictionary)
    }

    @Test
    fun missingOutlineDataDoesNotStopAnalysisOfFollowingPageObjects() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            page.resources.pdfObject.put(PdfName.Font, PdfDictionary().apply {
                put(PdfName("F1"), metricFontDictionary(PdfName.Type1, PdfName.FontFile, byteArrayOf(1)))
            })
            page.newContentStreamAfter().setData(
                "BT /F1 100 Tf 1 0 0 1 100 100 Tm (A) Tj ET 300 300 10 10 re f".toByteArray(Charsets.US_ASCII)
            )
            var box: Rectangle? = null
            var texts = 0
            var paths = 0
            val geometry = PdfFitGeometry()
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    val include: (Rectangle) -> Unit = { box = Rectangle.getCommonRectangle(box, it) }
                    when (data) {
                        is TextRenderInfo -> {
                            texts++
                            geometry.includeText(data, include)
                        }
                        is PathRenderInfo -> {
                            paths++
                            PdfFitGeometry.includePath(data, include)
                        }
                    }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_TEXT, EventType.RENDER_PATH)
            }
            PdfFitGeometry.Processor(listener).processPageContent(page)
            assertEquals(1, texts)
            assertEquals(1, paths)
            assertEquals(100f, requireNotNull(box).left, 0.001f)
            assertEquals(310f, requireNotNull(box).right, 0.001f)
            assertEquals(310f, requireNotNull(box).top, 0.001f)
        }
    }

    @Test(expected = IllegalArgumentException::class)
    fun outOfFileFontTableIsRejected() {
        val bytes = fontBytes()
        ByteBuffer.wrap(bytes).putInt(20, Int.MAX_VALUE)
        PdfTrueTypeBounds(bytes)
    }

    @Test
    fun strokeBoundsContainLineThickness() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).setLineWidth(10f).setLineJoinStyle(1).moveTo(100.0, 100.0).lineTo(200.0, 100.0).stroke()
            var box: Rectangle? = null
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is PathRenderInfo) PdfFitGeometry.includePath(data) { box = it }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH)
            }
            PdfFitGeometry.Processor(listener).processPageContent(page)
            assertEquals(95f, requireNotNull(box).bottom, 0.001f)
            assertEquals(105f, requireNotNull(box).top, 0.001f)
        }
    }

    @Test
    fun rectangularStrokeDoesNotUseTheMaximumCornerLengthAsPadding() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).setLineWidth(1f).rectangle(5.0, 5.0, 270.0, 384.0).stroke()
            val bounds = firstStrokeBounds(page)
            assertEquals(4.5f, bounds.left, 0.001f)
            assertEquals(4.5f, bounds.bottom, 0.001f)
            assertEquals(271f, bounds.width, 0.001f)
            assertEquals(385f, bounds.height, 0.001f)
        }
    }

    @Test
    fun pointOnlyCurvesAtRectangularCornersDoNotInflateTheBorder() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).setLineWidth(1f).setLineCapStyle(2)
                .moveTo(5.0, 5.0).lineTo(275.0, 5.0).curveTo(275.0, 5.0, 275.0, 5.0, 275.0, 5.0)
                .lineTo(275.0, 389.0).curveTo(275.0, 389.0, 275.0, 389.0, 275.0, 389.0)
                .lineTo(5.0, 389.0).curveTo(5.0, 389.0, 5.0, 389.0, 5.0, 389.0)
                .lineTo(5.0, 5.0).curveTo(5.0, 5.0, 5.0, 5.0, 5.0, 5.0).stroke()
            val bounds = firstStrokeBounds(page)
            assertEquals(4.5f, bounds.left, 0.001f)
            assertEquals(4.5f, bounds.bottom, 0.001f)
            assertEquals(271f, bounds.width, 0.001f)
            assertEquals(385f, bounds.height, 0.001f)
        }
    }

    @Test
    fun rotatedAndScaledRectangleStillIncludesTheWholeStroke() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).concatMatrix(0.0, 2.0, -3.0, 0.0, 900.0, 100.0)
                .setLineWidth(1f).rectangle(5.0, 5.0, 270.0, 384.0).stroke()
            val bounds = firstStrokeBounds(page)
            assertEquals(-268.5f, bounds.left, 0.001f)
            assertEquals(109f, bounds.bottom, 0.001f)
            assertEquals(1155f, bounds.width, 0.001f)
            assertEquals(542f, bounds.height, 0.001f)
        }
    }

    @Test
    fun sharpCornersRetainTheConservativeStrokePadding() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).setLineWidth(10f).setLineJoinStyle(0).setMiterLimit(10f)
                .moveTo(100.0, 100.0).lineTo(200.0, 100.0).lineTo(101.0, 101.0).stroke()
            val bounds = firstStrokeBounds(page)
            assertEquals(50f, bounds.left, 0.001f)
            assertEquals(50f, bounds.bottom, 0.001f)
            assertEquals(250f, bounds.right, 0.001f)
            assertEquals(151f, bounds.top, 0.001f)
        }
    }

    @Test
    fun diagonalClosingEdgeUsesItsActualOuterCorners() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).setLineWidth(10f).setLineJoinStyle(0).setMiterLimit(10f)
                .moveTo(100.0, 100.0).lineTo(200.0, 100.0).lineTo(200.0, 200.0).closePath().stroke()
            val bounds = firstStrokeBounds(page)
            assertEquals(87.92893f, bounds.left, 0.001f)
            assertEquals(95f, bounds.bottom, 0.001f)
            assertEquals(205f, bounds.right, 0.001f)
            assertEquals(212.07107f, bounds.top, 0.001f)
        }
    }

    @Test
    fun emptyTextDoesNotAddAnInvisiblePointToTheContentBounds() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            val font = PdfFontFactory.createFont(PdfDictionary().apply {
                put(PdfName.Type, PdfName.Font)
                put(PdfName.Subtype, PdfName.Type1)
                put(PdfName.BaseFont, PdfName("Helvetica"))
                put(PdfName.Encoding, PdfName.WinAnsiEncoding)
            })
            PdfCanvas(page).beginText().setFontAndSize(font, 12f)
                .moveText(0.0, 1000.0).showText("").endText()
            var events = 0
            var rectangles = 0
            val geometry = PdfFitGeometry()
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is TextRenderInfo) {
                        events++
                        geometry.includeText(data) { rectangles++ }
                    }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_TEXT)
            }
            PdfFitGeometry.Processor(listener).processPageContent(page)
            assertEquals(1, events)
            assertEquals(0, rectangles)
        }
    }

    @Test
    fun curvedClippingStopsFitAnalysisBeforeRecursiveSubdivision() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            PdfCanvas(page).moveTo(0.0, 0.0).curveTo(1e12, 1e12, -1e12, 1e12, 100.0, 0.0).clip().endPath()
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) = Unit
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH)
            }
            val start = System.nanoTime()
            val result = runCatching { PdfFitGeometry.Processor(listener).processPageContent(page) }
            assertTrue(result.isFailure)
            assertTrue(System.nanoTime() - start < 1_000_000_000L)
        }
    }

    @Test
    fun validContentAboveFourMegabytesIsStillAnalyzed() {
        var paths = 0
        val listener = object : IEventListener {
            override fun eventOccurred(data: IEventData?, type: EventType?) {
                if (data is PathRenderInfo) paths++
            }
            override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH)
        }
        val content = ByteArray(5 * 1024 * 1024) { ' '.code.toByte() }
        "0 0 m 100 100 l S\n".toByteArray(Charsets.US_ASCII).copyInto(content)
        PdfFitGeometry.Processor(listener).processContent(content, PdfResources())
        assertEquals(1, paths)
    }

    @Test
    fun contentAboveEightMegabytesStillStopsAnalysis() {
        val listener = object : IEventListener {
            override fun eventOccurred(data: IEventData?, type: EventType?) = Unit
            override fun getSupportedEvents(): Set<EventType> = emptySet()
        }
        val result = runCatching {
            PdfFitGeometry.Processor(listener).processContent(ByteArray(8 * 1024 * 1024 + 1), PdfResources())
        }
        assertTrue(result.isFailure)
        assertEquals("PDF fit analysis limit reached", result.exceptionOrNull()?.message)
    }

    @Test
    fun aSpaceCodeCanContainVisibleEmbeddedGlyphOutlines() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val descriptor = PdfDictionary().apply {
                put(PdfName.FontName, PdfName("Synthetic"))
                put(PdfName.Ascent, PdfNumber(200))
                put(PdfName.Descent, PdfNumber(-10))
                put(PdfName.FontBBox, PdfArray(intArrayOf(-10, -50, 720, 800)))
                put(PdfName.FontFile2, PdfStream(fontBytes(32)))
            }
            val dictionary = PdfDictionary().apply {
                put(PdfName.Type, PdfName.Font)
                put(PdfName.Subtype, PdfName.TrueType)
                put(PdfName.BaseFont, PdfName("Synthetic"))
                put(PdfName.Encoding, PdfName.WinAnsiEncoding)
                put(PdfName.FirstChar, PdfNumber(32))
                put(PdfName.LastChar, PdfNumber(32))
                put(PdfName.Widths, PdfArray(intArrayOf(500)))
                put(PdfName.FontDescriptor, descriptor)
            }
            val font = PdfFontFactory.createFont(dictionary)
            val page = pdf.addNewPage()
            PdfCanvas(page).beginText().setFontAndSize(font, 100f).showText(" ").endText()
            var left = 0f
            var right = 0f
            val geometry = PdfFitGeometry()
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is TextRenderInfo) geometry.includeText(data) {
                        left = minOf(left, it.left)
                        right = maxOf(right, it.right)
                    }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_TEXT)
            }
            PdfFitGeometry.Processor(listener).processPageContent(page)
            assertEquals(-1f, left, 0.001f)
            assertEquals(72f, right, 0.001f)
        }
    }

    @Test
    fun aVerifiedEmptySpaceRunDoesNotEnlargeVisibleTextBounds() {
        val bytes = fontBytes(32)
        val data = ByteBuffer.wrap(bytes)
        val offsets = data.getInt(12 + 2 * 16 + 8)
        data.putShort(offsets + 4, 0)
        val visible = "BT /F1 100 Tf 1 0 0 1 100 100 Tm (A) Tj ET"
        val expected = byteMappedTextBounds(spaceFontDictionary(bytes), content = visible)
        val actual = byteMappedTextBounds(spaceFontDictionary(bytes), content =
            "$visible BT /F1 100 Tf 1 0 0 1 500 500 Tm (   ) Tj ET")
        assertEquals(expected.toString(), actual.toString())
        assertEquals(expected.left, actual.left, .001f)
        assertEquals(expected.bottom, actual.bottom, .001f)
    }

    @Test
    fun aZeroGlyphBoxAloneDoesNotProveThatSpaceDataIsEmpty() {
        val bytes = fontBytes(32)
        val data = ByteBuffer.wrap(bytes)
        val glyphs = data.getInt(12 + 3 * 16 + 8)
        for (index in 0..3) data.putShort(glyphs + 2 + index * 2, 0)
        assertTrue(!PdfTrueTypeBounds(bytes).glyphIsEmpty(1))
        val actual = byteMappedTextBounds(spaceFontDictionary(bytes), content =
            "BT /F1 100 Tf 1 0 0 1 500 500 Tm ( ) Tj ET")
        assertEquals(500f, actual.left, .001f)
        assertEquals(550f, actual.right, .001f)
    }

    @Test
    fun invisibleTextDoesNotEnlargeTheVisibleContentBounds() {
        val visible = "BT /F1 100 Tf 1 0 0 1 100 100 Tm <01> Tj ET"
        val expected = byteMappedTextBounds(byteMappedFontDictionary(), content = visible)
        for (mode in listOf(3, 7)) {
            val actual = byteMappedTextBounds(byteMappedFontDictionary(), content =
                "$visible BT /F1 100 Tf $mode Tr 1 0 0 1 500 500 Tm <01> Tj ET")
            assertEquals(expected.toString(), actual.toString())
            assertEquals(expected.left, actual.left, .001f)
            assertEquals(expected.bottom, actual.bottom, .001f)
        }
    }

    @Test
    fun visibleTextRenderingModesKeepTheirPreviousBounds() {
        val expected = byteMappedTextBounds(byteMappedFontDictionary())
        for (mode in listOf(0, 1, 2, 4, 5, 6)) {
            val actual = byteMappedTextBounds(byteMappedFontDictionary(), content =
                "BT /F1 100 Tf $mode Tr 1 0 0 1 100 100 Tm <01> Tj ET")
            assertEquals(expected.toString(), actual.toString())
            assertEquals(expected.left, actual.left, .001f)
            assertEquals(expected.bottom, actual.bottom, .001f)
        }
    }

    private fun spaceFontDictionary(bytes: ByteArray): PdfDictionary =
        metricFontDictionary(PdfName.TrueType, PdfName.FontFile2, bytes).apply {
            put(PdfName.FirstChar, PdfNumber(32))
            put(PdfName.LastChar, PdfNumber(65))
            put(PdfName.Widths, PdfArray(IntArray(34) { 500 }))
        }

    @Test
    fun invalidNumericTextAdjustmentDoesNotPoisonFollowingText() {
        val content = "BT /F1 100 Tf 1 0 0 1 100 100 Tm [<01> - <01> 25 <01>] TJ ET"
        val actual = byteMappedTextBounds(byteMappedFontDictionary(), content = content)
        val expected = byteMappedTextBounds(byteMappedFontDictionary(), content = content.replace(" - ", " 0 "))
        assertEquals(expected.left, actual.left, .001f)
        assertEquals(expected.right, actual.right, .001f)
        assertEquals(expected.bottom, actual.bottom, .001f)
        assertEquals(expected.top, actual.top, .001f)
    }

    @Test
    fun invalidNumericCidAdjustmentDoesNotPoisonFollowingText() {
        val content = "BT /F1 100 Tf 1 0 0 1 100 100 Tm [<0002> - <0002> 25 <0002>] TJ ET"
        val actual = byteMappedTextBounds(cidFontDictionary(), content = content)
        val expected = byteMappedTextBounds(cidFontDictionary(), content = content.replace(" - ", " 0 "))
        assertEquals(expected.left, actual.left, .001f)
        assertEquals(expected.right, actual.right, .001f)
    }

    @Test
    fun unpaintedAndClippingPathsDoNotEnlargeVisibleBounds() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            page.newContentStreamAfter().setData("0 0 500 500 re n 0 0 400 400 re W n 10 20 30 40 re f"
                .toByteArray(Charsets.US_ASCII))
            var measured: Rectangle? = null
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is PathRenderInfo) PdfFitGeometry.includePath(data) {
                        measured = Rectangle.getCommonRectangle(measured, it)
                    }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH)
            }
            PdfFitGeometry.Processor(listener).processPageContent(page)
            val box = requireNotNull(measured)
            assertEquals(10f, box.left, .001f)
            assertEquals(20f, box.bottom, .001f)
            assertEquals(40f, box.right, .001f)
            assertEquals(60f, box.top, .001f)
        }
    }

    @Test
    fun cubicStrokeUsesRealExtremaRatherThanControlPointBounds() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            page.newContentStreamAfter().setData("2 w 0 0 m 100 0 100 100 0 100 c S".toByteArray(Charsets.US_ASCII))
            val bounds = firstStrokeBounds(page)
            assertEquals(-1f, bounds.left, .001f)
            assertEquals(-1f, bounds.bottom, .001f)
            assertEquals(76f, bounds.right, .001f)
            assertEquals(101f, bounds.top, .001f)
        }
    }

    @Test
    fun transformedCubicExtremaAreMeasuredAfterRotation() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            page.newContentStreamAfter().setData("0 1 -1 0 0 0 cm 2 w 0 0 m 100 0 100 100 0 100 c S"
                .toByteArray(Charsets.US_ASCII))
            val bounds = firstStrokeBounds(page)
            assertEquals(-101f, bounds.left, .001f)
            assertEquals(-1f, bounds.bottom, .001f)
            assertEquals(1f, bounds.right, .001f)
            assertEquals(76f, bounds.top, .001f)
        }
    }

    @Test
    fun smoothClosedCurvesDoNotUseTheMaximumMiterLimitAsPadding() {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            page.newContentStreamAfter().setData(
                "2 w 10 M 0 0 m 100 0 100 100 0 100 c -100 100 -100 0 0 0 c h S"
                    .toByteArray(Charsets.US_ASCII))
            val bounds = firstStrokeBounds(page)
            assertEquals(-76f, bounds.left, .001f)
            assertEquals(-1f, bounds.bottom, .001f)
            assertEquals(76f, bounds.right, .001f)
            assertEquals(101f, bounds.top, .001f)
        }
    }

    @Test
    fun embeddedCidCompactFontUsesIndividualContoursInsteadOfTheWholeFontBox() {
        val dictionary = cidFontDictionary()
        val descendant = dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
        descendant.put(PdfName.Subtype, PdfName.CIDFontType0)
        val descriptor = descendant.getAsDictionary(PdfName.FontDescriptor)
        descriptor.remove(PdfName.FontFile2)
        descriptor.put(PdfName.FontFile3, PdfStream(PdfCffBoundsTest.font(PdfCffBoundsTest.rectangle())).apply {
            put(PdfName.Subtype, PdfName("CIDFontType0C"))
        })
        val bounds = byteMappedTextBounds(dictionary, code = 2)
        assertEquals(100f, bounds.left, .001f)
        assertEquals(150f, bounds.right, .001f)
        assertTrue(bounds.bottom >= 80f && bounds.top <= 200f)
    }

    @Test
    fun unsupportedCompactGlyphRetainsTheConservativeFontBox() {
        val dictionary = cidFontDictionary()
        val descendant = dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
        descendant.put(PdfName.Subtype, PdfName.CIDFontType0)
        val descriptor = descendant.getAsDictionary(PdfName.FontDescriptor)
        descriptor.remove(PdfName.FontFile2)
        descriptor.put(PdfName.FontFile3, PdfStream(PdfCffBoundsTest.font(byteArrayOf(16, 14))).apply {
            put(PdfName.Subtype, PdfName("CIDFontType0C"))
        })
        val bounds = byteMappedTextBounds(dictionary, code = 2)
        assertEquals(0f, bounds.left, .001f)
        assertEquals(300f, bounds.right, .001f)
    }

    @Test
    fun compactGlyphUsesTheOriginalCidEvenWithoutAUnicodeMapping() {
        val dictionary = cidFontDictionary()
        dictionary.remove(PdfName.ToUnicode)
        val descendant = dictionary.getAsArray(PdfName.DescendantFonts).getAsDictionary(0)
        descendant.put(PdfName.Subtype, PdfName.CIDFontType0)
        val descriptor = descendant.getAsDictionary(PdfName.FontDescriptor)
        descriptor.remove(PdfName.FontFile2)
        descriptor.put(PdfName.FontFile3, PdfStream(PdfCffBoundsTest.font(PdfCffBoundsTest.rectangle())).apply {
            put(PdfName.Subtype, PdfName("CIDFontType0C"))
        })
        val bounds = byteMappedTextBounds(dictionary, code = 2)
        assertEquals(100f, bounds.left, .001f)
        assertEquals(150f, bounds.right, .001f)
    }

    private fun firstStrokeBounds(page: PdfPage): Rectangle {
        var box: Rectangle? = null
        val listener = object : IEventListener {
            override fun eventOccurred(data: IEventData?, type: EventType?) {
                if (data is PathRenderInfo && data.operation and PathRenderInfo.STROKE != 0 && box == null) {
                    PdfFitGeometry.includePath(data) { box = it }
                }
            }
            override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH)
        }
        PdfFitGeometry.Processor(listener).processPageContent(page)
        return requireNotNull(box)
    }

    private fun byteMappedFontDictionary(code: Int = 1): PdfDictionary {
        val descriptor = PdfDictionary().apply {
            put(PdfName.FontName, PdfName("Synthetic"))
            put(PdfName.Ascent, PdfNumber(200))
            put(PdfName.Descent, PdfNumber(-10))
            put(PdfName.Flags, PdfNumber(4))
            put(PdfName.FontBBox, PdfArray(intArrayOf(-1000, -200, 2000, 1000)))
            put(PdfName.FontFile2, PdfStream(fontBytes(symbolicCode = code)))
        }
        val hex = code.toString(16).padStart(2, '0')
        val next = (code + 1).toString(16).padStart(2, '0')
        return PdfDictionary().apply {
            put(PdfName.Type, PdfName.Font)
            put(PdfName.Subtype, PdfName.TrueType)
            put(PdfName.BaseFont, PdfName("Synthetic"))
            put(PdfName.FirstChar, PdfNumber(0))
            put(PdfName.LastChar, PdfNumber(255))
            put(PdfName.Widths, PdfArray(IntArray(256) { 500 }))
            put(PdfName.FontDescriptor, descriptor)
            put(PdfName.ToUnicode, PdfStream("""
                /CIDInit /ProcSet findresource begin
                12 dict begin begincmap
                /CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def
                /CMapName /Synthetic def /CMapType 2 def
                1 begincodespacerange <00> <ff> endcodespacerange
                2 beginbfchar <$hex> <0041> <$next> <0042> endbfchar
                endcmap CMapName currentdict /CMap defineresource pop end end
            """.trimIndent().toByteArray(Charsets.US_ASCII)))
        }
    }

    private fun metricFontDictionary(subtype: PdfName, streamName: PdfName? = null, bytes: ByteArray? = null): PdfDictionary {
        val descriptor = PdfDictionary().apply {
            put(PdfName.FontName, PdfName("Synthetic"))
            put(PdfName.Ascent, PdfNumber(800))
            put(PdfName.Descent, PdfNumber(-200))
            put(PdfName.FontBBox, PdfArray(intArrayOf(0, -200, 500, 800)))
            if (streamName != null) put(streamName, PdfStream(requireNotNull(bytes)))
        }
        return PdfDictionary().apply {
            put(PdfName.Type, PdfName.Font)
            put(PdfName.Subtype, subtype)
            put(PdfName.BaseFont, PdfName("Synthetic"))
            put(PdfName.Encoding, PdfName.WinAnsiEncoding)
            put(PdfName.FirstChar, PdfNumber(65))
            put(PdfName.LastChar, PdfNumber(65))
            put(PdfName.Widths, PdfArray(intArrayOf(500)))
            put(PdfName.FontDescriptor, descriptor)
        }
    }

    private fun cidFontDictionary(mapping: ByteArray? = null): PdfDictionary {
        val descriptor = metricFontDictionary(PdfName.TrueType, PdfName.FontFile2, fontBytes())
            .getAsDictionary(PdfName.FontDescriptor)
        descriptor.put(PdfName.FontBBox, PdfArray(intArrayOf(-1000, -200, 2000, 1000)))
        val descendant = PdfDictionary().apply {
            put(PdfName.Type, PdfName.Font)
            put(PdfName.Subtype, PdfName.CIDFontType2)
            put(PdfName.BaseFont, PdfName("Synthetic"))
            put(PdfName.CIDSystemInfo, PdfDictionary().apply {
                put(PdfName.Registry, com.itextpdf.kernel.pdf.PdfString("Adobe"))
                put(PdfName.Ordering, com.itextpdf.kernel.pdf.PdfString("Identity"))
                put(PdfName.Supplement, PdfNumber(0))
            })
            put(PdfName.DW, PdfNumber(500))
            put(PdfName.FontDescriptor, descriptor)
            put(PdfName.CIDToGIDMap, mapping?.let(::PdfStream) ?: PdfName.Identity)
        }
        return PdfDictionary().apply {
            put(PdfName.Type, PdfName.Font)
            put(PdfName.Subtype, PdfName.Type0)
            put(PdfName.BaseFont, PdfName("Synthetic"))
            put(PdfName.Encoding, PdfName.IdentityH)
            put(PdfName.DescendantFonts, PdfArray().apply { add(descendant) })
            put(PdfName.ToUnicode, PdfStream("""
                /CIDInit /ProcSet findresource begin
                12 dict begin begincmap
                /CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def
                /CMapName /Synthetic def /CMapType 2 def
                1 begincodespacerange <0000> <ffff> endcodespacerange
                1 beginbfchar <0002> <0041> endbfchar
                endcmap CMapName currentdict /CMap defineresource pop end end
            """.trimIndent().toByteArray(Charsets.US_ASCII)))
        }
    }

    private fun assertMetricTextBounds(
        dictionary: PdfDictionary,
        matrix: String = "1 0 0 1 100 100",
        geometry: PdfFitGeometry = PdfFitGeometry()
    ) {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            dictionary.makeIndirect(pdf)
            page.resources.pdfObject.put(PdfName.Font, PdfDictionary().apply { put(PdfName("F1"), dictionary) })
            page.newContentStreamAfter().setData(
                "BT /F1 100 Tf $matrix Tm (A) Tj ET".toByteArray(Charsets.US_ASCII)
            )
            var measured: Rectangle? = null
            var expected: Rectangle? = null
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is TextRenderInfo) {
                        expected = Rectangle.getCommonRectangle(data.ascentLine.boundingRectangle, data.descentLine.boundingRectangle)
                        geometry.includeText(data) { measured = Rectangle.getCommonRectangle(measured, it) }
                    }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_TEXT)
            }
            PdfFitGeometry.Processor(listener).processPageContent(page)
            val result = requireNotNull(measured)
            val reference = requireNotNull(expected)
            assertTrue(result.width > 0f && result.height > 0f)
            assertEquals(reference.left, result.left, 0.001f)
            assertEquals(reference.bottom, result.bottom, 0.001f)
            assertEquals(reference.right, result.right, 0.001f)
            assertEquals(reference.top, result.top, 0.001f)
        }
    }

    private fun byteMappedTextBounds(
        dictionary: PdfDictionary,
        code: Int = 1,
        geometry: PdfFitGeometry = PdfFitGeometry(),
        content: String? = null
    ): Rectangle {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            page.resources.pdfObject.put(PdfName.Font, PdfDictionary().apply { put(PdfName("F1"), dictionary) })
            val size = if (dictionary.getAsName(PdfName.Subtype) == PdfName.Type0) 4 else 2
            val hex = code.toString(16).padStart(size, '0')
            page.newContentStreamAfter().setData(
                (content ?: "BT /F1 100 Tf 1 0 0 1 100 100 Tm <$hex> Tj ET").toByteArray(Charsets.US_ASCII)
            )
            var box: Rectangle? = null
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is TextRenderInfo) geometry.includeText(data) {
                        box = Rectangle.getCommonRectangle(box, it)
                    }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_TEXT)
            }
            val originalContent = page.contentBytes
            val originalWidths = dictionary.getAsArray(PdfName.DescendantFonts)?.getAsDictionary(0)?.get(PdfName.W)?.toString()
            PdfFitGeometry.Processor(listener).processPageContent(page)
            assertArrayEquals(originalContent, page.contentBytes)
            assertEquals(originalWidths, dictionary.getAsArray(PdfName.DescendantFonts)?.getAsDictionary(0)?.get(PdfName.W)?.toString())
            return requireNotNull(box)
        }
    }

    private fun fontBytes(unicode: Int = 65, symbolicCode: Int? = null): ByteArray {
        val buffer = ByteBuffer.allocate(768)
        buffer.putInt(0, 0x00010000).putShort(4, 5)
        val tables = listOf("head" to 54, "maxp" to 6, "loca" to 6, "glyf" to 10,
            "cmap" to if (symbolicCode == null) 44 else 274)
        var offset = 92
        val positions = HashMap<String, Int>()
        for ((index, table) in tables.withIndex()) {
            val record = 12 + index * 16
            buffer.position(record)
            buffer.put(table.first.toByteArray(Charsets.US_ASCII))
            buffer.putInt(record + 8, offset).putInt(record + 12, table.second)
            positions[table.first] = offset
            offset += table.second
        }
        buffer.putShort(positions.getValue("head") + 18, 1000)
        buffer.putShort(positions.getValue("maxp") + 4, 2)
        buffer.putShort(positions.getValue("loca") + 4, 5)
        val glyph = positions.getValue("glyf")
        for ((index, value) in listOf(1, -10, -50, 720, 800).withIndex()) {
            buffer.putShort(glyph + index * 2, value.toShort())
        }
        val cmap = positions.getValue("cmap")
        if (symbolicCode != null) {
            buffer.putShort(cmap + 2, 1).putShort(cmap + 4, 1).putShort(cmap + 6, 0).putInt(cmap + 8, 12)
            val sub = cmap + 12
            buffer.putShort(sub, 0).putShort(sub + 2, 262).put(sub + 6 + symbolicCode, 1)
            return buffer.array()
        }
        buffer.putShort(cmap + 2, 1).putShort(cmap + 4, 3).putShort(cmap + 6, 1).putInt(cmap + 8, 12)
        val sub = cmap + 12
        buffer.putShort(sub, 4).putShort(sub + 2, 32).putShort(sub + 6, 4)
        buffer.putShort(sub + 14, unicode.toShort()).putShort(sub + 16, -1)
        buffer.putShort(sub + 20, unicode.toShort()).putShort(sub + 22, -1)
        buffer.putShort(sub + 24, (1 - unicode).toShort()).putShort(sub + 26, 1)
        return buffer.array()
    }
}
