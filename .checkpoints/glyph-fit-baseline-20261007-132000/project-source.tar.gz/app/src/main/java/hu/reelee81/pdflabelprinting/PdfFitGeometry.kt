package hu.reelee81.pdflabelprinting

import com.itextpdf.io.font.FontProgram
import com.itextpdf.io.font.FontProgramFactory
import com.itextpdf.io.font.constants.StandardFonts
import com.itextpdf.io.source.PdfTokenizer
import com.itextpdf.io.source.RandomAccessFileOrArray
import com.itextpdf.io.source.RandomAccessSourceFactory
import com.itextpdf.kernel.geom.Matrix
import com.itextpdf.kernel.geom.Rectangle
import com.itextpdf.kernel.geom.Vector
import com.itextpdf.kernel.geom.BezierCurve
import com.itextpdf.kernel.geom.Line
import com.itextpdf.kernel.geom.Path
import com.itextpdf.kernel.font.PdfType0Font
import com.itextpdf.kernel.pdf.PdfArray
import com.itextpdf.kernel.pdf.PdfDictionary
import com.itextpdf.kernel.pdf.PdfLiteral
import com.itextpdf.kernel.pdf.PdfName
import com.itextpdf.kernel.pdf.PdfObject
import com.itextpdf.kernel.pdf.PdfNumber
import com.itextpdf.kernel.pdf.PdfResources
import com.itextpdf.kernel.pdf.PdfString
import com.itextpdf.kernel.pdf.canvas.parser.PdfCanvasProcessor
import com.itextpdf.kernel.pdf.canvas.parser.EventType
import com.itextpdf.kernel.pdf.canvas.parser.data.IEventData
import com.itextpdf.kernel.pdf.canvas.parser.data.PathRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.data.TextRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.listener.IEventListener
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.floor
import kotlin.math.ceil

internal class PdfFitGeometry {
    private class FontBounds(
        val trueType: PdfTrueTypeBounds?,
        val cid: Boolean,
        val gidMap: ByteArray?,
        val useByteCodes: Boolean,
        val standard: FontProgram?,
        val fallback: IntArray?,
        val compact: PdfCffBounds? = null
    )

    private class CidCodes(val values: IntArray, val ends: IntArray, val count: Int)

    private val fonts = IdentityHashMap<PdfDictionary, FontBounds>()
    private var retainedBytes = 0
    private var clippingBounds: Rectangle? = null

    fun visibleRectangle(rect: Rectangle): Rectangle? {
        if (!finite(rect)) throw AnalysisLimit()
        val clip = clippingBounds ?: return rect
        if (clip.width <= 0 || clip.height <= 0) return null
        if (rect.left >= clip.left && rect.bottom >= clip.bottom && rect.right <= clip.right && rect.top <= clip.top) return rect
        val left = max(rect.left, clip.left)
        val bottom = max(rect.bottom, clip.bottom)
        val right = min(rect.right, clip.right)
        val top = min(rect.top, clip.top)
        if (right < left || top < bottom) return null
        return Rectangle(left, bottom, right - left, top - bottom)
    }

    fun includeText(info: TextRenderInfo, include: (Rectangle) -> Unit) {
        val textBytes = info.pdfString.valueBytes
        if (textBytes.isEmpty()) return
        if (info.textRenderMode == 3 || info.textRenderMode == 7) return
        if (emptySpaceRun(info, textBytes)) return
        val ascent = info.ascentLine.boundingRectangle
        val descent = info.descentLine.boundingRectangle
        if (!finite(ascent) || !finite(descent)) throw AnalysisLimit()
        include(ascent)
        include(descent)
        if (textBytes.size > 4096) throw AnalysisLimit()
        val font = info.font
        if (font.pdfObject.getAsName(PdfName.Subtype) == PdfName.Type3) return
        if (font is PdfType0Font && font.cmap.cmapName.endsWith("V")) return

        val bounds = try {
            fonts[font.pdfObject] ?: fontBounds(font.pdfObject).also {
                if (fonts.size < 4) fonts[font.pdfObject] = it
            }
        } catch (limit: AnalysisLimit) {
            throw limit
        } catch (_: RuntimeException) {
            return
        }
        if (bounds.trueType == null && bounds.compact == null && bounds.standard == null && bounds.fallback == null) return
        val codes = if (font is PdfType0Font && (bounds.trueType != null || bounds.compact != null)) try {
            cidCodes(font, textBytes)
        } catch (_: RuntimeException) {
            null
        } else null
        val characters = try {
            if (codes?.count == 1) listOf(info) else info.characterRenderInfos
        } catch (_: RuntimeException) {
            return
        }
        val cids = codes?.takeIf { it.count == characters.size }?.values
        for ((characterIndex, character) in characters.withIndex()) {
            val line = try {
                font.decodeIntoGlyphLine(character.pdfString)
            } catch (_: RuntimeException) {
                continue
            }
            if (line.end - line.start != 1) continue
            val glyph = line[line.start]
            val trueTypeBox = try {
                val gid = if (bounds.cid) {
                    val cid = cids?.get(characterIndex)
                    val map = bounds.gidMap
                    if (cid == null || map == null) cid else {
                        val index = cid.toLong() * 2
                        if (index < 0 || index + 1 >= map.size) null else {
                            ((map[index.toInt()].toInt() and 255) shl 8) or
                                (map[index.toInt() + 1].toInt() and 255)
                        }
                    }
                } else bounds.trueType?.let { metrics ->
                    val bytes = if (bounds.useByteCodes) character.pdfString.valueBytes else null
                    val direct = if (bytes?.size == 1) metrics.glyphForSymbolicByte(bytes[0].toInt() and 255) else null
                    direct ?: metrics.glyphForUnicode(glyph.unicode)
                }
                gid?.let { bounds.trueType?.glyphBox(it) }
            } catch (_: RuntimeException) {
                null
            }
            val ink = trueTypeBox
                ?: cids?.get(characterIndex)?.let { bounds.compact?.glyphBox(it) }
                ?: bounds.standard?.getCharBBox(glyph.unicode)
                ?: (if (bounds.standard != null && glyph.unicode == 32) intArrayOf(0, 0, 0, 0) else null)
                ?: bounds.fallback
                ?: continue
            val units = if (trueTypeBox != null) requireNotNull(bounds.trueType).unitsPerEm else 1000
            val state = character.graphicsState
            val matrix = character.textMatrix.multiply(state.ctm)
            val sx = character.fontSize * character.horizontalScaling / 100f / units
            val sy = character.fontSize / units
            var left = Float.POSITIVE_INFINITY
            var bottom = Float.POSITIVE_INFINITY
            var right = Float.NEGATIVE_INFINITY
            var top = Float.NEGATIVE_INFINITY
            for (x in intArrayOf(ink[0], ink[2])) for (y in intArrayOf(ink[1], ink[3])) {
                val point = Vector(x * sx, y * sy + state.textRise, 1f).cross(matrix)
                left = min(left, point.get(Vector.I1))
                bottom = min(bottom, point.get(Vector.I2))
                right = max(right, point.get(Vector.I1))
                top = max(top, point.get(Vector.I2))
            }
            if (!left.isFinite() || !bottom.isFinite() || !right.isFinite() || !top.isFinite()) throw AnalysisLimit()
            include(Rectangle(left, bottom, right - left, top - bottom))
        }
    }

    private fun emptySpaceRun(info: TextRenderInfo, bytes: ByteArray): Boolean {
        if (bytes.size > 4096 || bytes.any { it.toInt() != 32 }) return false
        val font = info.font
        val dictionary = font.pdfObject
        return dictionary.getAsName(PdfName.Subtype) == PdfName.TrueType &&
            dictionary.getAsName(PdfName.Encoding) == PdfName.WinAnsiEncoding && try {
            val bounds = fonts[dictionary] ?: fontBounds(dictionary).also {
                if (fonts.size < 4) fonts[dictionary] = it
            }
            if (bounds.useByteCodes) return false
            val metrics = bounds.trueType ?: return false
            val line = font.decodeIntoGlyphLine(info.pdfString)
            if (line.end <= line.start || (line.start until line.end).any { line[it].unicode != 32 }) return false
            val gid = metrics.glyphForUnicode(32) ?: return false
            metrics.glyphIsEmpty(gid)
        } catch (limit: AnalysisLimit) {
            throw limit
        } catch (_: RuntimeException) {
            false
        }
    }

    private fun fontBounds(font: PdfDictionary): FontBounds {
        val cid = font.getAsName(PdfName.Subtype) == PdfName.Type0
        val descendant = if (cid) font.getAsArray(PdfName.DescendantFonts)?.getAsDictionary(0) else font
        val descriptor = descendant?.getAsDictionary(PdfName.FontDescriptor)
        val fallback = descriptor?.getAsArray(PdfName.FontBBox)?.toFloatArray()?.takeIf {
            it.size == 4 && it.all(Float::isFinite) && it[2] >= it[0] && it[3] > it[1]
        }?.let { values -> IntArray(4) { if (it < 2) floor(values[it]).toInt() else ceil(values[it]).toInt() } }
        if (descriptor?.containsKey(PdfName.FontFile) == true || descriptor?.containsKey(PdfName.FontFile3) == true) {
            val stream = descriptor.getAsStream(PdfName.FontFile3)
            val compact = if (cid && stream?.getAsName(PdfName.Subtype)?.value == "CIDFontType0C" &&
                fonts.size < 4 && retainedBytes < 1024 * 1024) {
                PdfBoundedStream.read(stream, min(512 * 1024, 1024 * 1024 - retainedBytes))?.let { bytes ->
                    try {
                        PdfCffBounds(bytes).also { retainedBytes += bytes.size }
                    } catch (_: IllegalArgumentException) {
                        null
                    }
                }
            } else null
            val matrix = if (fallback != null && fonts.size < 4 && retainedBytes < 1024 * 1024) {
                descriptor.getAsStream(PdfName.FontFile)?.let { stream ->
                    PdfBoundedStream.read(stream, min(512 * 1024, 1024 * 1024 - retainedBytes))?.let(::fontMatrix)
                }
            } else null
            return FontBounds(null, cid, null, false, null, transformedFontBox(fallback, matrix), compact)
        }
        var trueType: PdfTrueTypeBounds? = null
        var gidMap: ByteArray? = null
        if (fonts.size < 4 && retainedBytes < 1024 * 1024) {
            val bytes = descriptor?.getAsStream(PdfName.FontFile2)?.let { PdfBoundedStream.read(it, 512 * 1024) }
            if (bytes != null && retainedBytes + bytes.size <= 1024 * 1024) {
                trueType = try {
                    PdfTrueTypeBounds(bytes)
                } catch (_: IllegalArgumentException) {
                    null
                }
                if (trueType != null) retainedBytes += bytes.size
            }
            val mapping = descendant?.get(PdfName.CIDToGIDMap)
            if (mapping is com.itextpdf.kernel.pdf.PdfStream && trueType != null) {
                gidMap = PdfBoundedStream.read(mapping, min(128 * 1024, 1024 * 1024 - retainedBytes))
                    ?: return FontBounds(null, cid, null, false, null, fallback)
                retainedBytes += gidMap.size
            }
        }
        val name = font.getAsName(PdfName.BaseFont)?.value
        val standard = name?.takeIf { StandardFonts.isStandardFont(it) }?.let {
            FontProgramFactory.createFont(it, false)
        }
        if (descriptor?.containsKey(PdfName.FontFile2) == true && trueType == null) {
            return FontBounds(null, cid, null, false, null, fallback)
        }
        val useByteCodes = !cid && font.getAsName(PdfName.Subtype) == PdfName.TrueType &&
            (!font.containsKey(PdfName.Encoding) || (descriptor?.getAsNumber(PdfName.Flags)?.intValue() ?: 0) and 4 != 0)
        return FontBounds(trueType, cid, gidMap, useByteCodes, standard, fallback)
    }

    private fun fontMatrix(bytes: ByteArray): Matrix? {
        return try {
            PdfTokenizer(RandomAccessFileOrArray(RandomAccessSourceFactory().createSource(bytes))).use { tokens ->
                var count = 0
                while (++count <= 4096 && tokens.position < 64 * 1024 && tokens.nextToken()) {
                    if (tokens.tokenType == PdfTokenizer.TokenType.Other && tokens.stringValue == "eexec") break
                    if (tokens.tokenType != PdfTokenizer.TokenType.Name || tokens.stringValue != "FontMatrix") continue
                    if (!tokens.nextToken() || tokens.tokenType != PdfTokenizer.TokenType.StartArray) return null
                    val values = FloatArray(6)
                    for (index in values.indices) {
                        if (!tokens.nextToken() || tokens.tokenType != PdfTokenizer.TokenType.Number) return null
                        values[index] = tokens.stringValue.toFloatOrNull()?.takeIf(Float::isFinite) ?: return null
                    }
                    if (!tokens.nextToken() || tokens.tokenType != PdfTokenizer.TokenType.EndArray) return null
                    return Matrix(values[0], values[1], values[2], values[3], values[4], values[5])
                }
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun transformedFontBox(box: IntArray?, matrix: Matrix?): IntArray? {
        if (box == null || matrix == null) return box
        val normalized = Matrix(
            matrix.get(Matrix.I11) * 1000, matrix.get(Matrix.I12) * 1000,
            matrix.get(Matrix.I21) * 1000, matrix.get(Matrix.I22) * 1000,
            matrix.get(Matrix.I31) * 1000, matrix.get(Matrix.I32) * 1000
        )
        var left = Float.POSITIVE_INFINITY
        var bottom = Float.POSITIVE_INFINITY
        var right = Float.NEGATIVE_INFINITY
        var top = Float.NEGATIVE_INFINITY
        for (x in intArrayOf(box[0], box[2])) for (y in intArrayOf(box[1], box[3])) {
            val point = Vector(x.toFloat(), y.toFloat(), 1f).cross(normalized)
            left = min(left, point.get(Vector.I1))
            bottom = min(bottom, point.get(Vector.I2))
            right = max(right, point.get(Vector.I1))
            top = max(top, point.get(Vector.I2))
        }
        if (!left.isFinite() || !bottom.isFinite() || !right.isFinite() || !top.isFinite()) throw AnalysisLimit()
        if (left <= Int.MIN_VALUE.toFloat() || bottom <= Int.MIN_VALUE.toFloat() ||
            right >= Int.MAX_VALUE.toFloat() || top >= Int.MAX_VALUE.toFloat()) throw AnalysisLimit()
        return intArrayOf(floor(left).toInt(), floor(bottom).toInt(), ceil(right).toInt(), ceil(top).toInt())
    }

    companion object {
        private fun finite(rect: Rectangle): Boolean =
            rect.x.isFinite() && rect.y.isFinite() && rect.width.isFinite() && rect.height.isFinite()

        private fun cidCodes(font: PdfType0Font, bytes: ByteArray): CidCodes? {
            if (bytes.size > 4096) throw AnalysisLimit()
            val ranges = font.cmap.codeSpaceRanges
            if (ranges.size !in 2..128 || ranges.size % 2 != 0) return null
            if (ranges.any { it.size !in 1..4 }) return null
            val values = IntArray(bytes.size)
            val ends = IntArray(bytes.size)
            var offset = 0
            var count = 0
            while (offset < bytes.size) {
                var code = 0
                var length = 0
                for (size in 1..min(4, bytes.size - offset)) {
                    code = (code shl 8) or (bytes[offset + size - 1].toInt() and 255)
                    val unsigned = code.toLong() and 0xffffffffL
                    for (index in ranges.indices step 2) {
                        val low = ranges[index]
                        val high = ranges[index + 1]
                        if (low.size != high.size) return null
                        if (low.size != size) continue
                        val first = low.fold(0L) { value, byte -> (value shl 8) or (byte.toLong() and 255) }
                        val last = high.fold(0L) { value, byte -> (value shl 8) or (byte.toLong() and 255) }
                        if (unsigned in first..last) {
                            length = size
                            break
                        }
                    }
                    if (length != 0) break
                }
                if (length == 0) return null
                values[count] = font.cmap.getCidCode(code)
                offset += length
                ends[count++] = offset
            }
            return CidCodes(values, ends, count)
        }

        fun includePath(info: PathRenderInfo, include: (Rectangle) -> Unit) {
            if (info.operation == PathRenderInfo.NO_OP) return
            var left = Float.POSITIVE_INFINITY
            var bottom = Float.POSITIVE_INFINITY
            var right = Float.NEGATIVE_INFINITY
            var top = Float.NEGATIVE_INFINITY
            var segments = 0
            var axisAligned = true
            var smoothJoins = true
            var openPath = false
            fun includeX(value: Double) {
                if (!value.isFinite() || !value.toFloat().isFinite()) throw AnalysisLimit()
                left = min(left, value.toFloat())
                right = max(right, value.toFloat())
            }
            fun includeY(value: Double) {
                if (!value.isFinite() || !value.toFloat().isFinite()) throw AnalysisLimit()
                bottom = min(bottom, value.toFloat())
                top = max(top, value.toFloat())
            }
            for (sub in info.path.subpaths) for (segment in sub.segments) {
                if (++segments > 4096) throw AnalysisLimit()
                val points = segment.basePoints
                if (axisAligned) {
                    val start = points.firstOrNull()
                    axisAligned = when (segment) {
                        is Line -> points.size == 2 &&
                            (points[0].x == points[1].x || points[0].y == points[1].y)
                        is BezierCurve -> start != null && points.all { it.x == start.x && it.y == start.y }
                        else -> false
                    }
                }
                val transformed = points.map { point ->
                    val vector = Vector(point.x.toFloat(), point.y.toFloat(), 1f).cross(info.ctm)
                    if (!vector.get(Vector.I1).isFinite() || !vector.get(Vector.I2).isFinite()) throw AnalysisLimit()
                    vector
                }
                if (segment is BezierCurve && transformed.size == 4) {
                    PdfCurveBounds.include(transformed[0].get(Vector.I1).toDouble(), transformed[1].get(Vector.I1).toDouble(),
                        transformed[2].get(Vector.I1).toDouble(), transformed[3].get(Vector.I1).toDouble(), ::includeX)
                    PdfCurveBounds.include(transformed[0].get(Vector.I2).toDouble(), transformed[1].get(Vector.I2).toDouble(),
                        transformed[2].get(Vector.I2).toDouble(), transformed[3].get(Vector.I2).toDouble(), ::includeY)
                } else for (point in transformed) {
                    includeX(point.get(Vector.I1).toDouble())
                    includeY(point.get(Vector.I2).toDouble())
                }
            }
            for (sub in info.path.subpaths) {
                if (sub.segments.isEmpty()) continue
                val start = sub.startPoint
                val end = sub.segments.last().basePoints.last()
                if (axisAligned && sub.isClosed) axisAligned = start.x == end.x || start.y == end.y
                if (!sub.isClosed) openPath = true
                var firstX = 0.0
                var firstY = 0.0
                var previousX = 0.0
                var previousY = 0.0
                var found = false
                fun join(x: Double, y: Double) {
                    val cross = previousX * y - previousY * x
                    val dot = previousX * x + previousY * y
                    if (dot <= 0 || cross * cross > 1e-12 *
                        (previousX * previousX + previousY * previousY) * (x * x + y * y)) smoothJoins = false
                }
                for (segment in sub.segments) {
                    val points = segment.basePoints
                    val from = points.first()
                    val to = points.last()
                    val outgoing = points.firstOrNull { it.x != from.x || it.y != from.y } ?: continue
                    val incoming = points.lastOrNull { it.x != to.x || it.y != to.y } ?: continue
                    val dx = outgoing.x - from.x
                    val dy = outgoing.y - from.y
                    if (found) join(dx, dy) else {
                        firstX = dx
                        firstY = dy
                        found = true
                    }
                    previousX = to.x - incoming.x
                    previousY = to.y - incoming.y
                }
                if (found && sub.isClosed) {
                    if (start.x != end.x || start.y != end.y) {
                        join(start.x - end.x, start.y - end.y)
                        previousX = start.x - end.x
                        previousY = start.y - end.y
                    }
                    join(firstX, firstY)
                }
            }
            if (!left.isFinite()) return
            if (info.operation and PathRenderInfo.STROKE != 0) {
                val stroke = PdfStrokeBounds.measure(info)
                if (stroke != null) {
                    include(Rectangle.getCommonRectangle(Rectangle(left, bottom, right - left, top - bottom), stroke))
                    return
                }
                val half = abs(info.lineWidth) / 2
                var join = if (info.lineJoinStyle == 0 && !axisAligned && !smoothJoins) max(1f, info.miterLimit) else 1f
                if (openPath && !axisAligned && info.lineCapStyle == 2) join = max(join, 1.414214f)
                val px = half * join * (abs(info.ctm[0]) + abs(info.ctm[3]))
                val py = half * join * (abs(info.ctm[1]) + abs(info.ctm[4]))
                left -= px
                right += px
                bottom -= py
                top += py
            }
            val box = Rectangle(left, bottom, right - left, top - bottom)
            if (!finite(box)) throw AnalysisLimit()
            include(box)
        }
    }

    class Processor(listener: IEventListener, private val geometry: PdfFitGeometry?) : PdfCanvasProcessor(listener) {
        constructor(listener: IEventListener) : this(listener, null)

        private var operators = 0
        private var decodedBytes = 0L
        private var depth = 0
        private val deadline = System.nanoTime() + 2_000_000_000L
        private var clip: Rectangle? = null
        private val savedClips = ArrayList<Rectangle?>()
        private var clipStackFloor = 0

        override fun eventOccurred(data: IEventData?, type: EventType?) {
            val previous = geometry?.clippingBounds
            geometry?.clippingBounds = clip
            try {
                super.eventOccurred(data, type)
            } finally {
                geometry?.clippingBounds = previous
            }
        }

        override fun processContent(contentBytes: ByteArray, resources: PdfResources) {
            decodedBytes += contentBytes.size
            if (decodedBytes > 8 * 1024 * 1024 || ++depth > 32) throw AnalysisLimit()
            try {
                super.processContent(contentBytes, resources)
            } finally {
                depth--
            }
        }

        override fun invokeOperator(operator: PdfLiteral, operands: MutableList<PdfObject>) {
            if (++operators > 200_000 || System.nanoTime() > deadline) throw AnalysisLimit()
            var clipSegments = 0
            for (sub in graphicsState.clippingPath?.subpaths.orEmpty()) {
                clipSegments += sub.segments.size
                if (clipSegments > 128) throw AnalysisLimit()
            }
            when (operator.toString()) {
                "q" -> {
                    if (savedClips.size >= 128) throw AnalysisLimit()
                    savedClips.add(clip)
                }
                "Q" -> {
                    if (savedClips.size <= clipStackFloor) throw AnalysisLimit()
                    clip = savedClips.removeAt(savedClips.lastIndex)
                }
                "Do" -> {
                    val name = operands[0] as PdfName
                    val stream = getXObjectStream(name)
                    if (stream.getAsName(PdfName.Subtype) == PdfName.Form) {
                        processForm(operator, operands, stream.getAsArray(PdfName.BBox), stream.getAsArray(PdfName.Matrix))
                        return
                    }
                }
            }
            val effective = if (operator.toString() == "TJ") {
                val array = operands[0] as PdfArray
                if (array.size() > 4096) throw AnalysisLimit()
                if (array.any { it is PdfNumber && !it.floatValue().isFinite() }) {
                    mutableListOf<PdfObject>(PdfArray().apply {
                        for (entry in array) add(if (entry is PdfNumber && !entry.floatValue().isFinite()) PdfNumber(0) else entry)
                    })
                } else operands
            } else operands
            val font = graphicsState.font as? PdfType0Font
            if (font == null || font.cmap.cmapName.endsWith("V")) {
                super.invokeOperator(operator, effective)
                return
            }
            when (operator.toString()) {
                "Tj" -> showCidText(operands[0] as PdfString, font)
                "TJ" -> {
                    for (entry in effective[0] as PdfArray) {
                        if (System.nanoTime() > deadline) throw AnalysisLimit()
                        if (entry is PdfString) showCidText(entry, font) else {
                            super.invokeOperator(PdfLiteral("TJ"), mutableListOf<PdfObject>(PdfArray().apply { add(entry) }))
                        }
                    }
                }
                "'" -> {
                    super.invokeOperator(PdfLiteral("T*"), mutableListOf())
                    showCidText(operands[0] as PdfString, font)
                }
                "\"" -> {
                    super.invokeOperator(PdfLiteral("Tw"), mutableListOf(operands[0]))
                    super.invokeOperator(PdfLiteral("Tc"), mutableListOf(operands[1]))
                    super.invokeOperator(PdfLiteral("T*"), mutableListOf())
                    showCidText(operands[2] as PdfString, font)
                }
                else -> super.invokeOperator(operator, operands)
            }
        }

        private fun processForm(operator: PdfLiteral, operands: MutableList<PdfObject>, box: PdfArray?, transform: PdfArray?) {
            val previous = clip
            val previousFloor = clipStackFloor
            val stackSize = savedClips.size
            clipStackFloor = stackSize
            try {
                if (box?.size() != 4) throw AnalysisLimit()
                val values = box.toFloatArray()
                if (values.any { !it.isFinite() }) throw AnalysisLimit()
                val left = min(values[0], values[2])
                val bottom = min(values[1], values[3])
                val width = abs(values[2] - values[0])
                val height = abs(values[3] - values[1])
                val matrix = if (transform == null) Matrix() else {
                    if (transform.size() != 6) throw AnalysisLimit()
                    val m = transform.toFloatArray()
                    if (m.any { !it.isFinite() }) throw AnalysisLimit()
                    Matrix(m[0], m[1], m[2], m[3], m[4], m[5])
                }
                val path = Path().apply {
                    rectangle(left, bottom, width, height)
                }
                clip = intersection(clip, pathBox(path, matrix.multiply(graphicsState.ctm)))
                super.invokeOperator(operator, operands)
                if (savedClips.size != stackSize) throw AnalysisLimit()
            } finally {
                while (savedClips.size > stackSize) savedClips.removeAt(savedClips.lastIndex)
                clipStackFloor = previousFloor
                clip = previous
            }
        }

        private fun intersection(previous: Rectangle?, next: Rectangle): Rectangle {
            if (previous == null) return next
            val left = max(previous.left, next.left)
            val bottom = max(previous.bottom, next.bottom)
            val right = min(previous.right, next.right)
            val top = min(previous.top, next.top)
            return Rectangle(left, bottom, max(0f, right - left), max(0f, top - bottom))
        }

        private fun pathBox(path: Path, matrix: Matrix): Rectangle {
            var left = Float.POSITIVE_INFINITY
            var bottom = Float.POSITIVE_INFINITY
            var right = Float.NEGATIVE_INFINITY
            var top = Float.NEGATIVE_INFINITY
            for (sub in path.subpaths) for (segment in sub.segments) for (point in segment.basePoints) {
                val transformed = Vector(point.x.toFloat(), point.y.toFloat(), 1f).cross(matrix)
                val x = transformed.get(Vector.I1)
                val y = transformed.get(Vector.I2)
                if (!x.isFinite() || !y.isFinite()) throw AnalysisLimit()
                left = min(left, x)
                bottom = min(bottom, y)
                right = max(right, x)
                top = max(top, y)
            }
            return if (!left.isFinite()) Rectangle(0f, 0f, 0f, 0f) else Rectangle(left, bottom, right - left, top - bottom)
        }

        private fun showCidText(value: PdfString, font: PdfType0Font) {
            val adjusted = try {
                correctedTextArray(value, font)
            } catch (limit: AnalysisLimit) {
                throw limit
            } catch (_: RuntimeException) {
                null
            }
            if (adjusted == null) super.invokeOperator(PdfLiteral("Tj"), mutableListOf<PdfObject>(value)) else {
                super.invokeOperator(PdfLiteral("TJ"), mutableListOf<PdfObject>(adjusted))
            }
        }

        private fun correctedTextArray(value: PdfString, font: PdfType0Font): PdfArray? {
            val bytes = value.valueBytes
            if (bytes.size > 4096) throw AnalysisLimit()
            if (font.cmap.isDirect) {
                val line = font.decodeIntoGlyphLine(value)
                if ((line.start until line.end).none { line[it].code == 0 && line[it].unicode < 0 }) return null
            }
            val codes = cidCodes(font, bytes) ?: return null
            val array = PdfArray()
            var changed = false
            var start = 0
            for (index in 0 until codes.count) {
                if (System.nanoTime() > deadline) throw AnalysisLimit()
                val raw = bytes.copyOfRange(start, codes.ends[index])
                start = codes.ends[index]
                val text = PdfString(raw)
                val line = font.decodeIntoGlyphLine(text)
                if (line.end - line.start != 1) return null
                val encoded = font.convertToBytes(line[line.start])
                val parsedWidth = font.getContentWidth(PdfString(encoded))
                val width = cidWidth(font, codes.values[index]) ?: return null
                var adjustment = parsedWidth - width
                val rawSpace = raw.size == 1 && raw[0].toInt() == 32
                val encodedSpace = encoded.size == 1 && encoded[0].toInt() == 32
                if (rawSpace != encodedSpace && graphicsState.fontSize != 0f) {
                    val extra = if (rawSpace) graphicsState.wordSpacing else -graphicsState.wordSpacing
                    adjustment -= extra * 1000 / graphicsState.fontSize
                }
                if (!adjustment.isFinite()) throw AnalysisLimit()
                array.add(text)
                if (adjustment != 0f) array.add(PdfNumber(adjustment.toDouble()))
                if (!raw.contentEquals(encoded) || abs(adjustment) > 0.001f) changed = true
            }
            return array.takeIf { changed }
        }

        private fun cidWidth(font: PdfType0Font, cid: Int): Float? {
            val descendant = font.pdfObject.getAsArray(PdfName.DescendantFonts)?.getAsDictionary(0) ?: return null
            val widths = descendant.getAsArray(PdfName.W)
            var index = 0
            while (widths != null && index < widths.size()) {
                if (index > 4096 || System.nanoTime() > deadline) throw AnalysisLimit()
                val first = widths.getAsNumber(index++)?.intValue() ?: return null
                when (val next = widths.get(index++)) {
                    is PdfArray -> {
                        val offset = cid.toLong() - first
                        if (offset >= 0 && offset < next.size()) return next.getAsNumber(offset.toInt())?.floatValue()
                    }
                    is PdfNumber -> {
                        val width = widths.getAsNumber(index++)?.floatValue() ?: return null
                        if (cid in first..next.intValue()) return width
                    }
                    else -> return null
                }
            }
            return descendant.getAsNumber(PdfName.DW)?.floatValue() ?: 1000f
        }

        override fun paintPath(operation: Int, rule: Int) {
            var segments = 0
            for (sub in currentPath.subpaths) {
                segments += sub.segments.size
                if (segments > if (isClip) 128 else 4096) throw AnalysisLimit()
                if (isClip && sub.segments.any { it is BezierCurve }) throw AnalysisLimit()
            }
            val next = if (isClip) pathBox(currentPath, graphicsState.ctm) else null
            super.paintPath(operation, rule)
            if (next != null) clip = intersection(clip, next)
        }
    }

    private class AnalysisLimit : RuntimeException("PDF fit analysis limit reached")
}