package hu.reelee81.pdflabelprinting

import java.nio.ByteBuffer
import java.nio.ByteOrder

internal class PdfTrueTypeBounds(bytes: ByteArray) {
    private val data = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
    private val count: Int
    private val head: Int
    private val glyphOffsets: Int
    private val glyphDataOffset: Int
    private val glyphDataLength: Int
    private val longOffsets: Boolean
    val unitsPerEm: Int

    init {
        require(data.limit() >= 12 && data.getInt(0) in listOf(0x00010000, tag("true")))
        count = u16(4)
        require(count in 1..128 && 12 + count * 16 <= data.limit())
        require((0 until count).none { data.getInt(12 + it * 16) == tag("gvar") })
        head = table("head", 54).first
        unitsPerEm = u16(head + 18)
        require(unitsPerEm in 16..16384)
        val glyphs = u16(table("maxp", 6).first + 4)
        val offsetFormat = u16(head + 50)
        require(offsetFormat in 0..1)
        longOffsets = offsetFormat == 1
        glyphOffsets = table("loca", (glyphs + 1) * if (longOffsets) 4 else 2).first
        val glyphTable = table("glyf", 0)
        glyphDataOffset = glyphTable.first
        glyphDataLength = glyphTable.second
    }

    fun glyphBox(gid: Int): IntArray? {
        if (gid < 0) return null
        val step = if (longOffsets) 4 else 2
        val offsetsLength = table("loca", 0).second
        if ((gid.toLong() + 2) * step > offsetsLength) return null
        val start = if (longOffsets) u32(glyphOffsets + gid * 4) else u16(glyphOffsets + gid * 2).toLong() * 2
        val end = if (longOffsets) u32(glyphOffsets + (gid + 1) * 4) else u16(glyphOffsets + (gid + 1) * 2).toLong() * 2
        if (start == end) return intArrayOf(0, 0, 0, 0)
        if (start < 0 || end > glyphDataLength || end - start < 10) return null
        val pos = glyphDataOffset + start.toInt()
        val box = IntArray(4) { data.getShort(pos + 2 + it * 2).toInt() }
        return box.takeIf { it[2] >= it[0] && it[3] >= it[1] }
    }

    fun glyphIsEmpty(gid: Int): Boolean {
        if (gid < 0) return false
        val step = if (longOffsets) 4 else 2
        if ((gid.toLong() + 2) * step > table("loca", 0).second) return false
        val start = if (longOffsets) u32(glyphOffsets + gid * 4) else u16(glyphOffsets + gid * 2).toLong() * 2
        val end = if (longOffsets) u32(glyphOffsets + (gid + 1) * 4) else u16(glyphOffsets + (gid + 1) * 2).toLong() * 2
        return start == end && end <= glyphDataLength
    }

    fun glyphForUnicode(unicode: Int): Int? {
        val (base, length) = table("cmap", 4)
        val records = u16(base + 2)
        if (records > 64 || 4 + records * 8 > length) return null
        var result: Int? = null
        for (index in 0 until records) {
            val pos = base + 4 + index * 8
            val platform = u16(pos)
            val encoding = u16(pos + 2)
            if (platform != 0 && !(platform == 3 && encoding in listOf(0, 1, 10))) continue
            val offset = u32(pos + 4)
            if (offset > length - 2) continue
            val sub = base + offset.toInt()
            val symbol = platform == 3 && encoding == 0
            val code = if (symbol && unicode in 0..255) unicode or 0xf000 else unicode
            val gid = when (u16(sub)) {
                4 -> lookup4(sub, base + length, code)
                12 -> lookup12(sub, base + length, code)
                else -> null
            }
            if (gid != null && gid != 0) {
                result = gid
                if (!symbol) return result
            }
        }
        return result
    }

    fun glyphForSymbolicByte(code: Int): Int? {
        if (code !in 0..255) return null
        val (base, length) = table("cmap", 4)
        if (length < 12 || u16(base + 2) != 1 || u16(base + 4) != 1 || u16(base + 6) != 0) return null
        val offset = u32(base + 8)
        if (offset < 12 || offset > length - 262) return null
        val sub = base + offset.toInt()
        if (u16(sub) != 0 || u16(sub + 2) != 262) return null
        return (data.get(sub + 6 + code).toInt() and 255).takeIf { it != 0 }
    }

    private fun lookup4(sub: Int, end: Int, code: Int): Int? {
        if (code !in 0..0xffff || sub > end - 16) return null
        val length = u16(sub + 2)
        val segments = u16(sub + 6) / 2
        if (segments !in 1..8192 || length < 16 + segments * 8 || sub > end - length) return null
        val ends = sub + 14
        val starts = ends + segments * 2 + 2
        val deltas = starts + segments * 2
        val offsets = deltas + segments * 2
        for (index in 0 until segments) {
            if (code > u16(ends + index * 2)) continue
            val start = u16(starts + index * 2)
            if (code < start) return null
            val delta = data.getShort(deltas + index * 2).toInt()
            val range = u16(offsets + index * 2)
            if (range == 0) return (code + delta) and 0xffff
            val address = offsets + index * 2 + range + (code - start) * 2
            if (address > sub + length - 2) return null
            val gid = u16(address)
            return if (gid == 0) 0 else (gid + delta) and 0xffff
        }
        return null
    }

    private fun lookup12(sub: Int, end: Int, code: Int): Int? {
        if (sub > end - 16) return null
        val length = u32(sub + 4)
        val groups = u32(sub + 12)
        if (groups > 65536 || length < 16 + groups * 12 || length > end - sub) return null
        var low = 0
        var high = groups.toInt() - 1
        while (low <= high) {
            val mid = (low + high) ushr 1
            val pos = sub + 16 + mid * 12
            val start = u32(pos)
            val finish = u32(pos + 4)
            when {
                code.toLong() < start -> high = mid - 1
                code.toLong() > finish -> low = mid + 1
                else -> return (u32(pos + 8) + code - start).takeIf { it in 0..65535 }?.toInt()
            }
        }
        return null
    }

    private fun table(name: String, minimum: Int): Pair<Int, Int> {
        for (index in 0 until count) {
            val pos = 12 + index * 16
            if (data.getInt(pos) != tag(name)) continue
            val offset = u32(pos + 8)
            val length = u32(pos + 12)
            require(length >= minimum && offset <= data.limit() && length <= data.limit() - offset)
            return offset.toInt() to length.toInt()
        }
        throw IllegalArgumentException("Missing font table: $name")
    }

    private fun u16(offset: Int): Int = data.getShort(offset).toInt() and 0xffff
    private fun u32(offset: Int): Long = data.getInt(offset).toLong() and 0xffffffffL
    private fun tag(value: String): Int = value.fold(0) { result, char -> (result shl 8) or char.code }
}