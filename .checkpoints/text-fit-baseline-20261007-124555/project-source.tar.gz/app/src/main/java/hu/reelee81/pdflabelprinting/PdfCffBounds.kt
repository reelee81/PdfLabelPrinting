package hu.reelee81.pdflabelprinting

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

internal class PdfCffBounds(private val bytes: ByteArray) {
    private class Slice(val start: Int, val end: Int)
    private class Index(val count: Int, val offsets: Int, val width: Int, val base: Int, val end: Int)
    private class Dictionary {
        var charset = 0
        var characters = 0
        var arrays = 0
        var selection = 0
        var privateSize = 0
        var privateOffset = 0
        var subroutines = 0
        var matrix: DoubleArray? = null
        var cid = false
        var type = 2
        var paint = 0
    }
    private class Local(val subroutines: Index?, val matrix: DoubleArray)

    private var work = 0
    private val deadline = System.nanoTime() + 500_000_000L
    private val top: Dictionary
    private val characters: Index
    private val global: Index
    private val arrays: Index
    private val glyphs = LinkedHashMap<Int, IntArray?>()
    private val locals = HashMap<Int, Local>()

    init {
        require(bytes.size in 4..512 * 1024 && byte(0) == 1 && byte(2) in 4..bytes.size && byte(3) in 1..4)
        val names = index(byte(2))
        require(names.count == 1)
        val dictionaries = index(names.end)
        require(dictionaries.count == 1)
        top = dictionary(item(dictionaries, 0))
        require(top.cid && top.type == 2 && top.paint == 0 && top.charset > 2)
        val strings = index(dictionaries.end)
        global = index(strings.end)
        characters = index(top.characters)
        require(characters.count > 0 && top.arrays > 0 && top.selection > 0)
        arrays = index(top.arrays)
        require(arrays.count in 1..256)
    }

    fun glyphBox(cid: Int): IntArray? {
        if (glyphs.containsKey(cid)) return glyphs[cid]
        val result = try {
            glyphForCid(cid)?.let { gid ->
                val local = local(fontForGlyph(gid))
                Outline(local).measure(item(characters, gid))
            }
        } catch (_: IllegalArgumentException) {
            null
        }
        if (glyphs.size >= 64) glyphs.remove(glyphs.keys.first())
        glyphs[cid] = result
        return result
    }

    private fun checkWork() {
        require(++work <= 200_000 && System.nanoTime() <= deadline)
    }

    private fun byte(position: Int): Int {
        require(position in bytes.indices)
        return bytes[position].toInt() and 255
    }

    private fun unsigned(position: Int, width: Int): Int {
        require(width in 1..4 && position >= 0 && position <= bytes.size - width)
        var value = 0L
        for (offset in 0 until width) value = (value shl 8) or byte(position + offset).toLong()
        require(value <= Int.MAX_VALUE)
        return value.toInt()
    }

    private fun index(position: Int): Index {
        val count = unsigned(position, 2)
        if (count == 0) return Index(0, position + 2, 1, position + 2, position + 2)
        val width = byte(position + 2)
        require(width in 1..4)
        val offsets = position + 3
        val base = offsets.toLong() + (count + 1L) * width - 1
        require(base >= 0 && base < bytes.size)
        var previous = 1
        for (entry in 0..count) {
            checkWork()
            val offset = unsigned(offsets + entry * width, width)
            require(offset >= previous && base + offset <= bytes.size && (entry != 0 || offset == 1))
            previous = offset
        }
        return Index(count, offsets, width, base.toInt(), base.toInt() + previous)
    }

    private fun item(index: Index, entry: Int): Slice {
        require(entry in 0 until index.count)
        return Slice(index.base + unsigned(index.offsets + entry * index.width, index.width),
            index.base + unsigned(index.offsets + (entry + 1) * index.width, index.width))
    }

    private inner class Reader(val slice: Slice) {
        var position = slice.start
        fun read(): Int {
            require(position < slice.end)
            return byte(position++)
        }
        fun number(first: Int, dictionary: Boolean): Double = when (first) {
            in 32..246 -> (first - 139).toDouble()
            in 247..250 -> ((first - 247) * 256 + read() + 108).toDouble()
            in 251..254 -> (-(first - 251) * 256 - read() - 108).toDouble()
            28 -> ((read() shl 8) or read()).toShort().toDouble()
            29 -> {
                require(dictionary)
                ((read() shl 24) or (read() shl 16) or (read() shl 8) or read()).toDouble()
            }
            30 -> {
                require(dictionary)
                val value = StringBuilder()
                var finished = false
                while (!finished) {
                    require(value.length <= 64)
                    val encoded = read()
                    for (digit in intArrayOf(encoded ushr 4, encoded and 15)) {
                        when (digit) {
                            in 0..9 -> value.append(digit)
                            10 -> value.append('.')
                            11 -> value.append('E')
                            12 -> value.append("E-")
                            14 -> value.append('-')
                            15 -> { finished = true; break }
                            else -> throw IllegalArgumentException("Invalid font number")
                        }
                    }
                }
                requireNotNull(value.toString().toDoubleOrNull()).also { require(it.isFinite()) }
            }
            255 -> {
                require(!dictionary)
                ((read() shl 24) or (read() shl 16) or (read() shl 8) or read()).toDouble() / 65536
            }
            else -> throw IllegalArgumentException("Invalid font number")
        }
    }

    private fun dictionary(slice: Slice): Dictionary {
        val result = Dictionary()
        val reader = Reader(slice)
        val values = DoubleArray(48)
        var count = 0
        fun integer(entry: Int): Int {
            require(entry < count && values[entry] >= 0 && values[entry] <= bytes.size && values[entry] == floor(values[entry]))
            return values[entry].toInt()
        }
        while (reader.position < slice.end) {
            checkWork()
            val first = reader.read()
            if (first >= 28) {
                require(count < values.size)
                values[count++] = reader.number(first, true)
                continue
            }
            val operator = if (first == 12) 1200 + reader.read() else first
            when (operator) {
                15 -> { require(count == 1); result.charset = integer(0) }
                17 -> { require(count == 1); result.characters = integer(0) }
                18 -> { require(count == 2); result.privateSize = integer(0); result.privateOffset = integer(1) }
                19 -> { require(count == 1); result.subroutines = integer(0) }
                1205 -> { require(count == 1); result.paint = values[0].toInt() }
                1206 -> { require(count == 1); result.type = values[0].toInt() }
                1207 -> { require(count == 6); result.matrix = values.copyOf(6) }
                1220 -> throw IllegalArgumentException("Synthetic font")
                1230 -> { require(count == 3); result.cid = true }
                1236 -> { require(count == 1); result.arrays = integer(0) }
                1237 -> { require(count == 1); result.selection = integer(0) }
            }
            count = 0
        }
        require(count == 0)
        return result
    }

    private fun glyphForCid(cid: Int): Int? {
        if (cid == 0) return 0
        if (cid !in 1..65535) return null
        val format = byte(top.charset)
        require(format in 0..2)
        var position = top.charset + 1
        var gid = 1
        while (gid < characters.count) {
            checkWork()
            val first = unsigned(position, 2)
            position += 2
            val remaining = if (format == 0) 0 else unsigned(position, format).also { position += format }
            require(remaining < characters.count - gid && first + remaining <= 65535)
            if (cid in first..first + remaining) return gid + cid - first
            gid += remaining + 1
        }
        return null
    }

    private fun fontForGlyph(gid: Int): Int {
        val position = top.selection
        return when (byte(position)) {
            0 -> byte(position + 1 + gid)
            3 -> {
                val count = unsigned(position + 1, 2)
                require(count in 1..characters.count)
                var previous = 0
                var selected = -1
                for (entry in 0 until count) {
                    checkWork()
                    val start = unsigned(position + 3 + entry * 3, 2)
                    require(if (entry == 0) start == 0 else start > previous)
                    require(start < characters.count)
                    if (start <= gid) selected = byte(position + 5 + entry * 3)
                    previous = start
                }
                require(unsigned(position + 3 + count * 3, 2) == characters.count)
                selected
            }
            else -> throw IllegalArgumentException("Unsupported font selection")
        }.also { require(it in 0 until arrays.count) }
    }

    private fun local(fd: Int): Local {
        locals[fd]?.let { return it }
        require(locals.size < 16)
        val dictionary = dictionary(item(arrays, fd))
        require(dictionary.type == 2 && dictionary.paint == 0)
        val start = dictionary.privateOffset
        val size = dictionary.privateSize
        require(start >= 0 && size <= bytes.size - start)
        val private = dictionary(Slice(start, start + size))
        val subroutines = if (private.subroutines == 0) null else {
            require(private.subroutines <= bytes.size - start)
            index(start + private.subroutines)
        }
        val parent = top.matrix
        val child = dictionary.matrix
        val matrix = when {
            child == null -> parent ?: doubleArrayOf(.001, 0.0, 0.0, .001, 0.0, 0.0)
            parent == null -> child
            else -> doubleArrayOf(
                child[0] * parent[0] + child[1] * parent[2], child[0] * parent[1] + child[1] * parent[3],
                child[2] * parent[0] + child[3] * parent[2], child[2] * parent[1] + child[3] * parent[3],
                child[4] * parent[0] + child[5] * parent[2] + parent[4],
                child[4] * parent[1] + child[5] * parent[3] + parent[5])
        }.map { it * 1000 }.toDoubleArray()
        require(matrix.all { it.isFinite() && abs(it) <= 1e6 })
        return Local(subroutines, matrix).also { locals[fd] = it }
    }

    private inner class Outline(private val local: Local) {
        private val stack = DoubleArray(48)
        private val transient = DoubleArray(32)
        private var count = 0
        private var width = true
        private var hints = 0
        private var steps = 0
        private var moved = false
        private var x = 0.0
        private var y = 0.0
        private var left = Double.POSITIVE_INFINITY
        private var bottom = Double.POSITIVE_INFINITY
        private var right = Double.NEGATIVE_INFINITY
        private var top = Double.NEGATIVE_INFINITY

        fun measure(slice: Slice): IntArray {
            require(run(slice, 0, false))
            if (left == Double.POSITIVE_INFINITY) return intArrayOf(0, 0, 0, 0)
            require(left > Int.MIN_VALUE && bottom > Int.MIN_VALUE && right < Int.MAX_VALUE && top < Int.MAX_VALUE)
            return intArrayOf(floor(left).toInt(), floor(bottom).toInt(), ceil(right).toInt(), ceil(top).toInt())
        }

        private fun push(value: Double) {
            require(count < stack.size && value.isFinite() && abs(value) <= 1e9)
            stack[count++] = value
        }
        private fun pop(): Double { require(count > 0); return stack[--count] }
        private fun integer(value: Double): Int { require(value == floor(value)); return value.toInt() }
        private fun removeWidth(expected: Int) {
            if (width && count == expected + 1) {
                stack.copyInto(stack, 0, 1, count)
                count--
            }
            width = false
        }
        private fun horizontal(x: Double, y: Double): Double = local.matrix[0] * x + local.matrix[2] * y + local.matrix[4]
        private fun vertical(x: Double, y: Double): Double = local.matrix[1] * x + local.matrix[3] * y + local.matrix[5]
        private fun includeX(value: Double) { require(value.isFinite()); left = min(left, value); right = max(right, value) }
        private fun includeY(value: Double) { require(value.isFinite()); bottom = min(bottom, value); top = max(top, value) }
        private fun line(dx: Double, dy: Double) {
            require(moved)
            includeX(horizontal(x, y)); includeY(vertical(x, y))
            x += dx; y += dy
            includeX(horizontal(x, y)); includeY(vertical(x, y))
        }
        private fun curve(dx1: Double, dy1: Double, dx2: Double, dy2: Double, dx3: Double, dy3: Double) {
            require(moved)
            val x1 = x + dx1; val y1 = y + dy1
            val x2 = x1 + dx2; val y2 = y1 + dy2
            val x3 = x2 + dx3; val y3 = y2 + dy3
            PdfCurveBounds.include(horizontal(x, y), horizontal(x1, y1), horizontal(x2, y2), horizontal(x3, y3), ::includeX)
            PdfCurveBounds.include(vertical(x, y), vertical(x1, y1), vertical(x2, y2), vertical(x3, y3), ::includeY)
            x = x3; y = y3
        }
        private fun curveAt(i: Int) = curve(stack[i], stack[i + 1], stack[i + 2], stack[i + 3], stack[i + 4], stack[i + 5])

        private fun run(slice: Slice, depth: Int, subroutine: Boolean): Boolean {
            require(depth <= 10)
            val reader = Reader(slice)
            while (reader.position < slice.end) {
                checkWork()
                require(++steps <= 4096)
                val operator = reader.read()
                if (operator >= 32 || operator == 28) {
                    push(reader.number(operator, false))
                    continue
                }
                when (operator) {
                    1, 3, 18, 23, 19, 20 -> {
                        removeWidth(count - count % 2)
                        require(count % 2 == 0)
                        hints += count / 2
                        require(hints <= 96)
                        if (operator == 19 || operator == 20) {
                            reader.position += (hints + 7) / 8
                            require(reader.position <= slice.end)
                        }
                    }
                    4, 21, 22 -> {
                        removeWidth(if (operator == 21) 2 else 1)
                        require(count == if (operator == 21) 2 else 1)
                        x += if (operator == 4) 0.0 else stack[0]
                        y += if (operator == 22) 0.0 else stack[count - 1]
                        moved = true
                    }
                    5 -> {
                        require(count >= 2 && count % 2 == 0)
                        for (i in 0 until count step 2) line(stack[i], stack[i + 1])
                    }
                    6, 7 -> {
                        require(count > 0)
                        var horizontal = operator == 6
                        for (i in 0 until count) {
                            line(if (horizontal) stack[i] else 0.0, if (horizontal) 0.0 else stack[i])
                            horizontal = !horizontal
                        }
                    }
                    8 -> { require(count >= 6 && count % 6 == 0); for (i in 0 until count step 6) curveAt(i) }
                    24 -> {
                        require(count >= 8 && (count - 2) % 6 == 0)
                        for (i in 0 until count - 2 step 6) curveAt(i)
                        line(stack[count - 2], stack[count - 1])
                    }
                    25 -> {
                        require(count >= 8 && (count - 6) % 2 == 0)
                        for (i in 0 until count - 6 step 2) line(stack[i], stack[i + 1])
                        curveAt(count - 6)
                    }
                    26, 27 -> {
                        require(count >= 4 && count % 4 in 0..1)
                        var i = count % 4
                        var extra = if (i == 1) stack[0] else 0.0
                        while (i < count) {
                            if (operator == 26) curve(extra, stack[i], stack[i + 1], stack[i + 2], 0.0, stack[i + 3])
                            else curve(stack[i], extra, stack[i + 1], stack[i + 2], stack[i + 3], 0.0)
                            extra = 0.0; i += 4
                        }
                    }
                    30, 31 -> {
                        require(count >= 4 && count % 4 in 0..1)
                        var horizontal = operator == 31
                        var i = 0
                        while (i + 3 < count) {
                            val extra = if (count - i == 5) stack[i + 4] else 0.0
                            if (horizontal) curve(stack[i], 0.0, stack[i + 1], stack[i + 2], extra, stack[i + 3])
                            else curve(0.0, stack[i], stack[i + 1], stack[i + 2], stack[i + 3], extra)
                            i += 4; horizontal = !horizontal
                        }
                    }
                    10, 29 -> {
                        val index = if (operator == 10) requireNotNull(local.subroutines) else global
                        val bias = if (index.count < 1240) 107 else if (index.count < 33900) 1131 else 32768
                        val entry = integer(pop()) + bias
                        if (run(item(index, entry), depth + 1, true)) return true
                        continue
                    }
                    11 -> { require(subroutine); return false }
                    14 -> {
                        removeWidth(0)
                        require(count == 0)
                        return true
                    }
                    12 -> { escaped(reader.read()); continue }
                    else -> throw IllegalArgumentException("Unsupported outline operator")
                }
                count = 0
            }
            throw IllegalArgumentException("Unterminated outline")
        }

        private fun escaped(operator: Int) {
            when (operator) {
                0 -> require(count == 0)
                3, 4, 10, 11, 12, 15, 24 -> {
                    val b = pop(); val a = pop()
                    push(when (operator) {
                        3 -> if (a != 0.0 && b != 0.0) 1.0 else 0.0
                        4 -> if (a != 0.0 || b != 0.0) 1.0 else 0.0
                        10 -> a + b
                        11 -> a - b
                        12 -> a / b
                        15 -> if (a == b) 1.0 else 0.0
                        else -> a * b
                    })
                }
                5 -> push(if (pop() == 0.0) 1.0 else 0.0)
                9 -> push(abs(pop()))
                14 -> push(-pop())
                18 -> pop()
                20 -> { val i = integer(pop()); val value = pop(); require(i in transient.indices); transient[i] = value }
                21 -> { val i = integer(pop()); require(i in transient.indices); push(transient[i]) }
                22 -> { val b = pop(); val a = pop(); val second = pop(); val first = pop(); push(if (a <= b) first else second) }
                26 -> push(sqrt(pop()))
                27 -> { val value = pop(); push(value); push(value) }
                28 -> { val b = pop(); val a = pop(); push(b); push(a) }
                29 -> { val i = integer(pop()).coerceAtLeast(0); require(count > 0); push(stack[max(0, count - 1 - i)]) }
                30 -> {
                    val shift = integer(pop()); val size = integer(pop()); require(size in 1..count)
                    val offset = ((shift % size) + size) % size
                    repeat(offset) {
                        val last = stack[count - 1]
                        stack.copyInto(stack, count - size + 1, count - size, count - 1)
                        stack[count - size] = last
                    }
                }
                34 -> {
                    require(count == 7)
                    curve(stack[0], 0.0, stack[1], stack[2], stack[3], 0.0)
                    curve(stack[4], 0.0, stack[5], -stack[2], stack[6], 0.0)
                    count = 0
                }
                35 -> { require(count == 13); curveAt(0); curveAt(6); count = 0 }
                36 -> {
                    require(count == 9)
                    curve(stack[0], stack[1], stack[2], stack[3], stack[4], 0.0)
                    curve(stack[5], 0.0, stack[6], stack[7], stack[8], -stack[1] - stack[3] - stack[7])
                    count = 0
                }
                37 -> {
                    require(count == 11)
                    val dx = stack[0] + stack[2] + stack[4] + stack[6] + stack[8]
                    val dy = stack[1] + stack[3] + stack[5] + stack[7] + stack[9]
                    curveAt(0)
                    curve(stack[6], stack[7], stack[8], stack[9], if (abs(dx) > abs(dy)) stack[10] else -dx,
                        if (abs(dx) > abs(dy)) -dy else stack[10])
                    count = 0
                }
                else -> throw IllegalArgumentException("Unsupported outline operator")
            }
        }
    }
}