package hu.reelee81.pdflabelprinting

import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.os.ext.SdkExtensions
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.ChecksSdkIntAtLeast
import androidx.annotation.RequiresExtension
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.Toolbar.LayoutParams
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.pdf.PdfWriteHandle
import com.itextpdf.kernel.pdf.PdfDocument as ITextPdfDocument
import com.itextpdf.kernel.pdf.PdfName
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.utils.PdfAnnotationFlattener
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PdfEditorActivity : PdfActivity() {

    companion object {
        const val EXTRA_INPUT_URI = "pdf_input_uri"
        const val EXTRA_OUTPUT_URI = "pdf_output_uri"
        const val EXTRA_INITIAL_PAGE_INDEX = "pdf_initial_page_index"
        const val EXTRA_CURRENT_PAGE_INDEX = "pdf_current_page_index"
        private const val FRAG_TAG = "pdfEditorFrag"
        private const val STATE_DISCARD_CONFIRMATION_VISIBLE = "pdf_discard_confirmation_visible"
    }

    private lateinit var fragment: PdfEditorFragment
    private var saveButton: MaterialButton? = null
    private var saving = false
    private var documentLoaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!supportsPdfEditing()) {
            Toast.makeText(this, getString(R.string.pdf_editor_requires_s_ext_18), Toast.LENGTH_LONG).show()
            finish()
            return
        }

        setContentView(R.layout.viewer_pdf)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !night
        SystemBarsCompat.applyNavBarColor(this, ContextCompat.getColor(this, R.color.pdf_viewer_sb_bg_color))

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.title = getString(R.string.edit_pdf)
        toolbar.navigationIcon = AppCompatResources.getDrawable(this, R.drawable.ic_arrow_back_24)
        toolbar.setNavigationOnClickListener { finishOrConfirmDiscard() }

        val uri = intent.getStringExtra(EXTRA_INPUT_URI)?.toUri()
        if (uri == null) {
            Toast.makeText(this, getString(R.string.temporary_pdf_not_found), Toast.LENGTH_LONG).show()
            finish()
            return
        }

        fragment = (supportFragmentManager.findFragmentByTag(FRAG_TAG) as? PdfEditorFragment)
            ?: PdfEditorFragment().also {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.pdfFragContainer, it, FRAG_TAG)
                    .commitNow()
            }

        if (savedInstanceState == null) {
            fragment.loadDocumentAtPage(uri, intent.getIntExtra(EXTRA_INITIAL_PAGE_INDEX, 0))
        } else {
            fragment.documentUri = uri
        }

        addSaveButton(toolbar)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finishOrConfirmDiscard()
            }
        })

        if (savedInstanceState?.getBoolean(STATE_DISCARD_CONFIRMATION_VISIBLE) == true) {
            showDiscardConfirmation()
        }
        onPdfOperationStateChanged()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(
            STATE_DISCARD_CONFIRMATION_VISIBLE,
            findViewById<View>(R.id.overlay_dialog_pdf_editor_discard)?.isVisible == true
        )
        super.onSaveInstanceState(outState)
    }

    override fun isPdfNavigationInProgress(): Boolean =
        supportsPdfEditing() && ::fragment.isInitialized && fragment.isPageNavigationInProgress

    override fun isPdfSavingInProgress(): Boolean =
        saving || (supportsPdfEditing() && ::fragment.isInitialized && fragment.isApplyEditsInProgress)

    override fun isPdfOperationInProgress(): Boolean =
        isPdfSavingInProgress() || isPdfNavigationInProgress()

    override fun onPdfNavigationStateChanged(inProgress: Boolean) {
        if (!supportsPdfEditing() || !::fragment.isInitialized) return
        saveButton?.isEnabled = documentLoaded && !inProgress && !saving && !fragment.isApplyEditsInProgress
        if (documentLoaded && !inProgress && !saving && !isFinishing && !isDestroyed &&
            !fragment.isEditModeEnabled
        ) {
            fragment.isEditModeEnabled = true
        }
    }

    private fun addSaveButton(toolbar: MaterialToolbar) {
        val s = resources.getDimensionPixelSize(R.dimen.dp_44)
        val horizontalPadding = resources.getDimensionPixelSize(R.dimen.dp_16)

        saveButton = MaterialButton(
            this,
            null,
            com.google.android.material.R.attr.materialButtonStyle
        ).apply {
            text = getString(R.string.save_pdf_edits)
            minWidth = 0
            minimumWidth = 0
            insetLeft = 0
            insetRight = 0
            setPaddingRelative(horizontalPadding, paddingTop, horizontalPadding, paddingBottom)
            isEnabled = false
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, s).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                rightMargin = resources.getDimensionPixelSize(R.dimen.dp_20)
            }
            setOnClickListener { saveEdits() }
        }

        toolbar.addView(saveButton)
    }

    @RequiresExtension(extension = Build.VERSION_CODES.S, version = 18)
    fun onEditorDocumentLoaded() {
        documentLoaded = true
        onPdfOperationStateChanged()
    }

    fun onEditorDocumentLoadFailed() {
        documentLoaded = false
        saveButton?.isEnabled = false
    }

    private fun saveEdits() {
        if (!supportsPdfEditing()) return
        if (!documentLoaded) return
        if (fragment.isPageNavigationInProgress) return
        if (saving || fragment.isApplyEditsInProgress) return

        if (!fragment.hasUnsavedChanges) {
            Toast.makeText(this, getString(R.string.no_pdf_edits_to_save), Toast.LENGTH_SHORT).show()
            return
        }

        saving = true
        onPdfOperationStateChanged()
        try {
            fragment.applyDraftEdits()
        } catch (e: Exception) {
            onApplyEditsFailed(e)
        }
    }

    @RequiresExtension(extension = Build.VERSION_CODES.S, version = 18)
    fun onApplyEditsSuccess(handle: PdfWriteHandle) {
        saving = true
        onPdfOperationStateChanged()
        lifecycleScope.launch {
            try {
                val outFile = File(cacheDir, "edited_${System.currentTimeMillis()}.pdf")

                withContext(Dispatchers.IO) {
                    handle.use { writeHandle ->
                        ParcelFileDescriptor.open(
                            outFile,
                            ParcelFileDescriptor.MODE_CREATE or
                                    ParcelFileDescriptor.MODE_TRUNCATE or
                                    ParcelFileDescriptor.MODE_READ_WRITE
                        ).use { pfd ->
                            writeHandle.writeTo(pfd)
                        }
                    }
                    flattenVisibleAnnotations(outFile)
                }

                val outUri = FileProvider.getUriForFile(this@PdfEditorActivity, "$packageName.provider", outFile)
                finishEditor(outUri)
            } catch (e: Exception) {
                saving = false
                saveButton?.isEnabled = true
                Toast.makeText(this@PdfEditorActivity, getString(R.string.pdf_edits_save_failed, e.message), Toast.LENGTH_LONG).show()
                onPdfOperationStateChanged()
            }
        }
    }

    fun onApplyEditsFailed(error: Throwable) {
        saving = false
        saveButton?.isEnabled = true
        Toast.makeText(this, getString(R.string.pdf_edits_save_failed, error.message), Toast.LENGTH_LONG).show()
        onPdfOperationStateChanged()
    }

    private fun flattenVisibleAnnotations(file: File) {
        val flatFile = File(cacheDir, "flattened_${System.currentTimeMillis()}.pdf")
        if (flatFile.exists()) flatFile.delete()

        ITextPdfDocument(PdfReader(file.absolutePath), PdfWriter(flatFile.absolutePath)).use { pdf ->
            val flattener = PdfAnnotationFlattener()
            for (pageNumber in 1..pdf.numberOfPages) {
                val page = pdf.getPage(pageNumber)
                val annotations = page.annotations
                    .filter { annotation ->
                        when (annotation.subtype) {
                            PdfName.Stamp,
                            PdfName.Ink,
                            PdfName.Highlight,
                            PdfName.FreeText -> true
                            else -> false
                        }
                    }
                    .toList()

                if (annotations.isNotEmpty()) {
                    flattener.flatten(annotations)
                }
            }
        }

        if (file.exists()) file.delete()
        if (!flatFile.renameTo(file)) {
            flatFile.copyTo(file, overwrite = true)
            flatFile.delete()
        }
    }

    private fun finishOrConfirmDiscard() {
        if (isPdfSavingInProgress()) return

        val overlay = findViewById<View>(R.id.overlay_dialog_pdf_editor_discard)
        if (overlay.isVisible) {
            hideDiscardConfirmation()
            return
        }

        if (!supportsPdfEditing()) {
            finish()
            return
        }

        if (::fragment.isInitialized && fragment.hasUnsavedChanges) {
            showDiscardConfirmation()
        } else {
            finishEditor()
        }
    }

    private fun showDiscardConfirmation() {
        val overlay = findViewById<View>(R.id.overlay_dialog_pdf_editor_discard)
        val panel = findViewById<View>(R.id.overlay_dialog_pdf_editor_discard_panel)
        val cancel = findViewById<MaterialButton>(R.id.pdf_editor_discard_cancel)
        val discard = findViewById<MaterialButton>(R.id.pdf_editor_discard_confirm)

        overlay.setOnClickListener { hideDiscardConfirmation() }
        panel.setOnClickListener { }
        cancel.setOnClickListener { hideDiscardConfirmation() }
        discard.setOnClickListener {
            hideDiscardConfirmation()
            finishEditor()
        }

        overlay.isVisible = true
    }

    private fun hideDiscardConfirmation() {
        findViewById<View>(R.id.overlay_dialog_pdf_editor_discard).apply {
            isVisible = false
            setOnClickListener(null)
        }
    }

    private fun finishEditor(outputUri: Uri? = null) {
        val currentPageIndex =
            if (supportsPdfEditing() && ::fragment.isInitialized) fragment.currentPageIndex else 0
        val resultData = Intent().putExtra(
            EXTRA_CURRENT_PAGE_INDEX,
            currentPageIndex
        )
        if (outputUri != null) {
            resultData.putExtra(EXTRA_OUTPUT_URI, outputUri.toString())
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setResult(RESULT_OK, resultData)
        } else {
            setResult(RESULT_CANCELED, resultData)
        }

        if (supportsPdfEditing() && ::fragment.isInitialized && fragment.isEditModeEnabled) {
            fragment.isEditModeEnabled = false
        }
        finish()
    }

    @ChecksSdkIntAtLeast(extension = Build.VERSION_CODES.S, api = 18)
    private fun supportsPdfEditing(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SdkExtensions.getExtensionVersion(Build.VERSION_CODES.S) >= 18
}