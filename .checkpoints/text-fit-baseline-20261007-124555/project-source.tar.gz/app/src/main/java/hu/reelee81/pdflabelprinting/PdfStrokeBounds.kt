package hu.reelee81.pdflabelprinting

import com.itextpdf.kernel.geom.BezierCurve
import com.itextpdf.kernel.geom.Line
import com.itextpdf.kernel.geom.Matrix
import com.itextpdf.kernel.geom.Rectangle
import com.itextpdf.kernel.pdf.canvas.parser.data.PathRenderInfo
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

internal object PdfStrokeBounds {
    private class Edge(val x: Double, val y: Double, val endX: Double, val endY: Double) {
        val length = hypot(endX - x, endY - y)
        val dx = (endX - x) / length
        val dy = (endY - y) / length
    }

    private class Bounds(private val matrix: Matrix) {
        var left = Double.POSITIVE_INFINITY
        var bottom = Double.POSITIVE_INFINITY
        var right = Double.NEGATIVE_INFINITY
        var top = Double.NEGATIVE_INFINITY

        fun point(x: Double, y: Double) {
            val px = x * matrix[Matrix.I11] + y * matrix[Matrix.I21] + matrix[Matrix.I31]
            val py = x * matrix[Matrix.I12] + y * matrix[Matrix.I22] + matrix[Matrix.I32]
            left = min(left, px)
            bottom = min(bottom, py)
            right = max(right, px)
            top = max(top, py)
        }

        fun disk(x: Double, y: Double, radius: Double) {
            val px = x * matrix[Matrix.I11] + y * matrix[Matrix.I21] + matrix[Matrix.I31]
            val py = x * matrix[Matrix.I12] + y * matrix[Matrix.I22] + matrix[Matrix.I32]
            val rx = radius * hypot(matrix[Matrix.I11].toDouble(), matrix[Matrix.I21].toDouble())
            val ry = radius * hypot(matrix[Matrix.I12].toDouble(), matrix[Matrix.I22].toDouble())
            left = min(left, px - rx)
            bottom = min(bottom, py - ry)
            right = max(right, px + rx)
            top = max(top, py + ry)
        }

        fun rectangle(): Rectangle? {
            if (!left.toFloat().isFinite() || !bottom.toFloat().isFinite() ||
                !right.toFloat().isFinite() || !top.toFloat().isFinite()) return null
            return Rectangle(left.toFloat(), bottom.toFloat(), (right - left).toFloat(), (top - bottom).toFloat())
                .takeIf { it.width.isFinite() && it.height.isFinite() }
        }
    }

    fun measure(info: PathRenderInfo): Rectangle? {
        val dash = info.lineDashPattern
        if (dash?.getAsArray(0)?.isEmpty == false) return null
        if (info.lineCapStyle !in 0..2 || info.lineJoinStyle !in 0..2) return null
        val half = abs(info.lineWidth.toDouble()) / 2
        if (!half.isFinite() || !info.miterLimit.isFinite()) return null
        val bounds = Bounds(info.ctm)
        var segments = 0
        for (sub in info.path.subpaths) {
            var first: Edge? = null
            var previous: Edge? = null
            fun add(edge: Edge): Boolean {
                if (!edge.length.isFinite()) return false
                if (edge.length == 0.0) return true
                val nx = -edge.dy * half
                val ny = edge.dx * half
                bounds.point(edge.x + nx, edge.y + ny)
                bounds.point(edge.x - nx, edge.y - ny)
                bounds.point(edge.endX + nx, edge.endY + ny)
                bounds.point(edge.endX - nx, edge.endY - ny)
                val prior = previous
                if (prior == null) first = edge else if (!join(bounds, prior, edge, half, info)) return false
                previous = edge
                return true
            }
            for (segment in sub.segments) {
                if (++segments > 4096) return null
                val points = segment.basePoints
                val start = points.firstOrNull() ?: return null
                val end = points.last()
                if (segment is BezierCurve && points.all { it.x == start.x && it.y == start.y }) continue
                if (segment !is Line || points.size != 2) return null
                if (!add(Edge(start.x, start.y, end.x, end.y))) return null
            }
            val start = first ?: continue
            var end = previous ?: continue
            if (sub.isClosed) {
                if (end.endX != start.x || end.endY != start.y) {
                    if (!add(Edge(end.endX, end.endY, start.x, start.y))) return null
                    end = previous
                }
                if (!join(bounds, end, start, half, info)) return null
            } else {
                cap(bounds, start.x, start.y, -start.dx, -start.dy, half, info.lineCapStyle)
                cap(bounds, end.endX, end.endY, end.dx, end.dy, half, info.lineCapStyle)
            }
        }
        return bounds.rectangle()
    }

    private fun join(bounds: Bounds, previous: Edge, next: Edge, half: Double, info: PathRenderInfo): Boolean {
        if (previous.endX != next.x || previous.endY != next.y) return false
        when (info.lineJoinStyle) {
            1 -> bounds.disk(next.x, next.y, half)
            0 -> {
                val dot = previous.dx * next.dx + previous.dy * next.dy
                val cross = previous.dx * next.dy - previous.dy * next.dx
                if (abs(cross) < 1e-12 && dot > 0) return true
                val denominator = 1 + dot
                if (denominator <= 1e-10) return false
                val ratio = sqrt(2 / denominator)
                if (!ratio.isFinite() || ratio > max(1.0, info.miterLimit.toDouble())) return false
                val side = if (cross > 0) -1 else 1
                val dx = -(previous.dy + next.dy) * half / denominator * side
                val dy = (previous.dx + next.dx) * half / denominator * side
                bounds.point(next.x + dx, next.y + dy)
            }
        }
        return true
    }

    private fun cap(bounds: Bounds, x: Double, y: Double, dx: Double, dy: Double, half: Double, style: Int) {
        when (style) {
            1 -> bounds.disk(x, y, half)
            2 -> {
                bounds.point(x + dx * half - dy * half, y + dy * half + dx * half)
                bounds.point(x + dx * half + dy * half, y + dy * half - dx * half)
            }
        }
    }
}