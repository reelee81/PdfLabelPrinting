package hu.reelee81.pdflabelprinting

import kotlin.math.sqrt

internal object PdfCurveBounds {
    fun include(p0: Double, p1: Double, p2: Double, p3: Double, include: (Double) -> Unit) {
        include(p0)
        include(p3)
        val a = -p0 + 3 * p1 - 3 * p2 + p3
        val b = 2 * (p0 - 2 * p1 + p2)
        val c = p1 - p0
        fun at(t: Double) {
            if (t > 0 && t < 1) {
                val s = 1 - t
                include(s * s * s * p0 + 3 * s * s * t * p1 + 3 * s * t * t * p2 + t * t * t * p3)
            }
        }
        if (a == 0.0) {
            if (b != 0.0) at(-c / b)
            return
        }
        val discriminant = b * b - 4 * a * c
        if (discriminant < 0) return
        val root = sqrt(discriminant)
        val q = -0.5 * (b + if (b >= 0) root else -root)
        if (q == 0.0) at(-b / (2 * a)) else {
            at(q / a)
            at(c / q)
        }
    }
}