package hu.reelee81.pdflabelprinting

import com.itextpdf.kernel.geom.Rectangle
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.canvas.PdfCanvas
import com.itextpdf.kernel.pdf.canvas.parser.EventType
import com.itextpdf.kernel.pdf.canvas.parser.data.IEventData
import com.itextpdf.kernel.pdf.canvas.parser.data.PathRenderInfo
import com.itextpdf.kernel.pdf.canvas.parser.listener.IEventListener
import java.io.ByteArrayOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PdfStrokeBoundsTest {
    @Test
    fun aWaveUsesActualCornersInsteadOfMaximumMiterPadding() {
        assertBounds(99.29289f, 98.58579f, 106.70711f, 103.41421f, measure {
            it.setLineWidth(2f).moveTo(100.0, 100.0).lineTo(102.0, 102.0)
                .lineTo(104.0, 100.0).lineTo(106.0, 102.0).stroke()
        })
    }

    @Test
    fun buttCapsDoNotExtendTheEndsOfAHorizontalLine() {
        assertBounds(100f, 95f, 200f, 105f, measure {
            it.setLineWidth(10f).setLineCapStyle(0).moveTo(100.0, 100.0).lineTo(200.0, 100.0).stroke()
        })
    }

    @Test
    fun roundCapsIncludeTheEndDisks() {
        assertBounds(95f, 95f, 205f, 105f, measure {
            it.setLineWidth(10f).setLineCapStyle(1).moveTo(100.0, 100.0).lineTo(200.0, 100.0).stroke()
        })
    }

    @Test
    fun squareCapsOnADiagonalIncludeTheirOuterCorners() {
        assertBounds(92.92893f, 92.92893f, 207.07107f, 207.07107f, measure {
            it.setLineWidth(10f).setLineCapStyle(2).moveTo(100.0, 100.0).lineTo(200.0, 200.0).stroke()
        })
    }

    @Test
    fun bevelJoinsIncludeBothAdjacentStrokeBodies() {
        assertBounds(99.29289f, 99.29289f, 104.70711f, 102.70711f, measure {
            it.setLineWidth(2f).setLineJoinStyle(2).moveTo(100.0, 100.0)
                .lineTo(102.0, 102.0).lineTo(104.0, 100.0).stroke()
        })
    }

    @Test
    fun roundJoinsIncludeTheCornerDisk() {
        assertBounds(99.29289f, 99.29289f, 104.70711f, 103f, measure {
            it.setLineWidth(2f).setLineJoinStyle(1).moveTo(100.0, 100.0)
                .lineTo(102.0, 102.0).lineTo(104.0, 100.0).stroke()
        })
    }

    @Test
    fun shearAndUnequalScalesApplyToTheActualStrokeCorners() {
        assertBounds(257.5f, 405f, 462.5f, 535f, measure {
            it.concatMatrix(2.0, 1.0, .5, 3.0, 10.0, 20.0).setLineWidth(10f)
                .moveTo(100.0, 100.0).lineTo(200.0, 100.0).stroke()
        })
    }

    @Test
    fun roundCapsUnderShearUseTransformedDiskExtents() {
        assertBounds(249.69223f, 404.1886f, 470.30777f, 535.8114f, measure {
            it.concatMatrix(2.0, 1.0, .5, 3.0, 10.0, 20.0).setLineWidth(10f).setLineCapStyle(1)
                .moveTo(100.0, 100.0).lineTo(200.0, 100.0).stroke()
        })
    }

    @Test
    fun aNearReversalKeepsTheConservativeFallback() {
        assertNull(measure {
            it.setLineWidth(10f).setMiterLimit(10f).moveTo(100.0, 100.0)
                .lineTo(200.0, 100.0).lineTo(101.0, 101.0).stroke()
        })
    }

    @Test
    fun curvesKeepTheExistingCurveMeasurement() {
        assertNull(measure {
            it.setLineWidth(2f).moveTo(0.0, 0.0).curveTo(0.0, 100.0, 100.0, 100.0, 100.0, 0.0).stroke()
        })
    }

    @Test
    fun dashedLinesKeepTheExistingConservativeMeasurement() {
        assertNull(measure {
            it.setLineWidth(2f).setLineDash(3f, 2f, 0f).setLineCapStyle(2)
                .moveTo(0.0, 0.0).lineTo(100.0, 100.0).stroke()
        })
    }

    @Test
    fun separateSubpathsDoNotGetJoinedTogether() {
        assertBounds(100f, 99f, 200f, 301f, measure {
            it.setLineWidth(2f).moveTo(100.0, 100.0).lineTo(200.0, 100.0)
                .moveTo(100.0, 300.0).lineTo(200.0, 300.0).stroke()
        })
    }

    private fun measure(draw: (PdfCanvas) -> Unit): Rectangle? {
        PdfDocument(PdfWriter(ByteArrayOutputStream())).use { pdf ->
            val page = pdf.addNewPage()
            draw(PdfCanvas(page))
            var result: Rectangle? = null
            val listener = object : IEventListener {
                override fun eventOccurred(data: IEventData?, type: EventType?) {
                    if (data is PathRenderInfo && data.operation and PathRenderInfo.STROKE != 0) {
                        result = PdfStrokeBounds.measure(data)
                    }
                }
                override fun getSupportedEvents(): Set<EventType> = setOf(EventType.RENDER_PATH)
            }
            PdfFitGeometry.Processor(listener).processPageContent(page)
            return result
        }
    }

    private fun assertBounds(left: Float, bottom: Float, right: Float, top: Float, actual: Rectangle?) {
        val bounds = requireNotNull(actual)
        assertEquals(left, bounds.left, .001f)
        assertEquals(bottom, bounds.bottom, .001f)
        assertEquals(right, bounds.right, .001f)
        assertEquals(top, bounds.top, .001f)
    }
}
