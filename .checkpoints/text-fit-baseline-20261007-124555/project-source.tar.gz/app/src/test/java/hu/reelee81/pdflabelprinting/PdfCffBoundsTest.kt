package hu.reelee81.pdflabelprinting

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.ByteArrayOutputStream

class PdfCffBoundsTest {
    @Test
    fun cidCharsetIsNotMistakenForTheGlyphIndex() {
        val bounds = PdfCffBounds(font(rectangle()))
        assertArrayEquals(intArrayOf(10, 20, 110, 220), bounds.glyphBox(2))
        assertNull(bounds.glyphBox(1))
        assertArrayEquals(intArrayOf(0, 0, 0, 0), bounds.glyphBox(0))
    }

    @Test
    fun rangeCharsetsAndRangeFontSelectionGiveTheSameBounds() {
        for (format in 1..2) {
            assertArrayEquals(intArrayOf(10, 20, 110, 220),
                PdfCffBounds(font(rectangle(), charsetFormat = format, selectionFormat = 3)).glyphBox(2))
        }
    }

    @Test
    fun optionalWidthDoesNotChangeTheOutlinePosition() {
        val program = numbers(500) + rectangle()
        assertArrayEquals(intArrayOf(10, 20, 110, 220), PdfCffBounds(font(program)).glyphBox(2))
    }

    @Test
    fun cubicExtremaDoNotIncludeUnusedControlPoints() {
        val program = numbers(0, 0) + byteArrayOf(21) + numbers(100, 0, 0, 100, -100, 0) + byteArrayOf(8, 14)
        assertArrayEquals(intArrayOf(0, 0, 75, 100), PdfCffBounds(font(program)).glyphBox(2))
    }

    @Test
    fun localAndGlobalSubroutinesShareTheOperandStack() {
        val local = numbers(100, 0, 0, 200, -100, 0) + byteArrayOf(5, 11)
        val global = numbers(-107) + byteArrayOf(10, 11)
        val program = numbers(10, 20) + byteArrayOf(21) + numbers(-107) + byteArrayOf(29, 14)
        assertArrayEquals(intArrayOf(10, 20, 110, 220),
            PdfCffBounds(font(program, localPrograms = listOf(local), globalPrograms = listOf(global))).glyphBox(2))
    }

    @Test
    fun hintsAndMaskBytesAreNotInterpretedAsPathCommands() {
        val program = numbers(500, 0, 20) + byteArrayOf(1, 19, 255.toByte()) + rectangle()
        assertArrayEquals(intArrayOf(10, 20, 110, 220), PdfCffBounds(font(program)).glyphBox(2))
    }

    @Test
    fun localFontMatrixIsUsedWhenTheParentHasNoExplicitMatrix() {
        assertArrayEquals(intArrayOf(20, 40, 220, 440),
            PdfCffBounds(font(rectangle(), childMatrix = doubleArrayOf(.002, 0.0, 0.0, .002, 0.0, 0.0))).glyphBox(2))
    }

    @Test
    fun explicitParentAndChildMatricesAreConcatenated() {
        assertArrayEquals(intArrayOf(-440, 30, -40, 130), PdfCffBounds(font(rectangle(),
            parentMatrix = doubleArrayOf(.001, 0.0, 0.0, .001, 0.0, 0.0),
            childMatrix = doubleArrayOf(0.0, 1.0, -2.0, 0.0, 0.0, 20.0))).glyphBox(2))
    }

    @Test
    fun emptyGlyphKeepsItsEmptyBounds() {
        assertArrayEquals(intArrayOf(0, 0, 0, 0), PdfCffBounds(font(byteArrayOf(14))).glyphBox(2))
    }

    @Test
    fun unsupportedOutlineDoesNotReturnAPartialBoundingBox() {
        assertNull(PdfCffBounds(font(rectangle().dropLast(1).toByteArray() + byteArrayOf(16, 14))).glyphBox(2))
    }

    @Test
    fun compositeGlyphRetainsTheFallbackInsteadOfIgnoringItsAccent() {
        assertNull(PdfCffBounds(font(numbers(0, 0, 65, 66) + byteArrayOf(14))).glyphBox(2))
    }

    @Test
    fun operandStackOverflowStopsTheGlyph() {
        assertNull(PdfCffBounds(font(numbers(*IntArray(49)) + byteArrayOf(14))).glyphBox(2))
    }

    @Test
    fun recursiveSubroutinesStopAtTheDepthLimit() {
        val recursive = numbers(-107) + byteArrayOf(10, 11)
        assertNull(PdfCffBounds(font(numbers(-107) + byteArrayOf(10, 14), localPrograms = listOf(recursive))).glyphBox(2))
    }

    @Test
    fun truncatedOutlineDoesNotReturnAPartialBoundingBox() {
        assertNull(PdfCffBounds(font(rectangle().dropLast(1).toByteArray())).glyphBox(2))
    }

    @Test
    fun truncatedAndOversizedFontsAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { PdfCffBounds(byteArrayOf(1)) }
        assertThrows(IllegalArgumentException::class.java) { PdfCffBounds(ByteArray(512 * 1024 + 1)) }
        val truncated = font(rectangle()).dropLast(1).toByteArray()
        assertThrows(IllegalArgumentException::class.java) { PdfCffBounds(truncated) }
    }

    @Test
    fun fixedPointCoordinatesAreNotReadAsLargeIntegers() {
        val program = byteArrayOf(255.toByte(), 0, 10, -128, 0) + numbers(20) + byteArrayOf(21) +
            numbers(100, 0, 0, 200, -100, 0) + byteArrayOf(5, 14)
        assertArrayEquals(intArrayOf(10, 20, 111, 220), PdfCffBounds(font(program)).glyphBox(2))
    }

    @Test
    fun horizontalAndVerticalCurvesHaveAnalyticExtrema() {
        val horizontal = numbers(0, 0) + byteArrayOf(21) + numbers(100, 0, 100, -100) + byteArrayOf(27, 14)
        val vertical = numbers(0, 0) + byteArrayOf(21) + numbers(100, 100, 0, -100) + byteArrayOf(26, 14)
        assertArrayEquals(intArrayOf(0, 0, 75, 100), PdfCffBounds(font(horizontal)).glyphBox(2))
        assertArrayEquals(intArrayOf(0, 0, 100, 75), PdfCffBounds(font(vertical)).glyphBox(2))
    }

    @Test
    fun alternatingCurvesAndTheirOptionalLastCoordinateAreReadCorrectly() {
        val horizontal = numbers(0, 0) + byteArrayOf(21) + numbers(100, 0, 100, 0, -100) + byteArrayOf(31, 14)
        val vertical = numbers(0, 0) + byteArrayOf(21) + numbers(100, 100, 0, 0, -100) + byteArrayOf(30, 14)
        assertArrayEquals(intArrayOf(0, 0, 75, 100), PdfCffBounds(font(horizontal)).glyphBox(2))
        assertArrayEquals(intArrayOf(0, 0, 100, 75), PdfCffBounds(font(vertical)).glyphBox(2))
        val withoutExtra = numbers(0, 0) + byteArrayOf(21) + numbers(100, 0, 100, -100) + byteArrayOf(31, 14)
        assertArrayEquals(intArrayOf(0, 0, 100, 45), PdfCffBounds(font(withoutExtra)).glyphBox(2))
    }

    @Test
    fun allFlexFormsKeepBothCurvesAndTheReturnToTheStartingAxis() {
        val programs = listOf(
            numbers(100, 100, 100, 100, -100, -100, -100) + byteArrayOf(12, 34),
            numbers(100, 20, 100, 80, 100, 0, -100, 0, -100, -80, -100, -20, 50) + byteArrayOf(12, 35),
            numbers(100, 20, 100, 80, 100, -100, -100, -80, -100) + byteArrayOf(12, 36),
            numbers(100, 20, 100, 80, 100, 0, -100, 0, -100, -80, -100) + byteArrayOf(12, 37)
        )
        for (program in programs) {
            assertArrayEquals(intArrayOf(0, 0, 300, 100),
                PdfCffBounds(font(numbers(0, 0) + byteArrayOf(21) + program + byteArrayOf(14))).glyphBox(2))
        }
    }

    @Test
    fun arithmeticAndTransientStorageKeepTheirOperandOrder() {
        val program = numbers(30, 20) + byteArrayOf(12, 11) + numbers(0) + byteArrayOf(12, 20) +
            numbers(0) + byteArrayOf(12, 21) + numbers(20) + byteArrayOf(21) +
            numbers(100, 0, 0, 200, -100, 0) + byteArrayOf(5, 14)
        assertArrayEquals(intArrayOf(10, 20, 110, 220), PdfCffBounds(font(program)).glyphBox(2))
    }

    @Test
    fun excessiveOutlineWorkStopsWithoutGrowingTheStackOrReturningPartialBounds() {
        val program = ByteArrayOutputStream().apply {
            repeat(2100) { write(numbers(0)); write(22) }
            write(14)
        }.toByteArray()
        assertNull(PdfCffBounds(font(program)).glyphBox(2))
    }

    companion object {
        internal fun rectangle(): ByteArray = numbers(10, 20) + byteArrayOf(21) +
            numbers(100, 0, 0, 200, -100, 0) + byteArrayOf(5, 14)

        private fun numbers(vararg values: Int): ByteArray = ByteArrayOutputStream().apply {
            for (value in values) {
                write(28); write(value ushr 8); write(value)
            }
        }.toByteArray()

        internal fun font(
            program: ByteArray,
            charsetFormat: Int = 0,
            selectionFormat: Int = 0,
            localPrograms: List<ByteArray> = emptyList(),
            globalPrograms: List<ByteArray> = emptyList(),
            parentMatrix: DoubleArray? = null,
            childMatrix: DoubleArray? = null
        ): ByteArray {
            fun index(entries: List<ByteArray>): ByteArray = ByteArrayOutputStream().apply {
                write(entries.size ushr 8); write(entries.size)
                if (entries.isNotEmpty()) {
                    write(2)
                    var position = 1
                    write(0); write(1)
                    for (entry in entries) { position += entry.size; write(position ushr 8); write(position) }
                    for (entry in entries) write(entry)
                }
            }.toByteArray()
            fun offset(value: Int): ByteArray = byteArrayOf(29, (value ushr 24).toByte(), (value ushr 16).toByte(),
                (value ushr 8).toByte(), value.toByte())
            fun matrix(values: DoubleArray?): ByteArray {
                if (values == null) return byteArrayOf()
                return ByteArrayOutputStream().apply {
                    for (value in values) {
                        val digits = value.toString().flatMap { char -> when (char) {
                            '.' -> listOf(10)
                            '-' -> listOf(14)
                            else -> listOf(char.digitToInt())
                        } } + 15
                        write(30)
                        for (i in digits.indices step 2) write((digits[i] shl 4) or digits.getOrElse(i + 1) { 15 })
                    }
                    write(12); write(7)
                }.toByteArray()
            }
            fun top(charset: Int, characters: Int, arrays: Int, selection: Int): ByteArray =
                byteArrayOf(139.toByte(), 139.toByte(), 139.toByte(), 12, 30) + matrix(parentMatrix) +
                    offset(charset) + byteArrayOf(15) + offset(characters) + byteArrayOf(17) +
                    offset(arrays) + byteArrayOf(12, 36) + offset(selection) + byteArrayOf(12, 37)
            fun fd(private: Int): ByteArray = matrix(childMatrix) + offset(6) + offset(private) + byteArrayOf(18)
            val header = byteArrayOf(1, 0, 4, 2)
            val names = index(listOf("Synthetic".toByteArray(Charsets.US_ASCII)))
            val strings = index(emptyList())
            val global = index(globalPrograms)
            val charset = byteArrayOf(charsetFormat.toByte(), 0, 2) + when (charsetFormat) {
                1 -> byteArrayOf(0)
                2 -> byteArrayOf(0, 0)
                else -> byteArrayOf()
            }
            val selection = if (selectionFormat == 3) byteArrayOf(3, 0, 1, 0, 0, 0, 0, 2) else byteArrayOf(0, 0, 0)
            val charsetOffset = header.size + names.size + index(listOf(top(0, 0, 0, 0))).size + strings.size + global.size
            val selectionOffset = charsetOffset + charset.size
            val arraysOffset = selectionOffset + selection.size
            val privateOffset = arraysOffset + index(listOf(fd(0))).size
            val private = offset(6) + byteArrayOf(19)
            val local = index(localPrograms)
            val charactersOffset = privateOffset + private.size + local.size
            return header + names + index(listOf(top(charsetOffset, charactersOffset, arraysOffset, selectionOffset))) +
                strings + global + charset + selection + index(listOf(fd(privateOffset))) + private + local +
                index(listOf(byteArrayOf(14), program))
        }
    }
}
